import type { CrawlResult } from "./crawler";

export type CheckSeverity = "CRITICAL" | "HIGH" | "MEDIUM" | "INFO";
export type CheckStatus = "PASS" | "FAIL" | "SKIP" | "INFO";
export type Grade = "A" | "B" | "C" | "D" | "F";

export interface CheckResult {
  id: string;
  name: string;
  description: string;
  severity: CheckSeverity;
  status: CheckStatus;
  details: string;
  /** Extra data like lists of trackers, forms found, etc. */
  metadata?: Record<string, unknown>;
}

export interface ScanReport {
  url: string;
  scannedAt: string;
  score: number;
  grade: Grade;
  privacyPolicyUrl: string | null;
  checks: CheckResult[];
  summary: {
    total: number;
    passed: number;
    failed: number;
    skipped: number;
    info: number;
  };
  /** True if the site's WAF/bot protection blocked automated scanning. */
  siteBlocked: boolean;
  /** User-friendly message when scanning was partially or fully blocked. */
  blockedMessage: string | null;
  /** How the privacy policy was detected (for debugging/logging). */
  privacyDetectionMethod: string | null;
  /** Which scan modes were used: 'fast', 'deep', or 'fast+deep'. */
  scanMode?: "fast" | "deep" | "fast+deep";
  /** Number of checks resolved by deep scan (upgraded from FAIL/SKIP to PASS). */
  deepScanResolved?: number;
  /** Reasons deep scan was triggered (empty if not triggered). */
  deepScanReasons?: string[];
}

export interface FetchedPage {
  url: string;
  html: string;
  headers: Headers;
  cookies: string[];
  statusCode: number;
}

export interface ScanContext {
  mainPage: FetchedPage;
  privacyPage: FetchedPage | null;
  privacyPolicyUrl: string | null;
  /** Deep crawl results with all categorized links and fetched pages. */
  crawl: CrawlResult;
  /** Whether the privacy policy was found embedded in another page. */
  privacyEmbeddedIn: string | null;
  /** Whether the site's WAF blocked automated scanning. */
  siteBlocked: boolean;
  /** True if the privacy policy page was detected via SPA signals (exists but content is JS-rendered). */
  privacySpaDetected: boolean;
}
