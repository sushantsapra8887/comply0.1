import { ScanReport, ScanContext, FetchedPage, CheckResult } from "./types";
import { fetchPage, isSoft404, isBlockedResponse, stripHtml } from "./utils";
import { deepCrawl, normalizeUrl, CrawlResult } from "./crawler";
import { runNoticeChecks } from "./checks/notice";
import { runConsentChecks } from "./checks/consent";
import { runSecurityChecks } from "./checks/security";
import { runCollectionChecks } from "./checks/collection";
import { runRightsChecks } from "./checks/rights";
import { runChildrenChecks } from "./checks/children";
import { calculateScore, scoreToGrade, summarizeResults } from "./scoring";
import {
  shouldTriggerDeepScan,
  fetchWithBrowser,
  fetchPageWithBrowser,
  isVercelEnvironment,
  type ScanMode,
} from "./deepScan";

/** Overall time budget for the entire scan (keeps us within serverless limits). */
const SCAN_TIMEOUT = 55_000;

/** Privacy content keywords used for validation */
const PRIVACY_KEYWORDS = [
  "privacy", "personal data", "data protection",
  "data we collect", "data fiduciary", "data principal", "consent",
];

/**
 * Run all check modules against a scan context and return the flat array.
 */
async function runAllChecks(ctx: ScanContext): Promise<CheckResult[]> {
  const [
    noticeChecks,
    consentChecks,
    securityChecks,
    collectionChecks,
    rightsChecks,
    childrenChecks,
  ] = await Promise.all([
    Promise.resolve(runNoticeChecks(ctx)),
    Promise.resolve(runConsentChecks(ctx)),
    runSecurityChecks(ctx),
    Promise.resolve(runCollectionChecks(ctx)),
    Promise.resolve(runRightsChecks(ctx)),
    Promise.resolve(runChildrenChecks(ctx)),
  ]);

  return [
    ...noticeChecks,
    ...consentChecks,
    ...securityChecks,
    ...collectionChecks,
    ...rightsChecks,
    ...childrenChecks,
  ];
}

/**
 * Merge fast scan results with deep scan results.
 * Keep fast mode PASSes, update FAIL/SKIP checks with deep mode results.
 */
function mergeResults(
  fastChecks: CheckResult[],
  deepChecks: CheckResult[]
): { merged: CheckResult[]; resolved: number } {
  let resolved = 0;
  const deepMap = new Map(deepChecks.map((c) => [c.id, c]));

  const merged = fastChecks.map((fast) => {
    // Keep fast-mode passes — they're already good
    if (fast.status === "PASS") return fast;

    // For FAIL or SKIP, see if deep scan got a better result
    const deep = deepMap.get(fast.id);
    if (deep && deep.status === "PASS") {
      resolved++;
      return deep;
    }
    // If deep scan also failed/skipped, prefer the deep result (more info)
    if (deep && deep.status !== "SKIP" && fast.status === "SKIP") {
      if (deep.status === "PASS") resolved++;
      return deep;
    }
    return fast;
  });

  return { merged, resolved };
}

/**
 * Main scanner function.
 *
 * Two-mode scanning:
 * - Fast Mode: HTTP fetch, brute-force URLs, link parsing, sitemap check (runs first)
 * - Deep Mode: Puppeteer headless Chrome fallback (auto-triggers if Fast Mode gets incomplete results)
 *
 * 5-step fallback chain for finding privacy policies:
 * Step 1: Direct server-side fetch with enhanced headers + UA rotation
 * Step 2: Robots.txt/sitemap parsing (almost never blocked)
 * Step 3: CORS proxy (allorigins.win) for WAF-blocked sites
 * Step 4: Google Cache fallback
 * Step 5: Mark as blocked with helpful message (never false-negative "no policy found")
 */
export async function scanWebsite(url: string): Promise<ScanReport> {
  const scanStart = Date.now();
  const deadline = scanStart + SCAN_TIMEOUT;

  // Validate and normalize URL
  let normalizedUrl: string;
  try {
    const parsed = new URL(url);
    normalizedUrl = parsed.href;
  } catch {
    throw new Error(
      `Invalid URL: "${url}". Please provide a valid HTTP or HTTPS URL.`
    );
  }

  const domain = new URL(normalizedUrl).hostname;

  // =========================================================================
  // FAST MODE — existing scanner logic (unchanged)
  // =========================================================================

  // 1. Fetch main page (with UA rotation and 403 retry built into fetchPage)
  let mainPage: FetchedPage;
  let mainPageBlocked = false;
  try {
    const result = await fetchPage(normalizedUrl);
    mainPage = {
      url: normalizedUrl,
      html: result.html,
      headers: result.headers,
      cookies: result.cookies,
      statusCode: result.statusCode,
    };
    mainPageBlocked = result.blocked;
  } catch {
    // Total network failure — still try direct probing and sitemaps
    mainPage = {
      url: normalizedUrl,
      html: "",
      headers: new Headers(),
      cookies: [],
      statusCode: 0,
    };
    mainPageBlocked = true;
  }

  // 2. Deep crawl with 5-step fallback chain
  let crawlResult;
  try {
    crawlResult = await deepCrawl(
      mainPageBlocked ? "" : mainPage.html,
      normalizedUrl,
      deadline,
      mainPageBlocked
    );
  } catch {
    crawlResult = {
      allLinks: [],
      privacyLinks: [],
      consentLinks: [],
      rightsLinks: [],
      grievanceLinks: [],
      retentionLinks: [],
      legalLinks: [],
      fetchedPages: new Map(),
      privacyPolicyUrl: null,
      privacyDetectionMethod: "none",
      privacyEmbeddedIn: null,
      siteBlocked: mainPageBlocked,
      privacySpaDetected: false,
      spaDetectedPages: new Map(),
    };
  }

  const siteBlocked = crawlResult.siteBlocked;

  // 3. Determine privacy policy page
  let privacyPolicyUrl = crawlResult.privacyPolicyUrl;
  let privacyPage: FetchedPage | null = null;
  const privacyEmbeddedIn = crawlResult.privacyEmbeddedIn;

  if (privacyPolicyUrl) {
    const normUrl = normalizeUrl(privacyPolicyUrl);
    const cached = crawlResult.fetchedPages.get(normUrl);
    if (cached) {
      privacyPage = cached;
    } else if (Date.now() < deadline) {
      try {
        const result = await fetchPage(privacyPolicyUrl);
        if (!result.blocked && !isSoft404(result.html)) {
          const text = result.html.toLowerCase();
          const hasContent = PRIVACY_KEYWORDS.some((kw) => text.includes(kw));
          if (hasContent) {
            privacyPage = {
              url: privacyPolicyUrl,
              html: result.html,
              headers: result.headers,
              cookies: result.cookies,
              statusCode: result.statusCode,
            };
          }
        }
      } catch {
        privacyPage = null;
      }
    }
  }

  // 4. Build scan context
  const ctx: ScanContext = {
    mainPage,
    privacyPage,
    privacyPolicyUrl,
    crawl: crawlResult,
    privacyEmbeddedIn,
    siteBlocked,
    privacySpaDetected: crawlResult.privacySpaDetected,
  };

  // 5. Run all check modules (Fast Mode)
  const fastChecks = await runAllChecks(ctx);

  // 6. Calculate fast mode score
  const fastScore = calculateScore(fastChecks);
  const fastGrade = scoreToGrade(fastScore);

  // =========================================================================
  // DEEP MODE — Puppeteer fallback (auto-triggered if needed)
  // =========================================================================

  let scanMode: ScanMode = "fast";
  let finalChecks = fastChecks;
  let deepScanResolved = 0;
  let deepScanReasons: string[] = [];

  // Evaluate whether deep scan is needed
  const trigger = shouldTriggerDeepScan({
    checks: fastChecks.map((c) => ({ id: c.id, status: c.status })),
    privacyPolicyUrl,
    privacySpaDetected: crawlResult.privacySpaDetected,
    mainPageHtml: mainPage.html,
    privacyPageHtml: privacyPage?.html ?? null,
  });

  // Only attempt deep scan if:
  // - Trigger conditions met
  // - Not on Vercel (serverless)
  // - We still have time budget
  const timeRemaining = deadline - Date.now();
  const canDeepScan =
    trigger.shouldTrigger &&
    !isVercelEnvironment() &&
    timeRemaining > 10_000; // Need at least 10s for Puppeteer

  if (canDeepScan) {
    deepScanReasons = trigger.reasons;

    try {
      // Deep scan the main page
      const deepMain = await fetchWithBrowser(normalizedUrl);

      if (deepMain.success && deepMain.html.length > 0) {
        // Build updated main page from rendered content
        const deepMainPage: FetchedPage = {
          url: normalizedUrl,
          html: deepMain.html,
          headers: mainPage.headers,
          cookies: mainPage.cookies,
          statusCode: 200,
        };

        // Try to find privacy policy from rendered links
        let deepPrivacyPage: FetchedPage | null = privacyPage;
        let deepPrivacyUrl = privacyPolicyUrl;

        // If we didn't find a privacy page in fast mode, search rendered links
        if (!deepPrivacyUrl) {
          const privacyPatterns = [
            /privacy/i, /data-protection/i, /dpdp/i, /gdpr/i,
            /personal-data/i, /cookie-policy/i,
          ];
          const foundPrivacyLink = deepMain.links.find((link) =>
            privacyPatterns.some((p) => p.test(link))
          );
          if (foundPrivacyLink) {
            deepPrivacyUrl = foundPrivacyLink;
          }
        }

        // If we have a privacy URL (found or pre-existing), render it with Puppeteer
        if (deepPrivacyUrl && (!privacyPage || privacyPage.html.length < 1000)) {
          const deepPrivacy = await fetchPageWithBrowser(deepPrivacyUrl);
          if (deepPrivacy.success && deepPrivacy.html.length > 0) {
            const text = deepPrivacy.html.toLowerCase();
            const hasContent = PRIVACY_KEYWORDS.some((kw) => text.includes(kw));
            if (hasContent) {
              deepPrivacyPage = {
                url: deepPrivacyUrl,
                html: deepPrivacy.html,
                headers: new Headers(),
                cookies: [],
                statusCode: 200,
              };
            }
          }
        }

        // Update crawl result with any new links from rendered DOM
        const existingHrefs = new Set(crawlResult.allLinks.map((l) => l.href));
        const newLinks = deepMain.links
          .filter((href) => !existingHrefs.has(href))
          .map((href) => ({ href, text: "", source: "page" as const }));

        const updatedCrawl: CrawlResult = {
          ...crawlResult,
          allLinks: [...crawlResult.allLinks, ...newLinks],
          privacyPolicyUrl: deepPrivacyUrl || crawlResult.privacyPolicyUrl,
        };

        // Build deep scan context
        const deepCtx: ScanContext = {
          mainPage: deepMainPage,
          privacyPage: deepPrivacyPage,
          privacyPolicyUrl: deepPrivacyUrl || privacyPolicyUrl,
          crawl: updatedCrawl,
          privacyEmbeddedIn,
          siteBlocked: false, // Puppeteer bypasses WAF
          privacySpaDetected: false, // Puppeteer renders JS
        };

        // Re-run checks with rendered content
        const deepChecks = await runAllChecks(deepCtx);

        // Merge: keep fast passes, upgrade failed/skipped with deep results
        const { merged, resolved } = mergeResults(fastChecks, deepChecks);
        finalChecks = merged;
        deepScanResolved = resolved;
        scanMode = "fast+deep";

        // Update privacy URL if deep scan found one
        if (deepPrivacyUrl && !privacyPolicyUrl) {
          privacyPolicyUrl = deepPrivacyUrl;
        }
      }
    } catch {
      // Deep scan failed — use fast scan results as-is
      scanMode = "fast";
    }
  }

  // =========================================================================
  // BUILD FINAL REPORT
  // =========================================================================

  const score = calculateScore(finalChecks);
  const grade = scoreToGrade(score);

  // Build blocked/SPA message
  let blockedMessage: string | null = null;

  if (scanMode === "fast+deep") {
    // Deep scan ran — no need for SPA/blocked warnings (it handled them)
    if (deepScanResolved > 0) {
      blockedMessage = null; // Clean result, no warning needed
    }
  } else if (isVercelEnvironment() && trigger.shouldTrigger) {
    // On Vercel, deep scan couldn't run — show helpful message
    blockedMessage =
      "Some checks could not complete because this site uses JavaScript rendering. Deep scan available on our full platform.";
  } else if (crawlResult.privacySpaDetected && privacyPolicyUrl) {
    blockedMessage = `This website uses JavaScript rendering (single-page application). Privacy policy page was found at ${privacyPolicyUrl} but its content could not be fully analyzed because it loads dynamically. Some content checks were skipped. For a complete scan, use the manual paste scanner. Score is based on analyzable checks only.`;
  } else if (siteBlocked) {
    if (privacyPolicyUrl) {
      blockedMessage = `This website has bot protection that limited automated scanning. Privacy policy was found at ${privacyPolicyUrl}. Some checks were skipped due to site restrictions. Score is based on scannable checks only.`;
    } else {
      blockedMessage = `This website has bot protection (Cloudflare, Akamai, or similar WAF) that prevents automated scanning. This does NOT mean they lack a privacy policy. We recommend manually checking ${domain}/privacy or ${domain}/policies. Score is calculated based on scannable checks only.`;
    }
  }

  return {
    url: normalizedUrl,
    scannedAt: new Date().toISOString(),
    score,
    grade,
    privacyPolicyUrl,
    checks: finalChecks,
    summary: summarizeResults(finalChecks),
    siteBlocked: scanMode === "fast+deep" ? false : siteBlocked,
    blockedMessage,
    privacyDetectionMethod: crawlResult.privacyDetectionMethod,
    scanMode,
    deepScanResolved: scanMode === "fast+deep" ? deepScanResolved : undefined,
    deepScanReasons: deepScanReasons.length > 0 ? deepScanReasons : undefined,
  };
}

/**
 * Scan from user-pasted HTML (Layer 6 — manual paste fallback).
 *
 * This is the 100% guaranteed fallback that works on ANY website
 * regardless of bot protection, since the user's browser fetched the page.
 */
export async function scanFromHtml(
  url: string,
  pastedHtml: string
): Promise<ScanReport> {
  // Validate URL
  let normalizedUrl: string;
  try {
    const parsed = new URL(url);
    if (!["http:", "https:"].includes(parsed.protocol)) {
      throw new Error("Invalid protocol");
    }
    normalizedUrl = parsed.href;
  } catch {
    throw new Error(
      `Invalid URL: "${url}". Please provide a valid HTTP or HTTPS URL.`
    );
  }

  // Determine if the pasted HTML looks like a privacy policy page
  const PRIVACY_CONTENT_TERMS = [
    "personal data", "collect", "process", "consent", "data protection",
    "privacy", "information we collect", "third party", "cookies",
    "data principal", "data fiduciary",
  ];
  const text = stripHtml(pastedHtml).toLowerCase();
  let matchCount = 0;
  for (const term of PRIVACY_CONTENT_TERMS) {
    if (text.includes(term)) matchCount++;
  }
  const isPrivacyPage = matchCount >= 3;

  // Build a FetchedPage from the pasted HTML
  const mainPage: FetchedPage = {
    url: normalizedUrl,
    html: pastedHtml,
    headers: new Headers(),
    cookies: [],
    statusCode: 200,
  };

  // If the pasted HTML is a privacy page, use it as both main and privacy page
  const privacyPage = isPrivacyPage ? mainPage : null;
  const privacyPolicyUrl = isPrivacyPage ? normalizedUrl : null;

  // Build a minimal crawl result from the pasted HTML
  const crawlResult: CrawlResult = {
    allLinks: [],
    privacyLinks: [],
    consentLinks: [],
    rightsLinks: [],
    grievanceLinks: [],
    retentionLinks: [],
    legalLinks: [],
    fetchedPages: new Map([[normalizeUrl(normalizedUrl), mainPage]]),
    privacyPolicyUrl,
    privacyDetectionMethod: "manual-paste",
    privacyEmbeddedIn: null,
    siteBlocked: false,
    privacySpaDetected: false,
    spaDetectedPages: new Map(),
  };

  const ctx: ScanContext = {
    mainPage,
    privacyPage,
    privacyPolicyUrl,
    crawl: crawlResult,
    privacyEmbeddedIn: null,
    siteBlocked: false, // Manual paste bypasses all blocking
    privacySpaDetected: false,
  };

  // Run all check modules
  const allChecks = await runAllChecks(ctx);

  const score = calculateScore(allChecks);
  const grade = scoreToGrade(score);

  return {
    url: normalizedUrl,
    scannedAt: new Date().toISOString(),
    score,
    grade,
    privacyPolicyUrl,
    checks: allChecks,
    summary: summarizeResults(allChecks),
    siteBlocked: false,
    blockedMessage: null,
    privacyDetectionMethod: "manual-paste",
    scanMode: "fast",
  };
}
