import { CheckResult, CheckSeverity, Grade } from "./types";

const SEVERITY_PENALTY: Record<CheckSeverity, number> = {
  CRITICAL: 8,
  HIGH: 5,
  MEDIUM: 3,
  INFO: 0,
};

/**
 * Calculate compliance score from check results.
 *
 * Only counts checks that actually ran (PASS or FAIL).
 * SKIP and INFO checks are excluded from the denominator so that
 * sites blocked by WAFs aren't unfairly penalized.
 *
 * Algorithm:
 * - Start at 100
 * - For each FAIL result, subtract penalty based on severity
 * - Scale the total penalty relative to the number of checks that ran
 * - Minimum score is 0
 */
export function calculateScore(checks: CheckResult[]): number {
  const runnableChecks = checks.filter(
    (c) => c.status === "PASS" || c.status === "FAIL"
  );

  // If no checks ran, return 0
  if (runnableChecks.length === 0) return 0;

  // Calculate max possible penalty (all runnable checks failing)
  const maxPenalty = runnableChecks.reduce(
    (sum, c) => sum + SEVERITY_PENALTY[c.severity],
    0
  );

  // Calculate actual penalty from failures
  const actualPenalty = runnableChecks
    .filter((c) => c.status === "FAIL")
    .reduce((sum, c) => sum + SEVERITY_PENALTY[c.severity], 0);

  if (maxPenalty === 0) return 100;

  // Score as percentage of non-penalized checks
  const score = Math.round(((maxPenalty - actualPenalty) / maxPenalty) * 100);
  return Math.max(0, Math.min(100, score));
}

/**
 * Convert numeric score to letter grade.
 */
export function scoreToGrade(score: number): Grade {
  if (score >= 90) return "A";
  if (score >= 75) return "B";
  if (score >= 50) return "C";
  if (score >= 25) return "D";
  return "F";
}

/**
 * Summarize check results.
 */
export function summarizeResults(checks: CheckResult[]) {
  return {
    total: checks.length,
    passed: checks.filter((c) => c.status === "PASS").length,
    failed: checks.filter((c) => c.status === "FAIL").length,
    skipped: checks.filter((c) => c.status === "SKIP").length,
    info: checks.filter((c) => c.status === "INFO").length,
  };
}
