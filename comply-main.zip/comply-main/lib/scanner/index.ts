export { scanWebsite } from "./engine";
export type {
  ScanReport,
  CheckResult,
  CheckSeverity,
  CheckStatus,
  Grade,
  FetchedPage,
  ScanContext,
} from "./types";
export type { ScanMode, DeepScanResult, DeepScanTrigger } from "./deepScan";
