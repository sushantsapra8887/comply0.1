/**
 * Deep Scan Module — Puppeteer-based fallback for JavaScript-rendered websites.
 *
 * Only used when the fast (HTTP-fetch) scanner detects SPA/JS-rendered content
 * that can't be analyzed with simple HTML parsing.
 *
 * Safety:
 * - Mutex ensures only ONE browser instance runs at a time
 * - Hard 30-second timeout per navigation
 * - Always closes browser in finally block
 * - Skipped entirely on Vercel (serverless doesn't support Puppeteer)
 */

import type { Browser, Page } from "puppeteer";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface DeepScanResult {
  /** Fully rendered HTML of the page */
  html: string;
  /** All anchor hrefs found in the rendered DOM */
  links: string[];
  /** Whether the deep scan succeeded */
  success: boolean;
  /** Error message if scan failed */
  error?: string;
}

export type ScanMode = "fast" | "deep" | "fast+deep";

// ---------------------------------------------------------------------------
// Mutex — prevent concurrent browser launches eating all memory
// ---------------------------------------------------------------------------

let browserLock: Promise<void> = Promise.resolve();

function acquireLock(): { release: () => void; ready: Promise<void> } {
  let release: () => void;
  const next = new Promise<void>((resolve) => {
    release = resolve;
  });
  const ready = browserLock;
  browserLock = next;
  return { release: release!, ready };
}

// ---------------------------------------------------------------------------
// Environment check
// ---------------------------------------------------------------------------

/** Returns true when running on Vercel serverless (Puppeteer not available). */
export function isVercelEnvironment(): boolean {
  return !!(process.env.VERCEL || process.env.VERCEL_ENV);
}

// ---------------------------------------------------------------------------
// Chromium path resolution
// ---------------------------------------------------------------------------

/**
 * Try to locate a usable Chromium/Chrome binary.
 * Order: PUPPETEER_EXECUTABLE_PATH env → common Linux paths → null.
 */
async function findChromePath(): Promise<string | null> {
  if (process.env.PUPPETEER_EXECUTABLE_PATH) {
    return process.env.PUPPETEER_EXECUTABLE_PATH;
  }

  const { execSync } = await import("child_process");
  const candidates = [
    "google-chrome-stable",
    "google-chrome",
    "chromium-browser",
    "chromium",
  ];
  for (const bin of candidates) {
    try {
      const path = execSync(`which ${bin} 2>/dev/null`).toString().trim();
      if (path) return path;
    } catch {
      // not found, try next
    }
  }
  return null;
}

// ---------------------------------------------------------------------------
// Core: fetch a page with headless Chrome
// ---------------------------------------------------------------------------

const BROWSER_TIMEOUT = 30_000; // 30 seconds hard limit per navigation
const EXTRA_WAIT = 3_000; // Wait after networkidle for JS rendering

/**
 * Launch headless Chrome, navigate to `url`, wait for full render,
 * and return the rendered HTML plus all discovered links.
 */
export async function fetchWithBrowser(url: string): Promise<DeepScanResult> {
  // Block on Vercel
  if (isVercelEnvironment()) {
    return {
      html: "",
      links: [],
      success: false,
      error: "Deep scan not available on Vercel serverless.",
    };
  }

  const chromePath = await findChromePath();
  if (!chromePath) {
    return {
      html: "",
      links: [],
      success: false,
      error: "No Chrome/Chromium binary found. Set PUPPETEER_EXECUTABLE_PATH.",
    };
  }

  // Acquire mutex — only one browser at a time
  const lock = acquireLock();
  await lock.ready;

  let browser: Browser | null = null;
  try {
    const puppeteer = await import("puppeteer");
    browser = await puppeteer.default.launch({
      executablePath: chromePath,
      headless: true,
      args: [
        "--no-sandbox",
        "--disable-setuid-sandbox",
        "--disable-dev-shm-usage",
        "--disable-gpu",
        "--disable-extensions",
        "--disable-background-networking",
        "--single-process",
      ],
      timeout: BROWSER_TIMEOUT,
    });

    const page: Page = await browser.newPage();

    // Set a realistic user-agent
    await page.setUserAgent(
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    );
    await page.setViewport({ width: 1440, height: 900 });

    // Navigate with networkidle2 (at most 2 open connections for 500ms)
    await page.goto(url, {
      waitUntil: "networkidle2",
      timeout: BROWSER_TIMEOUT,
    });

    // Extra wait for late JS rendering (React hydration, etc.)
    await new Promise((r) => setTimeout(r, EXTRA_WAIT));

    // Extract rendered HTML
    const html = await page.content();

    // Extract all anchor links from the rendered DOM
    const links: string[] = await page.evaluate(() => {
      const anchors = Array.from(document.querySelectorAll("a[href]"));
      return anchors
        .map((a) => {
          try {
            return new URL(
              (a as HTMLAnchorElement).href,
              window.location.href
            ).href;
          } catch {
            return "";
          }
        })
        .filter(Boolean);
    });

    await page.close();

    return { html, links, success: true };
  } catch (err) {
    return {
      html: "",
      links: [],
      success: false,
      error: err instanceof Error ? err.message : "Browser launch failed",
    };
  } finally {
    if (browser) {
      try {
        await browser.close();
      } catch {
        // Already closed or crashed — safe to ignore
      }
    }
    lock.release();
  }
}

/**
 * Navigate to a specific page (e.g. privacy policy), wait for render,
 * and return the rendered HTML content.
 */
export async function fetchPageWithBrowser(
  url: string
): Promise<DeepScanResult> {
  return fetchWithBrowser(url);
}

// ---------------------------------------------------------------------------
// Deep scan trigger detection
// ---------------------------------------------------------------------------

export interface DeepScanTrigger {
  /** Whether deep scan should be triggered */
  shouldTrigger: boolean;
  /** Reasons why deep scan was triggered */
  reasons: string[];
}

/**
 * Evaluate fast scan results to determine if deep scan is needed.
 *
 * Conditions:
 * 1. Privacy policy URL found (HTTP 200) but content keywords not detected (SPA)
 * 2. More than 50% of checks are SKIPPED
 * 3. Privacy policy check FAILED despite finding a URL that looks like a privacy page
 * 4. Fetched HTML is very short (<1000 chars) suggesting SPA shell
 * 5. HTML contains React/Vue/Angular/Next.js indicators
 */
export function shouldTriggerDeepScan(opts: {
  checks: Array<{ id: string; status: string }>;
  privacyPolicyUrl: string | null;
  privacySpaDetected: boolean;
  mainPageHtml: string;
  privacyPageHtml: string | null;
}): DeepScanTrigger {
  const reasons: string[] = [];

  // Condition 1: SPA detected on privacy page
  if (opts.privacySpaDetected && opts.privacyPolicyUrl) {
    reasons.push(
      "Privacy policy page uses JavaScript rendering (SPA detected)"
    );
  }

  // Condition 2: More than 50% of checks skipped
  const total = opts.checks.length;
  const skipped = opts.checks.filter(
    (c) => c.status === "SKIP" || c.status === "skip"
  ).length;
  if (total > 0 && skipped / total > 0.5) {
    reasons.push(
      `${skipped}/${total} checks skipped — site may be blocking or SPA-rendered`
    );
  }

  // Condition 3: Privacy check FAILED despite having a URL that looks like privacy
  if (opts.privacyPolicyUrl) {
    const privacyCheck = opts.checks.find((c) => c.id === "SC01");
    if (
      privacyCheck &&
      (privacyCheck.status === "FAIL" || privacyCheck.status === "fail")
    ) {
      reasons.push(
        "Privacy policy URL found but check failed — content may need JS rendering"
      );
    }
  }

  // Condition 4: Main page HTML very short (SPA shell)
  const htmlLen = opts.mainPageHtml.length;
  if (htmlLen > 0 && htmlLen < 1000) {
    reasons.push(
      `Main page HTML is only ${htmlLen} characters — likely an SPA shell`
    );
  }

  // Condition 5: SPA framework indicators in HTML
  const spaIndicators = [
    '<div id="root"',
    '<div id="app"',
    '<div id="__next"',
    "__NEXT_DATA__",
    "__NUXT__",
    "bundle.js",
    "main.chunk.js",
    "app.bundle.js",
    "static/js/main.",
    "/_next/static",
    "ng-version",
    'data-reactroot',
  ];

  const htmlLower = opts.mainPageHtml.toLowerCase();
  const matchedIndicators = spaIndicators.filter((ind) =>
    htmlLower.includes(ind.toLowerCase())
  );
  if (matchedIndicators.length > 0) {
    // Only trigger if the page is also short or checks are failing
    // (Many modern sites use React but still have SSR content)
    const failedOrSkipped = opts.checks.filter(
      (c) =>
        c.status === "FAIL" ||
        c.status === "fail" ||
        c.status === "SKIP" ||
        c.status === "skip"
    ).length;
    if (failedOrSkipped > total * 0.3) {
      reasons.push(
        `SPA framework detected (${matchedIndicators.slice(0, 3).join(", ")}) with ${failedOrSkipped} failed/skipped checks`
      );
    }
  }

  // Also check privacy page HTML if it's very short
  if (opts.privacyPageHtml !== null && opts.privacyPageHtml.length < 1000) {
    reasons.push(
      `Privacy page HTML is only ${opts.privacyPageHtml.length} characters — likely JS-rendered`
    );
  }

  return {
    shouldTrigger: reasons.length > 0,
    reasons,
  };
}
