export const FETCH_TIMEOUT = 30_000;

/** 5 different User-Agent strings to rotate through on retries. */
const USER_AGENTS = [
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
];

export const BROWSER_UA = USER_AGENTS[0];

/** Get browser-like headers, optionally with a specific UA and Referer. */
export function getBrowserHeaders(uaIndex = 0, referer?: string): Record<string, string> {
  const ua = USER_AGENTS[uaIndex % USER_AGENTS.length];
  const headers: Record<string, string> = {
    "User-Agent": ua,
    Accept:
      "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9,hi;q=0.8",
    "Accept-Encoding": "gzip, deflate, br",
    "Cache-Control": "no-cache",
    Connection: "keep-alive",
    DNT: "1",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Upgrade-Insecure-Requests": "1",
  };
  if (referer) {
    headers["Referer"] = referer;
    headers["Sec-Fetch-Site"] = "same-origin";
  }
  return headers;
}

/** Standard browser-like headers (default UA). */
export const BROWSER_HEADERS = getBrowserHeaders(0);

// ---------------------------------------------------------------------------
// Bot / WAF detection
// ---------------------------------------------------------------------------

/** Patterns in response body that indicate the request was blocked by a WAF. */
const BLOCKED_BODY_PATTERNS = [
  "access denied",
  "forbidden",
  "captcha",
  "challenge",
  "checking your browser",
  "cf-browser-verification",
  "attention required",
  "cloudflare",
  "just a moment",
  "please enable cookies",
  "ray id",
  "bot detection",
  "are you a robot",
  "ddos protection",
  "security check",
  "pardon our interruption",
  "please verify you are a human",
  "blocked your ip",
];

/**
 * Detect whether a response appears to be blocked by a WAF/bot protection.
 * Returns true if the response looks like a challenge page or block page.
 */
export function isBlockedResponse(html: string, statusCode: number): boolean {
  // 403/503 are classic WAF block codes
  if (statusCode === 403 || statusCode === 503) return true;

  // Very short body is suspicious (challenge pages are typically small)
  if (html.length < 500) {
    const lower = html.toLowerCase();
    return BLOCKED_BODY_PATTERNS.some((p) => lower.includes(p));
  }

  // Check for Cloudflare challenge page markers even in longer responses
  const lower = html.toLowerCase();
  if (
    (lower.includes("checking your browser") && lower.includes("cloudflare")) ||
    lower.includes("cf-browser-verification") ||
    (lower.includes("just a moment") && lower.includes("enable javascript"))
  ) {
    return true;
  }

  return false;
}

// ---------------------------------------------------------------------------
// Soft-404 detection
// ---------------------------------------------------------------------------

const SOFT_404_PATTERNS = [
  "page not found",
  "404 not found",
  "page doesn't exist",
  "page does not exist",
  "this page isn't available",
  "this page is not available",
  "we couldn't find",
  "we could not find",
  "sorry, we can't find",
  "the page you requested",
  "the page you are looking for",
  "no results found",
  "nothing found",
  "oops!",
  "error 404",
];

export function isSoft404(html: string): boolean {
  const text = stripHtml(html).toLowerCase();
  if (text.length < 2000) {
    return SOFT_404_PATTERNS.some((p) => text.includes(p));
  }
  const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  if (titleMatch) {
    const title = titleMatch[1].toLowerCase();
    if (
      title.includes("404") ||
      title.includes("not found") ||
      title.includes("page not found")
    ) {
      return true;
    }
  }
  return false;
}

// ---------------------------------------------------------------------------
// Core fetch with UA rotation and retry
// ---------------------------------------------------------------------------

/**
 * Fetch a page with bot-protection handling:
 * 1. Try with default UA
 * 2. If 403/blocked, retry with rotated UA + Referer
 * 3. If still blocked, try www/non-www alternate
 *
 * Returns the result plus a `blocked` flag.
 */
export async function fetchPage(url: string): Promise<{
  html: string;
  headers: Headers;
  cookies: string[];
  statusCode: number;
  blocked: boolean;
}> {
  const origin = new URL(url).origin;

  // Attempt 1: default headers
  let result = await rawFetch(url, getBrowserHeaders(0));
  if (!isBlockedResponse(result.html, result.statusCode)) {
    return { ...result, blocked: false };
  }

  // Attempt 2: rotated UA + Referer
  result = await rawFetch(url, getBrowserHeaders(1, origin + "/"));
  if (!isBlockedResponse(result.html, result.statusCode)) {
    return { ...result, blocked: false };
  }

  // Attempt 3: another UA
  result = await rawFetch(url, getBrowserHeaders(2, origin + "/"));
  if (!isBlockedResponse(result.html, result.statusCode)) {
    return { ...result, blocked: false };
  }

  // Attempt 4: try www/non-www alternate
  const altUrl = tryAlternateUrl(url);
  if (altUrl) {
    result = await rawFetch(altUrl, getBrowserHeaders(3, new URL(altUrl).origin + "/"));
    if (!isBlockedResponse(result.html, result.statusCode)) {
      return { ...result, blocked: false };
    }
  }

  // All attempts blocked — return last result with blocked flag
  return { ...result, blocked: true };
}

async function rawFetch(url: string, headers: Record<string, string>): Promise<{
  html: string;
  headers: Headers;
  cookies: string[];
  statusCode: number;
}> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      redirect: "follow",
      headers,
    });
    const html = await res.text();
    const cookies = res.headers.getSetCookie?.() ?? [];
    return { html, headers: res.headers, cookies, statusCode: res.status };
  } catch {
    return { html: "", headers: new Headers(), cookies: [], statusCode: 0 };
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Try to construct an alternate URL by toggling www prefix.
 */
export function tryAlternateUrl(url: string): string | null {
  try {
    const parsed = new URL(url);
    if (parsed.hostname.startsWith("www.")) {
      parsed.hostname = parsed.hostname.slice(4);
    } else {
      parsed.hostname = "www." + parsed.hostname;
    }
    return parsed.href;
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// Probe URL (full fetch with soft-404 + WAF detection)
// ---------------------------------------------------------------------------

export async function probeUrlFull(url: string): Promise<{
  html: string;
  statusCode: number;
  blocked: boolean;
} | null> {
  const result = await fetchPage(url);
  if (result.blocked) return { html: result.html, statusCode: result.statusCode, blocked: true };
  if (result.statusCode === 0) return null; // network error
  if (result.statusCode >= 400) return null;
  if (isSoft404(result.html)) return null;
  return { html: result.html, statusCode: result.statusCode, blocked: false };
}

export async function probeUrl(url: string): Promise<boolean> {
  const result = await probeUrlFull(url);
  return result !== null && !result.blocked;
}

export async function hasPrivacyContent(url: string): Promise<boolean> {
  try {
    const result = await fetchPage(url);
    if (result.blocked) return false;
    const text = stripHtml(result.html).toLowerCase();
    const keywords = [
      "privacy",
      "personal data",
      "data protection",
      "data we collect",
      "information we collect",
      "data principal",
      "your rights",
    ];
    return keywords.some((kw) => text.includes(kw));
  } catch {
    return false;
  }
}

// ---------------------------------------------------------------------------
// CORS Proxy fetch (for WAF-blocked sites)
// ---------------------------------------------------------------------------

/**
 * Fetch a URL via multiple CORS proxy services.
 * Tries allorigins.win first, then corsproxy.io as fallback.
 */
export async function fetchViaCorsProxy(url: string): Promise<{
  html: string;
  statusCode: number;
} | null> {
  // Try allorigins.win (JSON API)
  const result1 = await fetchViaAllOrigins(url);
  if (result1) return result1;

  // Try corsproxy.io (raw proxy)
  const result2 = await fetchViaCorsProxyIo(url);
  if (result2) return result2;

  return null;
}

async function fetchViaAllOrigins(url: string): Promise<{
  html: string;
  statusCode: number;
} | null> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT);
  try {
    const proxyUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(url)}`;
    const res = await fetch(proxyUrl, {
      signal: controller.signal,
      headers: { Accept: "application/json" },
    });
    if (!res.ok) return null;
    const data = await res.json();
    if (data && data.contents) {
      return { html: data.contents, statusCode: data.status?.http_code ?? 200 };
    }
    return null;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

async function fetchViaCorsProxyIo(url: string): Promise<{
  html: string;
  statusCode: number;
} | null> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT);
  try {
    const proxyUrl = `https://corsproxy.io/?${encodeURIComponent(url)}`;
    const res = await fetch(proxyUrl, {
      signal: controller.signal,
      redirect: "follow",
    });
    if (!res.ok) return null;
    const html = await res.text();
    if (!html || html.length < 100) return null;
    return { html, statusCode: res.status };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

// ---------------------------------------------------------------------------
// Google Cache fetch
// ---------------------------------------------------------------------------

/**
 * Try to fetch a page from search engine web caches.
 * Tries Google Cache first, then Bing Cache.
 * These cached pages are never behind Cloudflare/Akamai.
 */
export async function fetchFromWebCache(domain: string, query: string): Promise<{
  html: string;
  source: "google-cache" | "bing-cache";
} | null> {
  // Try Google Cache
  const googleResult = await fetchFromGoogleCache(domain, query);
  if (googleResult) return { html: googleResult.html, source: "google-cache" };

  // Try Bing Cache
  const bingResult = await fetchFromBingCache(domain, query);
  if (bingResult) return { html: bingResult.html, source: "bing-cache" };

  return null;
}

/**
 * Try to fetch a page from Google's web cache.
 */
export async function fetchFromGoogleCache(domain: string, query: string): Promise<{
  html: string;
} | null> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT);
  try {
    const cacheUrl = `https://webcache.googleusercontent.com/search?q=cache:${encodeURIComponent(domain)}+${encodeURIComponent(query)}`;
    const res = await fetch(cacheUrl, {
      signal: controller.signal,
      redirect: "follow",
      headers: getBrowserHeaders(0),
    });
    if (!res.ok) return null;
    const html = await res.text();
    if (isSoft404(html) || html.length < 500) return null;
    return { html };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Try to fetch a page from Bing's web cache.
 */
export async function fetchFromBingCache(domain: string, query: string): Promise<{
  html: string;
} | null> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT);
  try {
    const cacheUrl = `https://cc.bingj.com/cache.aspx?q=${encodeURIComponent(domain)}+${encodeURIComponent(query)}`;
    const res = await fetch(cacheUrl, {
      signal: controller.signal,
      redirect: "follow",
      headers: getBrowserHeaders(1),
    });
    if (!res.ok) return null;
    const html = await res.text();
    if (isSoft404(html) || html.length < 500) return null;
    return { html };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

// ---------------------------------------------------------------------------
// Robots.txt / Sitemap parsing
// ---------------------------------------------------------------------------

/**
 * Fetch and parse robots.txt to find sitemap URLs.
 */
export async function fetchSitemapUrlsFromRobotsTxt(origin: string): Promise<string[]> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15_000);
  try {
    const res = await fetch(`${origin}/robots.txt`, {
      signal: controller.signal,
      redirect: "follow",
      headers: { "User-Agent": BROWSER_UA },
    });
    if (!res.ok) return [];
    const text = await res.text();
    const sitemapUrls: string[] = [];
    const lines = text.split("\n");
    for (const line of lines) {
      const match = line.match(/^\s*Sitemap\s*:\s*(.+)/i);
      if (match) {
        sitemapUrls.push(match[1].trim());
      }
    }
    return sitemapUrls;
  } catch {
    return [];
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Fetch a sitemap (XML) and extract all <loc> URLs.
 * Handles nested sitemaps (sitemap index files) up to 1 level deep.
 */
export async function parseSitemap(sitemapUrl: string, depth = 0): Promise<string[]> {
  if (depth > 1) return []; // Don't recurse more than 1 level

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15_000);
  try {
    const res = await fetch(sitemapUrl, {
      signal: controller.signal,
      redirect: "follow",
      headers: { "User-Agent": BROWSER_UA },
    });
    if (!res.ok) return [];
    const xml = await res.text();

    const urls: string[] = [];

    // Check if it's a sitemap index (contains <sitemapindex>)
    if (xml.includes("<sitemapindex")) {
      const locRegex = /<loc>\s*(.*?)\s*<\/loc>/gi;
      let m: RegExpExecArray | null;
      const childSitemaps: string[] = [];
      while ((m = locRegex.exec(xml)) !== null) {
        childSitemaps.push(m[1]);
      }
      // Fetch child sitemaps in parallel (max 5)
      const children = await Promise.all(
        childSitemaps.slice(0, 5).map((s) => parseSitemap(s, depth + 1))
      );
      for (const child of children) {
        urls.push(...child);
      }
    } else {
      const locRegex = /<loc>\s*(.*?)\s*<\/loc>/gi;
      let m: RegExpExecArray | null;
      while ((m = locRegex.exec(xml)) !== null) {
        urls.push(m[1]);
      }
    }

    return urls;
  } catch {
    return [];
  } finally {
    clearTimeout(timer);
  }
}

// ---------------------------------------------------------------------------
// HTML utility functions (unchanged)
// ---------------------------------------------------------------------------

export function extractLinks(html: string, baseUrl: string): string[] {
  const linkRegex = /<a\s[^>]*href\s*=\s*["']([^"']+)["'][^>]*>/gi;
  const links: string[] = [];
  let match: RegExpExecArray | null;
  while ((match = linkRegex.exec(html)) !== null) {
    try {
      const absolute = new URL(match[1], baseUrl).href;
      links.push(absolute);
    } catch {
      // skip invalid URLs
    }
  }
  return links;
}

export function extractLinksWithText(
  html: string,
  baseUrl: string
): { href: string; text: string }[] {
  const linkRegex =
    /<a\s[^>]*href\s*=\s*["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
  const links: { href: string; text: string }[] = [];
  let match: RegExpExecArray | null;
  while ((match = linkRegex.exec(html)) !== null) {
    try {
      const href = new URL(match[1], baseUrl).href;
      const text = match[2].replace(/<[^>]+>/g, "").trim();
      links.push({ href, text });
    } catch {
      // skip invalid URLs
    }
  }
  return links;
}

export function containsAny(text: string, keywords: string[]): boolean {
  const lower = text.toLowerCase();
  return keywords.some((kw) => lower.includes(kw.toLowerCase()));
}

export function countMatches(text: string, keywords: string[]): string[] {
  const lower = text.toLowerCase();
  return keywords.filter((kw) => lower.includes(kw.toLowerCase()));
}

export function stripHtml(html: string): string {
  return html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
}

export function findLinksMatching(
  html: string,
  baseUrl: string,
  keywords: string[]
): { href: string; text: string }[] {
  const allLinks = extractLinksWithText(html, baseUrl);
  return allLinks.filter(
    (link) =>
      containsAny(link.href, keywords) || containsAny(link.text, keywords)
  );
}

function extractNestedElement(
  html: string,
  tagName: string,
  startIndex: number
): string | null {
  let depth = 0;
  const openPattern = new RegExp(`<${tagName}[\\s>]`, "gi");
  const closePattern = new RegExp(`</${tagName}\\s*>`, "gi");
  const events: { pos: number; end: number; type: "open" | "close" }[] = [];
  openPattern.lastIndex = startIndex;
  let m: RegExpExecArray | null;
  while ((m = openPattern.exec(html)) !== null) {
    events.push({ pos: m.index, end: m.index + m[0].length, type: "open" });
  }
  closePattern.lastIndex = startIndex;
  while ((m = closePattern.exec(html)) !== null) {
    events.push({ pos: m.index, end: m.index + m[0].length, type: "close" });
  }
  events.sort((a, b) => a.pos - b.pos);
  for (const event of events) {
    if (event.type === "open") depth++;
    else depth--;
    if (depth === 0) {
      return html.slice(startIndex, event.end);
    }
  }
  return null;
}

export function extractFooterHtml(html: string): string {
  const parts: string[] = [];
  const footerTagRegex = /<footer[\s>]/gi;
  let m: RegExpExecArray | null;
  while ((m = footerTagRegex.exec(html)) !== null) {
    const block = extractNestedElement(html, "footer", m.index);
    if (block) parts.push(block);
  }
  const footerAttrRegex =
    /<(div|section|nav|aside)\s[^>]*(?:class|id|role)\s*=\s*["'][^"']*(?:footer|bottom-nav|site-info|colophon|site-footer|global-footer|page-footer)[^"']*["'][^>]*>/gi;
  while ((m = footerAttrRegex.exec(html)) !== null) {
    const tagName = m[1];
    const block = extractNestedElement(html, tagName, m.index);
    if (block) parts.push(block);
  }
  const ariaRegex =
    /<(div|section|footer|aside)\s[^>]*role\s*=\s*["']contentinfo["'][^>]*>/gi;
  while ((m = ariaRegex.exec(html)) !== null) {
    const tagName = m[1];
    const block = extractNestedElement(html, tagName, m.index);
    if (block) parts.push(block);
  }
  if (parts.length === 0) {
    const bodyMatch = html.match(/<body[\s>][\s\S]*<\/body>/i);
    if (bodyMatch) {
      const body = bodyMatch[0];
      const start = Math.floor(body.length * 0.8);
      parts.push(body.slice(start));
    }
  }
  return parts.join("\n");
}

export function extractUrlsFromScripts(
  html: string,
  baseUrl: string
): string[] {
  const urls: string[] = [];
  const seen = new Set<string>();
  const scriptRegex = /<script[\s>][\s\S]*?<\/script>/gi;
  let m: RegExpExecArray | null;
  while ((m = scriptRegex.exec(html)) !== null) {
    const scriptContent = m[0];
    const urlPatterns = [
      /["'](https?:\/\/[^"'\s<>]+)["']/gi,
      /["'](\/[a-z0-9][a-z0-9\-_/]*(?:privacy|data-protection|datenschutz|policy)[a-z0-9\-_/]*)["']/gi,
    ];
    for (const pattern of urlPatterns) {
      let urlMatch: RegExpExecArray | null;
      while ((urlMatch = pattern.exec(scriptContent)) !== null) {
        try {
          const absolute = new URL(urlMatch[1], baseUrl).href;
          if (!seen.has(absolute)) {
            seen.add(absolute);
            urls.push(absolute);
          }
        } catch {
          // skip
        }
      }
    }
  }
  return urls;
}

export function extractPrivacyUrlsFromRawHtml(
  html: string,
  baseUrl: string,
  privacyKeywords: string[]
): string[] {
  const urls: string[] = [];
  const seen = new Set<string>();
  const rawUrlRegex = /["']((?:https?:\/\/[^"'\s<>]+|\/[^"'\s<>]+))["']/gi;
  let m: RegExpExecArray | null;
  while ((m = rawUrlRegex.exec(html)) !== null) {
    const candidate = m[1];
    const lower = candidate.toLowerCase();
    const isPrivacyUrl = privacyKeywords.some(
      (kw) => lower.includes(`/${kw}`) || lower.includes(`=${kw}`)
    );
    if (!isPrivacyUrl) continue;
    if (/\.(js|css|png|jpg|gif|svg|woff|ico|json)(\?|$)/i.test(candidate)) continue;
    try {
      const absolute = new URL(candidate, baseUrl).href;
      if (!seen.has(absolute)) {
        seen.add(absolute);
        urls.push(absolute);
      }
    } catch {
      // skip
    }
  }
  return urls;
}

export function extractForms(html: string): {
  action: string;
  inputs: { type: string; name: string }[];
}[] {
  const formRegex =
    /<form\s[^>]*action\s*=\s*["']([^"']*)["'][^>]*>([\s\S]*?)<\/form>/gi;
  const forms: { action: string; inputs: { type: string; name: string }[] }[] = [];
  let match: RegExpExecArray | null;
  while ((match = formRegex.exec(html)) !== null) {
    const action = match[1] || "";
    const formHtml = match[2];
    const inputs: { type: string; name: string }[] = [];
    const inputRegex =
      /<input\s[^>]*(?:type\s*=\s*["']([^"']*)["'])?[^>]*(?:name\s*=\s*["']([^"']*)["'])?[^>]*>/gi;
    let inputMatch: RegExpExecArray | null;
    while ((inputMatch = inputRegex.exec(formHtml)) !== null) {
      inputs.push({ type: inputMatch[1] || "text", name: inputMatch[2] || "" });
    }
    forms.push({ action, inputs });
  }
  const formNoActionRegex =
    /<form(?:\s[^>]*)?>(?![\s\S]*action\s*=)([\s\S]*?)<\/form>/gi;
  while ((match = formNoActionRegex.exec(html)) !== null) {
    const formHtml = match[1];
    const inputs: { type: string; name: string }[] = [];
    const inputRegex =
      /<input\s[^>]*(?:type\s*=\s*["']([^"']*)["'])?[^>]*(?:name\s*=\s*["']([^"']*)["'])?[^>]*>/gi;
    let inputMatch: RegExpExecArray | null;
    while ((inputMatch = inputRegex.exec(formHtml)) !== null) {
      inputs.push({ type: inputMatch[1] || "text", name: inputMatch[2] || "" });
    }
    forms.push({ action: "", inputs });
  }
  return forms;
}
