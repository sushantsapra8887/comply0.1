import { FetchedPage } from "./types";
import {
  fetchPage,
  extractLinksWithText,
  containsAny,
  extractFooterHtml,
  extractUrlsFromScripts,
  extractPrivacyUrlsFromRawHtml,
  probeUrlFull,
  stripHtml,
  isSoft404,
  isBlockedResponse,
  BROWSER_UA,
  fetchViaCorsProxy,
  fetchFromWebCache,
  fetchSitemapUrlsFromRobotsTxt,
  parseSitemap,
  getBrowserHeaders,
  FETCH_TIMEOUT,
} from "./utils";

// ---------------------------------------------------------------------------
// Comprehensive URL keyword patterns (case-insensitive matching)
// ---------------------------------------------------------------------------

export const PRIVACY_URL_PATTERNS = [
  "privacy",
  "policy",
  "policies",
  "data-protection",
  "data-policy",
  "datapolicy",
  "datenschutz",
  "privacidad",
  "gizlilik",
  "confidentialite",
  "personal-data",
  "personal-information",
  "gdpr",
  "dpdp",
  "cookie-policy",
  "cookiepolicy",
  "terms-privacy",
  "legal/privacy",
  "legal-notice",
  "privacy-notice",
  "privacy-statement",
  "privacypolicy",
  "privacy_policy",
  "data_protection",
  "user-privacy",
  "consumer-privacy",
  "information-security",
  "data-handling",
  "your-privacy",
  "our-privacy",
  "about-privacy",
  "site-privacy",
  "app-privacy",
];

export const PRIVACY_TEXT_KEYWORDS = [
  "privacy",
  "privacy policy",
  "data protection",
  "personal data",
  "गोपनीयता",
  "निजता",
  "गोपनीयता नीति",
  "your data",
  "our policies",
  "legal notice",
  "privacy notice",
  "cookie policy",
  "data handling",
  "confidential",
  "policy",
];

const LEGAL_PAGE_URL_PATTERNS = [
  "terms",
  "legal",
  "policies",
  "conditions",
  "tos",
  "disclaimer",
];

const LEGAL_PAGE_TEXT_KEYWORDS = [
  "terms",
  "legal",
  "policies",
  "conditions",
  "disclaimer",
  "terms of use",
];

/** At least 3 of these must appear to confirm a privacy page. */
const PRIVACY_CONTENT_TERMS = [
  "personal data",
  "collect",
  "process",
  "consent",
  "data protection",
  "privacy",
  "information we",
  "third party",
  "cookies",
  "data principal",
  "data fiduciary",
  "information",
  "share",
];

// ---------------------------------------------------------------------------
// Brute-force probe paths for ALL content categories
// ---------------------------------------------------------------------------

/** Track 1: Privacy policy — the FIRST thing we try. */
const PRIVACY_PROBE_PATHS = [
  "/privacy-policy",
  "/privacy",
  "/privacypolicy",
  "/privacy.html",
  "/privacy.php",
  "/policies/privacy-policy",
  "/policies/privacy",
  "/policy/privacy",
  "/legal/privacy",
  "/legal/privacy-policy",
  "/en/privacy-policy",
  "/en/privacy",
  "/in/privacy-policy",
  "/pages/privacy-policy",
  "/page/privacy-policy",
  "/about/privacy",
  "/info/privacy",
  "/help/privacy",
  "/company/privacy",
  "/site/privacy-policy",
  "/privacy-notice",
  "/data-privacy",
  "/cookie-policy",
  "/terms-and-privacy",
  "/data-protection",
  "/app/privacy",
  "/privacy/policy",
  "/privacy-policy.html",
  "/privacy-notice.html",
  "/pages/privacy",
  "/en/legal/privacy",
  "/privacy-statement",
  "/our-privacy-policy",
  "/site/privacy",
  "/gdpr",
  "/dpdp",
  "/legal",
  "/policies",
  "/terms",
];

/** Brute-force paths for grievance/DPO/contact. */
const GRIEVANCE_PROBE_PATHS = [
  "/contact",
  "/contact-us",
  "/grievance",
  "/support",
  "/help",
  "/about/contact",
  "/about-us",
  "/company/contact",
  "/grievance-officer",
  "/dpo",
  "/redressal",
  "/complaints",
];

/** Brute-force paths for DSAR / data rights / deletion. */
const DSAR_PROBE_PATHS = [
  "/data-request",
  "/dsar",
  "/delete-account",
  "/your-data",
  "/data-rights",
  "/data-deletion",
  "/account-deletion",
  "/exercise-rights",
  "/subject-access",
  "/your-rights",
];

/** Brute-force paths for terms. */
const TERMS_PROBE_PATHS = [
  "/terms",
  "/terms-of-service",
  "/tos",
  "/terms-and-conditions",
  "/legal/terms",
  "/terms-of-use",
  "/conditions",
];

/** Phase C: subpaths to explore for links. */
const PHASE_C_SUBPATHS = [
  "/help",
  "/support",
  "/about",
  "/legal",
  "/info",
  "/company",
  "/about-us",
  "/contact",
  "/terms",
  "/policies",
];

// Other check category patterns
export const CONSENT_URL_PATTERNS = [
  "consent", "cookie", "cookies", "cookie-policy", "cookie-notice",
  "manage-cookies", "cookie-preferences", "opt-out", "preferences",
];
export const CONSENT_TEXT_KEYWORDS = [
  "consent", "cookie", "cookies", "cookie policy", "manage cookies",
  "opt out", "preferences",
];
export const RIGHTS_URL_PATTERNS = [
  "rights", "your-rights", "data-rights", "dsar", "data-request",
  "subject-access", "data-access", "data-deletion", "account-deletion",
  "delete-account", "delete-my-data", "exercise-rights",
];
export const RIGHTS_TEXT_KEYWORDS = [
  "your rights", "data rights", "data request", "access request",
  "delete my data", "exercise rights", "account deletion",
];
export const GRIEVANCE_URL_PATTERNS = [
  "grievance", "grievance-officer", "dpo", "data-protection-officer",
  "nodal-officer", "complaint", "complaints", "contact-dpo", "redressal",
];
export const GRIEVANCE_TEXT_KEYWORDS = [
  "grievance", "grievance officer", "data protection officer", "dpo",
  "nodal officer", "complaint", "redressal",
];
export const RETENTION_URL_PATTERNS = [
  "retention", "data-retention", "retention-policy", "how-long",
  "storage-policy", "data-storage",
];
export const RETENTION_TEXT_KEYWORDS = [
  "retention", "data retention", "how long", "storage policy",
  "deletion schedule",
];

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface CrawledLink {
  href: string;
  text: string;
  source: "page" | "footer" | "script" | "raw-html" | "meta" | "json-route" | "sitemap" | "probe" | "subpath" | "cors-proxy" | "google-cache" | "bing-cache" | "manual-paste";
}

export interface CrawlResult {
  allLinks: CrawledLink[];
  privacyLinks: CrawledLink[];
  consentLinks: CrawledLink[];
  rightsLinks: CrawledLink[];
  grievanceLinks: CrawledLink[];
  retentionLinks: CrawledLink[];
  legalLinks: CrawledLink[];
  fetchedPages: Map<string, FetchedPage>;
  privacyPolicyUrl: string | null;
  privacyDetectionMethod: string;
  privacyEmbeddedIn: string | null;
  siteBlocked: boolean;
  /** True if the privacy page was detected via SPA signals (URL match + page indicators) rather than rendered content. */
  privacySpaDetected: boolean;
  /** URLs detected as SPA pages (found at valid URL but content is JS-rendered). Maps URL to category. */
  spaDetectedPages: Map<string, { category: string; confidence: number }>;
}

// ---------------------------------------------------------------------------
// URL helpers
// ---------------------------------------------------------------------------

export function normalizeUrl(url: string): string {
  try {
    const parsed = new URL(url);
    parsed.protocol = "https:";
    let path = parsed.pathname;
    if (path.length > 1 && path.endsWith("/")) path = path.slice(0, -1);
    parsed.pathname = path;
    return parsed.href;
  } catch {
    return url;
  }
}

export function urlsMatch(url1: string, url2: string): boolean {
  try {
    const a = new URL(url1);
    const b = new URL(url2);
    const hostA = a.hostname.replace(/^www\./, "");
    const hostB = b.hostname.replace(/^www\./, "");
    const pathA = a.pathname.replace(/\/$/, "") || "/";
    const pathB = b.pathname.replace(/\/$/, "") || "/";
    return hostA === hostB && pathA === pathB;
  } catch {
    return false;
  }
}

function isSameSite(url: string, baseUrl: string): boolean {
  try {
    const a = new URL(url);
    const b = new URL(baseUrl);
    const hostA = a.hostname.replace(/^www\./, "");
    const hostB = b.hostname.replace(/^www\./, "");
    return hostA === hostB || a.hostname.endsWith(`.${hostB}`) || b.hostname.endsWith(`.${hostA}`);
  } catch {
    return false;
  }
}

function urlMatchesPatterns(href: string, patterns: string[]): boolean {
  const lower = href.toLowerCase();
  return patterns.some(
    (kw) =>
      lower.includes(`/${kw}`) ||
      lower.includes(`/${kw}/`) ||
      lower.includes(`=${kw}`) ||
      lower.includes(`-${kw}`) ||
      lower.includes(`_${kw}`) ||
      lower.endsWith(`/${kw}`) ||
      lower.endsWith(kw)
  );
}

function textMatchesKeywords(text: string, keywords: string[]): boolean {
  return containsAny(text, keywords);
}

// ---------------------------------------------------------------------------
// Content validation
// ---------------------------------------------------------------------------

function hasPrivacyContentInHtml(html: string): boolean {
  const text = stripHtml(html).toLowerCase();
  let matchCount = 0;
  for (const term of PRIVACY_CONTENT_TERMS) {
    if (text.includes(term.toLowerCase())) {
      matchCount++;
      if (matchCount >= 3) return true;
    }
  }
  return false;
}

// ---------------------------------------------------------------------------
// SPA detection — Fix 5: detect JS-rendered pages that exist but can't be read
// ---------------------------------------------------------------------------

/**
 * SPA page indicators that suggest a page is real even if content is JS-rendered.
 * Used when a URL returns HTTP 200 but hasPrivacyContentInHtml() fails.
 */
interface SpaPageSignals {
  /** The page <title> contains a relevant keyword */
  titleMatch: boolean;
  /** Meta description or OG tags contain a relevant keyword */
  metaMatch: boolean;
  /** __NEXT_DATA__, __INITIAL_STATE__, or similar embedded JSON contains relevant keywords */
  scriptDataMatch: boolean;
  /** <noscript> tags contain relevant links or content */
  noscriptMatch: boolean;
  /** The page HTML is structurally different from the homepage (not just the SPA shell) */
  distinctFromHomepage: boolean;
  /** The HTML contains SPA framework markers (React root, Vue app, Angular app, etc.) */
  isSpaFramework: boolean;
}

/** Keywords by page category for SPA detection. */
const SPA_CATEGORY_KEYWORDS: Record<string, string[]> = {
  privacy: ["privacy", "data protection", "personal data", "datenschutz", "privacidad", "cookie policy", "privacy policy"],
  terms: ["terms", "conditions", "terms of service", "terms of use", "legal", "disclaimer"],
  grievance: ["grievance", "contact", "support", "complaint", "dpo", "data protection officer"],
  dsar: ["data request", "data rights", "delete account", "your data", "access request", "data deletion"],
};

/**
 * Detect whether a fetched page is a real SPA page for a given category.
 * Returns signals that can be used to decide if the page should count as "found"
 * even though the rendered content isn't available.
 */
function detectSpaPage(
  html: string,
  category: string,
  homepageHtml?: string,
): { isSpaPage: boolean; signals: SpaPageSignals; confidence: number } {
  const keywords = SPA_CATEGORY_KEYWORDS[category] || SPA_CATEGORY_KEYWORDS.privacy;
  const lower = html.toLowerCase();

  // 1. Check <title> tag
  const titleMatch = (() => {
    const m = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
    if (!m) return false;
    const title = m[1].toLowerCase();
    return keywords.some((kw) => title.includes(kw));
  })();

  // 2. Check meta tags (description, og:title, og:description)
  const metaMatch = (() => {
    const metaPatterns = [
      /<meta\s[^>]*name\s*=\s*["']description["'][^>]*content\s*=\s*["']([^"']*)["'][^>]*>/gi,
      /<meta\s[^>]*content\s*=\s*["']([^"']*)["'][^>]*name\s*=\s*["']description["'][^>]*>/gi,
      /<meta\s[^>]*property\s*=\s*["']og:(?:title|description)["'][^>]*content\s*=\s*["']([^"']*)["'][^>]*>/gi,
      /<meta\s[^>]*content\s*=\s*["']([^"']*)["'][^>]*property\s*=\s*["']og:(?:title|description)["'][^>]*>/gi,
    ];
    for (const pattern of metaPatterns) {
      let m: RegExpExecArray | null;
      while ((m = pattern.exec(html)) !== null) {
        const content = m[1].toLowerCase();
        if (keywords.some((kw) => content.includes(kw))) return true;
      }
    }
    return false;
  })();

  // 3. Check script data (__NEXT_DATA__, __INITIAL_STATE__, application/json scripts)
  const scriptDataMatch = (() => {
    // Check __NEXT_DATA__
    const nextDataMatch = html.match(/<script\s+id\s*=\s*["']__NEXT_DATA__["'][^>]*>([\s\S]*?)<\/script>/i);
    if (nextDataMatch) {
      const data = nextDataMatch[1].toLowerCase();
      if (keywords.some((kw) => data.includes(kw))) return true;
    }
    // Check window.__INITIAL_STATE__ or window.__PRELOADED_STATE__ or window.__NUXT__
    const statePatterns = [
      /window\.__INITIAL_STATE__\s*=\s*({[\s\S]*?});?\s*(?:<\/script>|$)/i,
      /window\.__PRELOADED_STATE__\s*=\s*({[\s\S]*?});?\s*(?:<\/script>|$)/i,
      /window\.__NUXT__\s*=\s*({[\s\S]*?});?\s*(?:<\/script>|$)/i,
    ];
    for (const pattern of statePatterns) {
      const m = html.match(pattern);
      if (m) {
        const data = m[1].toLowerCase();
        if (keywords.some((kw) => data.includes(kw))) return true;
      }
    }
    // Check <script type="application/json"> or <script type="application/ld+json">
    const jsonScriptRegex = /<script\s[^>]*type\s*=\s*["']application\/(?:ld\+)?json["'][^>]*>([\s\S]*?)<\/script>/gi;
    let m: RegExpExecArray | null;
    while ((m = jsonScriptRegex.exec(html)) !== null) {
      const data = m[1].toLowerCase();
      if (keywords.some((kw) => data.includes(kw))) return true;
    }
    return false;
  })();

  // 4. Check <noscript> tags for relevant content/links
  const noscriptMatch = (() => {
    const noscriptRegex = /<noscript[^>]*>([\s\S]*?)<\/noscript>/gi;
    let m: RegExpExecArray | null;
    while ((m = noscriptRegex.exec(html)) !== null) {
      const content = m[1].toLowerCase();
      if (keywords.some((kw) => content.includes(kw))) return true;
    }
    return false;
  })();

  // 5. Check if page is structurally different from homepage
  const distinctFromHomepage = (() => {
    if (!homepageHtml) return false;
    // Compare content length — SPA shell pages are often same length as homepage
    const lengthDiff = Math.abs(html.length - homepageHtml.length);
    const lengthRatio = lengthDiff / Math.max(homepageHtml.length, 1);
    // If page is significantly different in size, it's likely a distinct page
    if (lengthRatio > 0.1) return true;
    // Compare title tags — different titles = different page
    const pageTitle = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]?.trim() || "";
    const homeTitle = homepageHtml.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]?.trim() || "";
    if (pageTitle && homeTitle && pageTitle !== homeTitle) return true;
    return false;
  })();

  // 6. Check for SPA framework markers
  const isSpaFramework =
    lower.includes("__next") ||
    lower.includes("__nuxt") ||
    lower.includes("id=\"root\"") ||
    lower.includes("id=\"app\"") ||
    lower.includes("id=\"__app\"") ||
    lower.includes("ng-app") ||
    lower.includes("ng-version") ||
    lower.includes("data-reactroot") ||
    lower.includes("data-react-helmet") ||
    lower.includes("_next/static") ||
    lower.includes("/_next/") ||
    lower.includes("/static/js/main") ||
    lower.includes("chunk.js") ||
    lower.includes("vue-app") ||
    lower.includes("data-v-") ||
    lower.includes("gatsby");

  const signals: SpaPageSignals = {
    titleMatch,
    metaMatch,
    scriptDataMatch,
    noscriptMatch,
    distinctFromHomepage,
    isSpaFramework,
  };

  // Calculate confidence score
  let confidence = 0;
  if (titleMatch) confidence += 35;
  if (metaMatch) confidence += 25;
  if (scriptDataMatch) confidence += 25;
  if (noscriptMatch) confidence += 15;
  if (distinctFromHomepage) confidence += 15;
  if (isSpaFramework) confidence += 10;

  // A page is considered a valid SPA page if:
  // - Title or meta matches the category (strong signal) OR
  // - Script data matches AND it's a known SPA framework OR
  // - Multiple weaker signals combine to high confidence
  const isSpaPage = confidence >= 35;

  return { isSpaPage, signals, confidence };
}

/**
 * Ultimate fallback: check if a probed page is distinct from the homepage.
 * If a privacy-pattern URL returned HTTP 200, is not a soft-404, not blocked,
 * and the HTML is meaningfully different from the homepage shell, then the page
 * almost certainly exists — even if we can't read its JS-rendered content.
 *
 * This catches the worst-case SPA: no title, no meta, no __NEXT_DATA__, but
 * the URL routes to a real view that will render after JS loads.
 */
function isDistinctPage(pageHtml: string, homepageHtml: string | undefined): boolean {
  if (!homepageHtml) return true; // Can't compare, assume distinct

  // Different content length (> 5% difference or > 500 bytes)
  const lengthDiff = Math.abs(pageHtml.length - homepageHtml.length);
  if (lengthDiff > 500) return true;
  const lengthRatio = lengthDiff / Math.max(homepageHtml.length, 1);
  if (lengthRatio > 0.05) return true;

  // Different <title> tags
  const pageTitle = pageHtml.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]?.trim() || "";
  const homeTitle = homepageHtml.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]?.trim() || "";
  if (pageTitle && homeTitle && pageTitle !== homeTitle) return true;

  // Different canonical URLs
  const pageCanonical = pageHtml.match(/<link[^>]*rel\s*=\s*["']canonical["'][^>]*href\s*=\s*["']([^"']*)["']/i)?.[1] || "";
  const homeCanonical = homepageHtml.match(/<link[^>]*rel\s*=\s*["']canonical["'][^>]*href\s*=\s*["']([^"']*)["']/i)?.[1] || "";
  if (pageCanonical && homeCanonical && pageCanonical !== homeCanonical) return true;

  // Different meta description
  const pageDesc = pageHtml.match(/<meta[^>]*name\s*=\s*["']description["'][^>]*content\s*=\s*["']([^"']*)["']/i)?.[1] || "";
  const homeDesc = homepageHtml.match(/<meta[^>]*name\s*=\s*["']description["'][^>]*content\s*=\s*["']([^"']*)["']/i)?.[1] || "";
  if (pageDesc && homeDesc && pageDesc !== homeDesc) return true;

  // Simple content hash comparison — if the body content differs at all
  // Extract just the inner body text (strip tags) and compare a hash-like fingerprint
  const pageBody = stripHtml(pageHtml).slice(0, 2000);
  const homeBody = stripHtml(homepageHtml).slice(0, 2000);
  if (pageBody !== homeBody) return true;

  return false;
}

// ---------------------------------------------------------------------------
// Enhanced HTML extraction — meta tags, link tags, JSON route data
// ---------------------------------------------------------------------------

/**
 * Extract URLs from <meta> tags (og:url, canonical) and <link> tags.
 */
function extractUrlsFromMetaAndLink(html: string, baseUrl: string): string[] {
  const urls: string[] = [];
  const seen = new Set<string>();

  // <link rel="canonical|alternate" href="...">
  const linkRegex = /<link\s[^>]*(?:rel\s*=\s*["'](?:canonical|alternate)[^"']*["'])[^>]*href\s*=\s*["']([^"']+)["'][^>]*>/gi;
  let m: RegExpExecArray | null;
  while ((m = linkRegex.exec(html)) !== null) {
    try {
      const abs = new URL(m[1], baseUrl).href;
      if (!seen.has(abs)) { seen.add(abs); urls.push(abs); }
    } catch { /* skip */ }
  }
  // Also match href before rel
  const linkRegex2 = /<link\s[^>]*href\s*=\s*["']([^"']+)["'][^>]*(?:rel\s*=\s*["'](?:canonical|alternate)[^"']*["'])[^>]*>/gi;
  while ((m = linkRegex2.exec(html)) !== null) {
    try {
      const abs = new URL(m[1], baseUrl).href;
      if (!seen.has(abs)) { seen.add(abs); urls.push(abs); }
    } catch { /* skip */ }
  }

  // <meta property="og:url" content="...">
  const metaRegex = /<meta\s[^>]*(?:property|name)\s*=\s*["'](?:og:url|og:see_also)[^"']*["'][^>]*content\s*=\s*["']([^"']+)["'][^>]*>/gi;
  while ((m = metaRegex.exec(html)) !== null) {
    try {
      const abs = new URL(m[1], baseUrl).href;
      if (!seen.has(abs)) { seen.add(abs); urls.push(abs); }
    } catch { /* skip */ }
  }

  return urls;
}

/**
 * Extract URLs from JSON route data embedded in <script> tags.
 * Next.js, React, Nuxt, Gatsby, etc. embed route/nav data as JSON.
 * Patterns: "href":"/privacy-policy", "path":"/privacy", "url":"/legal/privacy"
 */
function extractUrlsFromJsonRouteData(html: string, baseUrl: string): string[] {
  const urls: string[] = [];
  const seen = new Set<string>();

  const scriptRegex = /<script[\s>][\s\S]*?<\/script>/gi;
  let m: RegExpExecArray | null;
  while ((m = scriptRegex.exec(html)) !== null) {
    const scriptContent = m[0];

    // Match JSON-embedded route patterns:
    // "href":"/privacy-policy"  "path":"/privacy"  "url":"/legal/privacy"
    // "to":"/privacy"  "link":"/privacy"  "route":"/privacy"
    const jsonRoutePatterns = [
      /["'](?:href|path|url|to|link|route|slug)["']\s*:\s*["'](\/[^"'\s<>]+)["']/gi,
      // Also catch Next.js __NEXT_DATA__ style paths
      /["'](?:page|pathname|asPath|destination)["']\s*:\s*["'](\/[^"'\s<>]+)["']/gi,
    ];

    for (const pattern of jsonRoutePatterns) {
      let urlMatch: RegExpExecArray | null;
      while ((urlMatch = pattern.exec(scriptContent)) !== null) {
        const candidate = urlMatch[1];
        // Skip JS/CSS/image assets
        if (/\.(js|css|png|jpg|gif|svg|woff|ico|json|map)(\?|$)/i.test(candidate)) continue;
        // Skip API endpoints and internal framework paths
        if (/^\/(api|_next|__next|static|assets|webpack)\//i.test(candidate)) continue;
        try {
          const abs = new URL(candidate, baseUrl).href;
          if (!seen.has(abs)) { seen.add(abs); urls.push(abs); }
        } catch { /* skip */ }
      }
    }
  }

  return urls;
}

// ---------------------------------------------------------------------------
// Safe fetch helper
// ---------------------------------------------------------------------------

async function safeFetchPage(url: string, deadline: number): Promise<FetchedPage | null> {
  if (Date.now() > deadline) return null;
  try {
    const result = await fetchPage(url);
    if (result.blocked) return null;
    if (isSoft404(result.html)) return null;
    return {
      url,
      html: result.html,
      headers: result.headers,
      cookies: result.cookies,
      statusCode: result.statusCode,
    };
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// Track 1: Brute-force probe common URLs (PARALLEL batches)
// ---------------------------------------------------------------------------

interface ProbeResult {
  url: string;
  html: string;
  statusCode: number;
  category: "privacy" | "grievance" | "dsar" | "terms";
}

async function track1BruteForceProbe(
  origin: string,
  deadline: number
): Promise<{
  results: ProbeResult[];
  blockedCount: number;
  totalCount: number;
}> {
  const allPaths: { path: string; category: ProbeResult["category"] }[] = [];

  // Privacy paths are highest priority — add them first
  for (const p of PRIVACY_PROBE_PATHS) allPaths.push({ path: p, category: "privacy" });
  for (const p of GRIEVANCE_PROBE_PATHS) allPaths.push({ path: p, category: "grievance" });
  for (const p of DSAR_PROBE_PATHS) allPaths.push({ path: p, category: "dsar" });
  for (const p of TERMS_PROBE_PATHS) allPaths.push({ path: p, category: "terms" });

  // Deduplicate paths
  const seenPaths = new Set<string>();
  const uniquePaths = allPaths.filter((p) => {
    if (seenPaths.has(p.path)) return false;
    seenPaths.add(p.path);
    return true;
  });

  const results: ProbeResult[] = [];
  let blockedCount = 0;
  let totalCount = 0;
  const batchSize = 10;

  for (let i = 0; i < uniquePaths.length; i += batchSize) {
    if (Date.now() > deadline) break;

    const batch = uniquePaths.slice(i, i + batchSize);
    const batchResults = await Promise.all(
      batch.map(async ({ path, category }) => {
        const url = `${origin}${path}`;
        const result = await probeUrlFull(url);
        totalCount++;
        if (result?.blocked) blockedCount++;
        if (result && !result.blocked && result.statusCode >= 200 && result.statusCode < 400) {
          return { url, html: result.html, statusCode: result.statusCode, category };
        }
        return null;
      })
    );

    for (const r of batchResults) {
      if (r) results.push(r);
    }

    // For privacy: if we already found a confirmed privacy page, we can
    // continue with other categories but we have privacy covered
  }

  return { results, blockedCount, totalCount };
}

// ---------------------------------------------------------------------------
// Track 2: Parse homepage HTML for links
// ---------------------------------------------------------------------------

function track2ParseHtml(
  mainPageHtml: string,
  baseUrl: string
): CrawledLink[] {
  if (!mainPageHtml) return [];

  const links: CrawledLink[] = [];
  const seen = new Set<string>();

  function addIfNew(link: CrawledLink) {
    const norm = normalizeUrl(link.href);
    if (!seen.has(norm)) { seen.add(norm); links.push(link); }
  }

  // 1. Standard <a> tag links
  const pageLinks = extractLinksWithText(mainPageHtml, baseUrl);
  for (const link of pageLinks) {
    if (isSameSite(link.href, baseUrl)) {
      addIfNew({ href: link.href, text: link.text, source: "page" });
    }
  }

  // 2. Footer links (more targeted)
  const footerHtml = extractFooterHtml(mainPageHtml);
  if (footerHtml) {
    const footerLinks = extractLinksWithText(footerHtml, baseUrl);
    for (const link of footerLinks) {
      if (isSameSite(link.href, baseUrl)) {
        addIfNew({ href: link.href, text: link.text, source: "footer" });
      }
    }
  }

  // 3. URLs embedded in <script> tags (JS/JSON data)
  const scriptUrls = extractUrlsFromScripts(mainPageHtml, baseUrl);
  for (const url of scriptUrls) {
    if (isSameSite(url, baseUrl)) {
      addIfNew({ href: url, text: "", source: "script" });
    }
  }

  // 4. JSON route data in scripts (Next.js, React, Gatsby patterns)
  const jsonRouteUrls = extractUrlsFromJsonRouteData(mainPageHtml, baseUrl);
  for (const url of jsonRouteUrls) {
    if (isSameSite(url, baseUrl)) {
      addIfNew({ href: url, text: "", source: "json-route" });
    }
  }

  // 5. <meta> and <link> tags
  const metaUrls = extractUrlsFromMetaAndLink(mainPageHtml, baseUrl);
  for (const url of metaUrls) {
    if (isSameSite(url, baseUrl)) {
      addIfNew({ href: url, text: "", source: "meta" });
    }
  }

  // 6. Raw HTML patterns for privacy URLs
  const rawPrivacyUrls = extractPrivacyUrlsFromRawHtml(mainPageHtml, baseUrl, PRIVACY_URL_PATTERNS);
  for (const url of rawPrivacyUrls) {
    if (isSameSite(url, baseUrl)) {
      addIfNew({ href: url, text: "", source: "raw-html" });
    }
  }

  // 7. Extract links from <noscript> tags (SPA fallback content)
  const noscriptRegex = /<noscript[^>]*>([\s\S]*?)<\/noscript>/gi;
  let noscriptMatch: RegExpExecArray | null;
  while ((noscriptMatch = noscriptRegex.exec(mainPageHtml)) !== null) {
    const noscriptHtml = noscriptMatch[1];
    const noscriptLinks = extractLinksWithText(noscriptHtml, baseUrl);
    for (const link of noscriptLinks) {
      if (isSameSite(link.href, baseUrl)) {
        addIfNew({ href: link.href, text: link.text, source: "page" });
      }
    }
  }

  return links;
}

// ---------------------------------------------------------------------------
// Track 3: Sitemap
// ---------------------------------------------------------------------------

async function track3Sitemap(
  origin: string,
  baseUrl: string,
  deadline: number
): Promise<CrawledLink[]> {
  if (Date.now() > deadline) return [];

  const links: CrawledLink[] = [];
  const seen = new Set<string>();

  // Fetch robots.txt + default sitemaps in parallel
  const [sitemapUrls, ...defaultResults] = await Promise.all([
    fetchSitemapUrlsFromRobotsTxt(origin),
    parseSitemap(`${origin}/sitemap.xml`),
    parseSitemap(`${origin}/sitemap_index.xml`),
  ]);

  const allSitemapUrls = [...new Set([...sitemapUrls, `${origin}/sitemap.xml`, `${origin}/sitemap_index.xml`])];

  // Collect URLs from default sitemaps immediately
  const allPageUrls: string[] = [];
  for (const urls of defaultResults) {
    allPageUrls.push(...urls);
  }

  // Parse any additional sitemaps from robots.txt
  const additionalSitemaps = allSitemapUrls.filter(
    (s) => s !== `${origin}/sitemap.xml` && s !== `${origin}/sitemap_index.xml`
  );
  if (additionalSitemaps.length > 0 && Date.now() < deadline) {
    const moreResults = await Promise.all(
      additionalSitemaps.slice(0, 3).map((s) => parseSitemap(s))
    );
    for (const urls of moreResults) {
      allPageUrls.push(...urls);
    }
  }

  for (const loc of allPageUrls) {
    if (isSameSite(loc, baseUrl)) {
      const norm = normalizeUrl(loc);
      if (!seen.has(norm)) {
        seen.add(norm);
        links.push({ href: loc, text: "", source: "sitemap" });
      }
    }
  }

  return links;
}

// ---------------------------------------------------------------------------
// Main deep crawl — 3 tracks in PARALLEL
// ---------------------------------------------------------------------------

export async function deepCrawl(
  mainPageHtml: string,
  baseUrl: string,
  deadline: number,
  mainPageBlocked: boolean = false
): Promise<CrawlResult> {
  const origin = new URL(baseUrl).origin;
  const domain = new URL(baseUrl).hostname;
  const allLinks: CrawledLink[] = [];
  const seen = new Set<string>();
  const fetchedPages = new Map<string, FetchedPage>();
  let privacyPolicyUrl: string | null = null;
  let privacyDetectionMethod = "none";
  let privacyEmbeddedIn: string | null = null;
  let siteBlocked = mainPageBlocked;
  let privacySpaDetected = false;
  const spaDetectedPages = new Map<string, { category: string; confidence: number }>();

  function addLink(link: CrawledLink): void {
    const normalized = normalizeUrl(link.href);
    if (!seen.has(normalized)) {
      seen.add(normalized);
      allLinks.push(link);
    }
  }

  function isOverBudget(): boolean {
    return Date.now() > deadline;
  }

  // ========================================================================
  // RUN ALL 3 TRACKS IN PARALLEL
  // Track 1: Brute-force probe common URLs (fastest, most reliable)
  // Track 2: Parse homepage HTML for links
  // Track 3: Fetch sitemaps for URLs
  // ========================================================================
  const [track1Result, track2Links, track3Links] = await Promise.all([
    track1BruteForceProbe(origin, deadline),
    Promise.resolve(track2ParseHtml(mainPageBlocked ? "" : mainPageHtml, baseUrl)),
    track3Sitemap(origin, baseUrl, deadline),
  ]);

  // --- Process Track 1 results (brute-force probes) ---
  if (track1Result.totalCount > 0 && track1Result.blockedCount >= track1Result.totalCount * 0.8) {
    siteBlocked = true;
  }

  for (const probeResult of track1Result.results) {
    const link: CrawledLink = { href: probeResult.url, text: "", source: "probe" };
    addLink(link);
    const page: FetchedPage = {
      url: probeResult.url,
      html: probeResult.html,
      headers: new Headers(),
      cookies: [],
      statusCode: probeResult.statusCode,
    };
    fetchedPages.set(normalizeUrl(probeResult.url), page);

    // Check if this is a confirmed privacy page
    if (probeResult.category === "privacy" && !privacyPolicyUrl && hasPrivacyContentInHtml(probeResult.html)) {
      privacyPolicyUrl = probeResult.url;
      privacyDetectionMethod = "track1-brute-force";
    }

    // SPA detection: if brute-force found a page but content check failed,
    // check if it's a JS-rendered SPA page that exists at a valid URL
    if (!hasPrivacyContentInHtml(probeResult.html) && !isSoft404(probeResult.html)) {
      const spaResult = detectSpaPage(probeResult.html, probeResult.category, mainPageHtml);
      if (spaResult.isSpaPage) {
        spaDetectedPages.set(probeResult.url, {
          category: probeResult.category,
          confidence: spaResult.confidence,
        });
        // If no privacy URL found yet and this is a privacy page, use SPA detection
        if (probeResult.category === "privacy" && !privacyPolicyUrl) {
          privacyPolicyUrl = probeResult.url;
          privacyDetectionMethod = "track1-spa-detected";
          privacySpaDetected = true;
        }
      } else if (isDistinctPage(probeResult.html, mainPageHtml)) {
        // Ultimate fallback: URL returned HTTP 200, not soft-404, not blocked,
        // and the HTML is distinct from the homepage. The page exists even if
        // we can't read its JS-rendered content.
        spaDetectedPages.set(probeResult.url, {
          category: probeResult.category,
          confidence: 20, // low confidence but URL+distinctness is enough
        });
        if (probeResult.category === "privacy" && !privacyPolicyUrl) {
          privacyPolicyUrl = probeResult.url;
          privacyDetectionMethod = "track1-url-match";
          privacySpaDetected = true;
        }
      }
    }
  }

  // --- Process Track 2 results (HTML parsing) ---
  for (const link of track2Links) {
    addLink(link);
  }

  // --- Process Track 3 results (sitemap) ---
  for (const link of track3Links) {
    addLink(link);
  }

  // ========================================================================
  // Categorize ALL discovered links
  // ========================================================================
  const privacyLinks: CrawledLink[] = [];
  const consentLinks: CrawledLink[] = [];
  const rightsLinks: CrawledLink[] = [];
  const grievanceLinks: CrawledLink[] = [];
  const retentionLinks: CrawledLink[] = [];
  const legalLinks: CrawledLink[] = [];

  for (const link of allLinks) {
    if (urlMatchesPatterns(link.href, PRIVACY_URL_PATTERNS) || textMatchesKeywords(link.text, PRIVACY_TEXT_KEYWORDS)) {
      privacyLinks.push(link);
    }
    if (urlMatchesPatterns(link.href, CONSENT_URL_PATTERNS) || textMatchesKeywords(link.text, CONSENT_TEXT_KEYWORDS)) {
      consentLinks.push(link);
    }
    if (urlMatchesPatterns(link.href, RIGHTS_URL_PATTERNS) || textMatchesKeywords(link.text, RIGHTS_TEXT_KEYWORDS)) {
      rightsLinks.push(link);
    }
    if (urlMatchesPatterns(link.href, GRIEVANCE_URL_PATTERNS) || textMatchesKeywords(link.text, GRIEVANCE_TEXT_KEYWORDS)) {
      grievanceLinks.push(link);
    }
    if (urlMatchesPatterns(link.href, RETENTION_URL_PATTERNS) || textMatchesKeywords(link.text, RETENTION_TEXT_KEYWORDS)) {
      retentionLinks.push(link);
    }
    if (urlMatchesPatterns(link.href, LEGAL_PAGE_URL_PATTERNS) || textMatchesKeywords(link.text, LEGAL_PAGE_TEXT_KEYWORDS)) {
      legalLinks.push(link);
    }
  }

  // ========================================================================
  // Fetch privacy candidates from Track 2/3 if Track 1 didn't find privacy
  // ========================================================================
  if (!privacyPolicyUrl && !siteBlocked && !isOverBudget() && privacyLinks.length > 0) {
    const sourceOrder: Record<string, number> = {
      footer: 0, page: 1, "json-route": 2, script: 3, meta: 4, "raw-html": 5,
      sitemap: 6, probe: 7, subpath: 8, "cors-proxy": 9,
      "google-cache": 10, "bing-cache": 11, "manual-paste": 12,
    };
    const sorted = [...privacyLinks].sort(
      (a, b) => (sourceOrder[a.source] ?? 99) - (sourceOrder[b.source] ?? 99)
    );
    const uniqueUrls: CrawledLink[] = [];
    const urlsSeen = new Set<string>();
    for (const link of sorted) {
      const norm = normalizeUrl(link.href);
      if (!urlsSeen.has(norm) && !fetchedPages.has(norm)) {
        urlsSeen.add(norm);
        uniqueUrls.push(link);
      }
    }
    const candidates = uniqueUrls.slice(0, 6);
    if (candidates.length > 0) {
      const fetched = await Promise.all(
        candidates.map(async (link) => {
          const page = await safeFetchPage(link.href, deadline);
          return { link, page };
        })
      );
      for (const { link, page } of fetched) {
        if (page && page.statusCode >= 200 && page.statusCode < 400) {
          fetchedPages.set(normalizeUrl(page.url), page);
          if (!privacyPolicyUrl && hasPrivacyContentInHtml(page.html)) {
            privacyPolicyUrl = link.href;
            privacyDetectionMethod = `track2-${link.source}`;
          } else if (!privacyPolicyUrl && !isSoft404(page.html)) {
            // SPA fallback for Track 2/3 discovered pages
            const spaResult = detectSpaPage(page.html, "privacy", mainPageHtml);
            if (spaResult.isSpaPage) {
              spaDetectedPages.set(link.href, { category: "privacy", confidence: spaResult.confidence });
              privacyPolicyUrl = link.href;
              privacyDetectionMethod = `track2-${link.source}-spa-detected`;
              privacySpaDetected = true;
            } else if (isDistinctPage(page.html, mainPageHtml)) {
              spaDetectedPages.set(link.href, { category: "privacy", confidence: 20 });
              privacyPolicyUrl = link.href;
              privacyDetectionMethod = `track2-${link.source}-url-match`;
              privacySpaDetected = true;
            }
          }
        }
      }
    }
  }

  // Also try fetching sitemap-discovered privacy URLs
  if (!privacyPolicyUrl && !isOverBudget()) {
    const sitemapPrivacy = privacyLinks
      .filter((l) => l.source === "sitemap" && !fetchedPages.has(normalizeUrl(l.href)));
    const uniqueSitemap: CrawledLink[] = [];
    const smSeen = new Set<string>();
    for (const link of sitemapPrivacy) {
      const norm = normalizeUrl(link.href);
      if (!smSeen.has(norm)) { smSeen.add(norm); uniqueSitemap.push(link); }
    }
    if (uniqueSitemap.length > 0) {
      const fetched = await Promise.all(
        uniqueSitemap.slice(0, 4).map(async (link) => {
          const page = await safeFetchPage(link.href, deadline);
          return { link, page };
        })
      );
      for (const { link, page } of fetched) {
        if (page && page.statusCode >= 200 && page.statusCode < 400) {
          fetchedPages.set(normalizeUrl(page.url), page);
          if (!privacyPolicyUrl && hasPrivacyContentInHtml(page.html)) {
            privacyPolicyUrl = link.href;
            privacyDetectionMethod = "track3-sitemap";
          } else if (!privacyPolicyUrl && !isSoft404(page.html)) {
            const spaResult = detectSpaPage(page.html, "privacy", mainPageHtml);
            if (spaResult.isSpaPage) {
              spaDetectedPages.set(link.href, { category: "privacy", confidence: spaResult.confidence });
              privacyPolicyUrl = link.href;
              privacyDetectionMethod = "track3-sitemap-spa-detected";
              privacySpaDetected = true;
            } else if (isDistinctPage(page.html, mainPageHtml)) {
              spaDetectedPages.set(link.href, { category: "privacy", confidence: 20 });
              privacyPolicyUrl = link.href;
              privacyDetectionMethod = "track3-sitemap-url-match";
              privacySpaDetected = true;
            }
          }
        }
      }
    }
  }

  // ========================================================================
  // CORS proxy fallback (for WAF-blocked sites)
  // ========================================================================
  if (!privacyPolicyUrl && siteBlocked && !isOverBudget()) {
    const proxyResult = await fetchViaCorsProxy(baseUrl);
    if (proxyResult && proxyResult.html.length > 500 && !isBlockedResponse(proxyResult.html, proxyResult.statusCode)) {
      const proxyLinks = extractLinksWithText(proxyResult.html, baseUrl);
      for (const link of proxyLinks) {
        if (isSameSite(link.href, baseUrl)) {
          const crawlLink: CrawledLink = { href: link.href, text: link.text, source: "cors-proxy" };
          addLink(crawlLink);
          if (urlMatchesPatterns(link.href, PRIVACY_URL_PATTERNS) || textMatchesKeywords(link.text, PRIVACY_TEXT_KEYWORDS)) {
            privacyLinks.push(crawlLink);
          }
        }
      }
      // Try fetching discovered privacy URLs via proxy
      const proxyPrivacy = privacyLinks.filter(
        (l) => l.source === "cors-proxy" && !fetchedPages.has(normalizeUrl(l.href))
      );
      for (const link of proxyPrivacy.slice(0, 3)) {
        if (isOverBudget()) break;
        const pageResult = await fetchViaCorsProxy(link.href);
        if (pageResult && pageResult.html.length > 500 && !isBlockedResponse(pageResult.html, pageResult.statusCode)) {
          const page: FetchedPage = { url: link.href, html: pageResult.html, headers: new Headers(), cookies: [], statusCode: pageResult.statusCode };
          fetchedPages.set(normalizeUrl(link.href), page);
          if (!privacyPolicyUrl && hasPrivacyContentInHtml(pageResult.html)) {
            privacyPolicyUrl = link.href;
            privacyDetectionMethod = "cors-proxy";
          } else if (!privacyPolicyUrl && !isSoft404(pageResult.html)) {
            const spaResult = detectSpaPage(pageResult.html, "privacy", mainPageHtml);
            if (spaResult.isSpaPage || isDistinctPage(pageResult.html, mainPageHtml)) {
              spaDetectedPages.set(link.href, { category: "privacy", confidence: spaResult.isSpaPage ? spaResult.confidence : 20 });
              privacyPolicyUrl = link.href;
              privacyDetectionMethod = spaResult.isSpaPage ? "cors-proxy-spa-detected" : "cors-proxy-url-match";
              privacySpaDetected = true;
            }
          }
        }
      }
    }

    // Also try direct privacy URLs via proxy
    if (!privacyPolicyUrl && !isOverBudget()) {
      const directPaths = ["/privacy", "/privacy-policy", "/privacy.html", "/legal/privacy", "/policies/privacy"];
      for (const path of directPaths) {
        if (isOverBudget() || privacyPolicyUrl) break;
        const url = `${origin}${path}`;
        const result = await fetchViaCorsProxy(url);
        if (result && result.html.length > 500 && !isBlockedResponse(result.html, result.statusCode)) {
          if (!isSoft404(result.html)) {
            const page: FetchedPage = { url, html: result.html, headers: new Headers(), cookies: [], statusCode: result.statusCode };
            fetchedPages.set(normalizeUrl(url), page);
            const link: CrawledLink = { href: url, text: "", source: "cors-proxy" };
            addLink(link);
            privacyLinks.push(link);
            if (hasPrivacyContentInHtml(result.html)) {
              privacyPolicyUrl = url;
              privacyDetectionMethod = "cors-proxy-direct";
            } else {
              const spaResult = detectSpaPage(result.html, "privacy", mainPageHtml);
              if (spaResult.isSpaPage || isDistinctPage(result.html, mainPageHtml)) {
                spaDetectedPages.set(url, { category: "privacy", confidence: spaResult.isSpaPage ? spaResult.confidence : 20 });
                privacyPolicyUrl = url;
                privacyDetectionMethod = spaResult.isSpaPage ? "cors-proxy-direct-spa-detected" : "cors-proxy-direct-url-match";
                privacySpaDetected = true;
              }
            }
          }
        }
      }
    }
  }

  // ========================================================================
  // Google/Bing Cache fallback
  // ========================================================================
  if (!privacyPolicyUrl && siteBlocked && !isOverBudget()) {
    const cacheResult = await fetchFromWebCache(domain, "privacy policy");
    if (cacheResult && cacheResult.html.length > 500) {
      if (hasPrivacyContentInHtml(cacheResult.html)) {
        const cacheUrl = `https://${domain}/privacy`;
        const page: FetchedPage = { url: cacheUrl, html: cacheResult.html, headers: new Headers(), cookies: [], statusCode: 200 };
        fetchedPages.set(normalizeUrl(cacheUrl), page);
        privacyPolicyUrl = cacheUrl;
        privacyDetectionMethod = `cache-${cacheResult.source}`;
        const link: CrawledLink = { href: cacheUrl, text: "", source: cacheResult.source };
        addLink(link);
        privacyLinks.push(link);
      }
    }
  }

  // ========================================================================
  // Subpath exploration (for non-blocked sites — only if still no privacy)
  // ========================================================================
  if (!privacyPolicyUrl && !siteBlocked && !isOverBudget()) {
    const subpathResults = await Promise.all(
      PHASE_C_SUBPATHS.map(async (path) => {
        if (isOverBudget()) return null;
        const subUrl = `${origin}${path}`;
        const norm = normalizeUrl(subUrl);
        if (fetchedPages.has(norm)) return null;
        const page = await safeFetchPage(subUrl, deadline);
        return page ? { path, page } : null;
      })
    );

    for (const result of subpathResults) {
      if (!result) continue;
      const { page } = result;
      fetchedPages.set(normalizeUrl(page.url), page);
      const subLinks = extractLinksWithText(page.html, page.url);
      for (const link of subLinks) {
        if (!isSameSite(link.href, baseUrl)) continue;
        const crawlLink: CrawledLink = { href: link.href, text: link.text, source: "subpath" };
        addLink(crawlLink);
        if (urlMatchesPatterns(link.href, PRIVACY_URL_PATTERNS) || textMatchesKeywords(link.text, PRIVACY_TEXT_KEYWORDS)) {
          privacyLinks.push(crawlLink);
        }
      }
    }

    // Fetch newly-discovered privacy links
    if (!privacyPolicyUrl) {
      const newLinks = privacyLinks.filter(
        (l) => l.source === "subpath" && !fetchedPages.has(normalizeUrl(l.href))
      );
      const unique: CrawledLink[] = [];
      const uSeen = new Set<string>();
      for (const link of newLinks) {
        const norm = normalizeUrl(link.href);
        if (!uSeen.has(norm)) { uSeen.add(norm); unique.push(link); }
      }
      if (unique.length > 0) {
        const fetched = await Promise.all(
          unique.slice(0, 4).map(async (link) => {
            const page = await safeFetchPage(link.href, deadline);
            return { link, page };
          })
        );
        for (const { link, page } of fetched) {
          if (page && page.statusCode >= 200 && page.statusCode < 400) {
            fetchedPages.set(normalizeUrl(page.url), page);
            if (!privacyPolicyUrl && hasPrivacyContentInHtml(page.html)) {
              privacyPolicyUrl = link.href;
              privacyDetectionMethod = `subpath-${link.source}`;
            } else if (!privacyPolicyUrl && !isSoft404(page.html)) {
              const spaResult = detectSpaPage(page.html, "privacy", mainPageHtml);
              if (spaResult.isSpaPage || isDistinctPage(page.html, mainPageHtml)) {
                spaDetectedPages.set(link.href, { category: "privacy", confidence: spaResult.isSpaPage ? spaResult.confidence : 20 });
                privacyPolicyUrl = link.href;
                privacyDetectionMethod = spaResult.isSpaPage ? `subpath-spa-detected` : `subpath-url-match`;
                privacySpaDetected = true;
              }
            }
          }
        }
      }
    }
  }

  // ---- Check legal pages for embedded privacy content ----
  if (!privacyPolicyUrl && !siteBlocked && !isOverBudget()) {
    const uniqueLegal: CrawledLink[] = [];
    const lSeen = new Set<string>();
    for (const link of legalLinks) {
      const norm = normalizeUrl(link.href);
      if (!lSeen.has(norm) && !fetchedPages.has(norm)) {
        lSeen.add(norm);
        uniqueLegal.push(link);
      }
    }
    if (uniqueLegal.length > 0) {
      const fetched = await Promise.all(
        uniqueLegal.slice(0, 3).map(async (link) => {
          const page = await safeFetchPage(link.href, deadline);
          return { link, page };
        })
      );
      for (const { link, page } of fetched) {
        if (page && page.statusCode >= 200 && page.statusCode < 400) {
          fetchedPages.set(normalizeUrl(page.url), page);
          if (!privacyPolicyUrl && hasPrivacyContentInHtml(page.html)) {
            privacyPolicyUrl = link.href;
            privacyDetectionMethod = "embedded-in-legal-page";
            privacyEmbeddedIn = link.text ||
              new URL(link.href).pathname.split("/").filter(Boolean).pop() ||
              "legal page";
          } else if (!privacyPolicyUrl && !isSoft404(page.html)) {
            // Check if this legal page is a SPA page with privacy content
            const spaResult = detectSpaPage(page.html, "privacy", mainPageHtml);
            if (spaResult.isSpaPage || isDistinctPage(page.html, mainPageHtml)) {
              // Check if the URL itself matches privacy patterns
              if (urlMatchesPatterns(link.href, PRIVACY_URL_PATTERNS)) {
                spaDetectedPages.set(link.href, { category: "privacy", confidence: spaResult.isSpaPage ? spaResult.confidence : 20 });
                privacyPolicyUrl = link.href;
                privacyDetectionMethod = spaResult.isSpaPage ? "legal-page-spa-detected" : "legal-page-url-match";
                privacySpaDetected = true;
              }
            }
          }
        }
      }
    }
  }

  // ========================================================================
  // Fetch additional categorized pages for other checks
  // (grievance, rights, retention, consent — many already fetched by Track 1)
  // ========================================================================
  if (!isOverBudget()) {
    const additionalFetches: { link: CrawledLink }[] = [];
    const addCategoryPages = (links: CrawledLink[], limit: number) => {
      const catSeen = new Set<string>();
      for (const link of links) {
        const norm = normalizeUrl(link.href);
        if (!catSeen.has(norm) && !fetchedPages.has(norm)) {
          catSeen.add(norm);
          additionalFetches.push({ link });
          if (catSeen.size >= limit) break;
        }
      }
    };
    addCategoryPages(consentLinks, 2);
    addCategoryPages(rightsLinks, 2);
    addCategoryPages(grievanceLinks, 2);
    addCategoryPages(retentionLinks, 2);

    if (additionalFetches.length > 0) {
      const fetched = await Promise.all(
        additionalFetches.map(async ({ link }) => {
          const page = await safeFetchPage(link.href, deadline);
          return { link, page };
        })
      );
      for (const { page } of fetched) {
        if (page && page.statusCode >= 200 && page.statusCode < 400) {
          fetchedPages.set(normalizeUrl(page.url), page);
        }
      }
    }
  }

  return {
    allLinks,
    privacyLinks,
    consentLinks,
    rightsLinks,
    grievanceLinks,
    retentionLinks,
    legalLinks,
    fetchedPages,
    privacyPolicyUrl,
    privacyDetectionMethod,
    privacyEmbeddedIn,
    siteBlocked,
    privacySpaDetected,
    spaDetectedPages,
  };
}
