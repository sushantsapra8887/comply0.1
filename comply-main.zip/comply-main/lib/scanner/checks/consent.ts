import { CheckResult, ScanContext } from "../types";
import { containsAny, stripHtml, countMatches } from "../utils";

const CONSENT_SCRIPTS = [
  "onetrust",
  "cookiebot",
  "osano",
  "trustarc",
  "cookieyes",
  "termly",
  "iubenda",
  "cookieconsent",
  "cookie-consent",
  "cookie-notice",
  "cookie-banner",
  "consent-manager",
  "quantcast",
  "didomi",
  "usercentrics",
  "consentmanager",
];

const CONSENT_ELEMENTS = [
  "cookie-banner",
  "cookie-consent",
  "consent-banner",
  "consent-modal",
  "consent-overlay",
  "cookie-notice",
  "cookie-popup",
  "cookie-modal",
  "gdpr-banner",
  "cc-banner",
  "cc-window",
  "cky-consent",
];

/**
 * Get combined HTML from main page + any consent-related crawled pages.
 */
function getAllConsentHtml(ctx: ScanContext): string {
  const sources = [ctx.mainPage.html];
  // Include consent-related crawled pages
  for (const link of ctx.crawl.consentLinks) {
    const page = ctx.crawl.fetchedPages.get(link.href);
    if (page && page.url !== ctx.mainPage.url) {
      sources.push(page.html);
    }
  }
  // Also check any fetched pages from the crawl
  for (const [, page] of ctx.crawl.fetchedPages) {
    if (page.url !== ctx.mainPage.url && !sources.includes(page.html)) {
      const lower = page.url.toLowerCase();
      if (
        lower.includes("consent") ||
        lower.includes("cookie") ||
        lower.includes("preferences")
      ) {
        sources.push(page.html);
      }
    }
  }
  return sources.join("\n");
}

/**
 * SC07: Consent banner present
 */
function checkConsentBanner(ctx: ScanContext): CheckResult {
  if (ctx.siteBlocked && !ctx.mainPage.html) {
    return {
      id: "SC07",
      name: "Consent banner present",
      description: "Detect consent overlay/banner/modal on page load or common consent management scripts.",
      severity: "CRITICAL",
      status: "SKIP",
      details: "Skipped — site has bot protection that prevented automated scanning.",
    };
  }
  const allHtml = getAllConsentHtml(ctx).toLowerCase();

  // Check for consent management scripts
  const scriptMatches = CONSENT_SCRIPTS.filter((s) => allHtml.includes(s));

  // Check for consent-related HTML elements (class/id)
  const elementMatches = CONSENT_ELEMENTS.filter(
    (el) =>
      allHtml.includes(`class="${el}"`) ||
      allHtml.includes(`id="${el}"`) ||
      allHtml.includes(`class='${el}'`) ||
      allHtml.includes(`id='${el}'`)
  );

  // Check for generic consent indicators
  const hasConsentText = containsAny(allHtml, [
    "we use cookies",
    "this website uses cookies",
    "cookie preferences",
    "accept cookies",
    "accept all",
    "reject all",
    "cookie settings",
    "manage cookies",
  ]);

  const detected =
    scriptMatches.length > 0 || elementMatches.length > 0 || hasConsentText;

  return {
    id: "SC07",
    name: "Consent banner present",
    description:
      "Detect consent overlay/banner/modal on page load or common consent management scripts.",
    severity: "CRITICAL",
    status: detected ? "PASS" : "FAIL",
    details: detected
      ? `Consent mechanism detected: ${[...scriptMatches, ...elementMatches].join(", ") || "consent text found"}`
      : "No consent banner, overlay, or consent management script detected.",
    metadata: { scriptMatches, elementMatches, hasConsentText },
  };
}

/**
 * SC08: Granular consent
 */
function checkGranularConsent(ctx: ScanContext): CheckResult {
  const allHtml = getAllConsentHtml(ctx);
  const lower = allHtml.toLowerCase();

  // Check for multiple checkboxes/toggles in consent context
  const checkboxCount = (
    allHtml.match(/<input[^>]*type\s*=\s*["']checkbox["'][^>]*>/gi) || []
  ).length;

  // Check for toggle switches (common in consent banners)
  const hasToggles = containsAny(lower, [
    "toggle",
    "switch",
    'role="switch"',
    "consent-toggle",
  ]);

  // Check for purpose-level categories
  const hasPurposeCategories = containsAny(lower, [
    "analytics",
    "marketing",
    "functional",
    "necessary",
    "performance",
    "advertising",
    "preferences",
    "statistics",
    "targeting",
  ]);

  // Granular means multiple choices available
  const isGranular =
    (checkboxCount >= 2 || hasToggles) && hasPurposeCategories;

  return {
    id: "SC08",
    name: "Granular consent",
    description:
      "Check if consent banner offers purpose-level choices (multiple toggles/checkboxes).",
    severity: "HIGH",
    status: isGranular ? "PASS" : "FAIL",
    details: isGranular
      ? "Consent mechanism provides granular, purpose-level choices."
      : "Consent mechanism does not appear to offer granular purpose-level choices.",
    metadata: { checkboxCount, hasToggles, hasPurposeCategories },
  };
}

/**
 * SC09: No pre-checked boxes
 */
function checkNoPreCheckedBoxes(ctx: ScanContext): CheckResult {
  const allHtml = getAllConsentHtml(ctx);

  // Find checked checkboxes
  const checkedRegex =
    /<input[^>]*type\s*=\s*["']checkbox["'][^>]*checked[^>]*>/gi;
  const preChecked = allHtml.match(checkedRegex) || [];

  // Filter out likely non-consent checkboxes (remember me, etc.)
  const suspiciousPreChecked = preChecked.filter((el) => {
    const lower = el.toLowerCase();
    return (
      !lower.includes("remember") &&
      !lower.includes("keep me") &&
      !lower.includes("stay signed")
    );
  });

  return {
    id: "SC09",
    name: "No pre-checked boxes",
    description:
      "Detect pre-checked checkboxes in consent/signup forms that could imply forced consent.",
    severity: "MEDIUM",
    status: suspiciousPreChecked.length === 0 ? "PASS" : "FAIL",
    details:
      suspiciousPreChecked.length === 0
        ? "No suspicious pre-checked checkboxes found."
        : `Found ${suspiciousPreChecked.length} pre-checked checkbox(es) that may imply forced consent.`,
    metadata: { count: suspiciousPreChecked.length },
  };
}

/**
 * SC10: Withdrawal option visible
 */
function checkWithdrawalOption(ctx: ScanContext): CheckResult {
  const htmlSources = [ctx.mainPage.html];
  if (ctx.privacyPage) htmlSources.push(ctx.privacyPage.html);
  // Include all crawled pages for deep detection
  for (const [, page] of ctx.crawl.fetchedPages) {
    if (page.url !== ctx.mainPage.url && page.url !== ctx.privacyPage?.url) {
      htmlSources.push(page.html);
    }
  }

  const combinedText = stripHtml(htmlSources.join(" "));

  const keywords = [
    "withdraw consent",
    "withdraw your consent",
    "manage preferences",
    "manage cookie",
    "opt out",
    "opt-out",
    "revoke consent",
    "change consent",
    "update preferences",
    "cookie settings",
    "privacy settings",
  ];

  const found = countMatches(combinedText, keywords);

  return {
    id: "SC10",
    name: "Withdrawal option visible",
    description:
      "Search for consent withdrawal or preference management options.",
    severity: "HIGH",
    status: found.length > 0 ? "PASS" : "FAIL",
    details:
      found.length > 0
        ? `Withdrawal options found: ${found.join(", ")}`
        : "No consent withdrawal or preference management option found.",
    metadata: { matchedKeywords: found },
  };
}

/**
 * SC11: Withdrawal UX comparable
 */
function checkWithdrawalUxComparable(ctx: ScanContext): CheckResult {
  const htmlSources = [ctx.mainPage.html];
  // Include all crawled pages
  for (const [, page] of ctx.crawl.fetchedPages) {
    if (page.url !== ctx.mainPage.url) {
      htmlSources.push(page.html);
    }
  }
  const allHtml = htmlSources.join("\n").toLowerCase();

  // Check if there's a persistent way to manage consent (footer link, floating button)
  const hasPersistentAccess = containsAny(allHtml, [
    "manage cookies",
    "cookie settings",
    "privacy settings",
    "manage preferences",
    "cookie preferences",
    "consent preferences",
    // Floating cookie icons
    "ot-floating-button",
    "cky-btn-revisit",
  ]);

  // Check if withdrawal is as easy as consent (one-click accessible)
  const hasEasyWithdrawal = containsAny(allHtml, [
    "withdraw",
    "revoke",
    "opt out",
    "opt-out",
    "reject all",
    "decline all",
    "deny all",
  ]);

  const isComparable = hasPersistentAccess || hasEasyWithdrawal;

  return {
    id: "SC11",
    name: "Withdrawal UX comparable",
    description:
      "Compare consent giving vs withdrawal complexity. Withdrawal should not be harder than consent.",
    severity: "MEDIUM",
    status: isComparable ? "PASS" : "FAIL",
    details: isComparable
      ? "Consent withdrawal appears to be accessible with comparable ease to giving consent."
      : "Consent withdrawal may be harder than giving consent — no persistent management option found.",
    metadata: { hasPersistentAccess, hasEasyWithdrawal },
  };
}

export function runConsentChecks(ctx: ScanContext): CheckResult[] {
  return [
    checkConsentBanner(ctx),
    checkGranularConsent(ctx),
    checkNoPreCheckedBoxes(ctx),
    checkWithdrawalOption(ctx),
    checkWithdrawalUxComparable(ctx),
  ];
}
