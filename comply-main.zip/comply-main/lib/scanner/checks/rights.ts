import { CheckResult, ScanContext } from "../types";
import { stripHtml, countMatches } from "../utils";

/**
 * Get combined text from main + privacy + all deeply crawled pages.
 * This ensures we find content even if it's on a separate grievance,
 * rights, or retention policy page.
 */
function getCombinedText(ctx: ScanContext): string {
  const sources = [stripHtml(ctx.mainPage.html)];
  if (ctx.privacyPage) {
    sources.push(stripHtml(ctx.privacyPage.html));
  }
  // Include ALL crawled pages for comprehensive detection
  for (const [, page] of ctx.crawl.fetchedPages) {
    if (page.url !== ctx.mainPage.url && page.url !== ctx.privacyPage?.url) {
      sources.push(stripHtml(page.html));
    }
  }
  return sources.join(" ");
}

/**
 * Get text from pages matching a specific category (grievance, rights, retention, etc.)
 */
function getCategoryText(
  ctx: ScanContext,
  category: "grievance" | "rights" | "retention"
): string {
  const sources: string[] = [];

  const links =
    category === "grievance"
      ? ctx.crawl.grievanceLinks
      : category === "rights"
        ? ctx.crawl.rightsLinks
        : ctx.crawl.retentionLinks;

  for (const link of links) {
    const page = ctx.crawl.fetchedPages.get(link.href);
    if (page) {
      sources.push(stripHtml(page.html));
    }
  }

  return sources.join(" ");
}

/**
 * SC23: DPO/Grievance officer contact
 */
function checkGrievanceOfficer(ctx: ScanContext): CheckResult {
  const combinedText = getCombinedText(ctx);
  const categoryText = getCategoryText(ctx, "grievance");
  const text = combinedText + " " + categoryText;

  const keywords = [
    "grievance officer",
    "grievance redressal",
    "data protection officer",
    "dpo",
    "nodal officer",
    "privacy officer",
    "compliance officer",
  ];

  const found = countMatches(text, keywords);

  return {
    id: "SC23",
    name: "DPO/Grievance officer contact",
    description:
      "Search for Grievance Officer or Data Protection Officer contact information across all discovered pages.",
    severity: "HIGH",
    status: found.length > 0 ? "PASS" : "FAIL",
    details:
      found.length > 0
        ? `Found references to: ${found.join(", ")}`
        : "No DPO or Grievance Officer contact information found across main page, privacy policy, or any discovered grievance/contact pages.",
    metadata: {
      matchedKeywords: found,
      pagesSearched:
        2 +
        ctx.crawl.fetchedPages.size +
        ctx.crawl.grievanceLinks.length,
    },
  };
}

/**
 * SC24: Data access/deletion mechanism
 */
function checkDataAccessDeletion(ctx: ScanContext): CheckResult {
  const combinedText = getCombinedText(ctx);
  const categoryText = getCategoryText(ctx, "rights");
  const text = combinedText + " " + categoryText;

  const keywords = [
    "request your data",
    "request data",
    "access your data",
    "download your data",
    "data portability",
    "delete my data",
    "delete your data",
    "data deletion",
    "erasure request",
    "data subject access request",
    "dsar",
    "subject access request",
    "sar",
  ];

  const found = countMatches(text, keywords);

  return {
    id: "SC24",
    name: "Data access/deletion mechanism",
    description:
      "Search for mechanisms to request data access or deletion (DSAR) across all discovered pages.",
    severity: "HIGH",
    status: found.length > 0 ? "PASS" : "FAIL",
    details:
      found.length > 0
        ? `Found data access/deletion references: ${found.join(", ")}`
        : "No data access or deletion mechanism found across main page, privacy policy, or any discovered rights pages.",
    metadata: { matchedKeywords: found },
  };
}

/**
 * SC25: Rights process documented
 */
function checkRightsProcessDocumented(ctx: ScanContext): CheckResult {
  const combinedText = getCombinedText(ctx);
  const categoryText = getCategoryText(ctx, "rights");
  const text = combinedText + " " + categoryText;

  const keywords = [
    "verification",
    "verify your identity",
    "timeline",
    "within",
    "business days",
    "working days",
    "calendar days",
    "steps to",
    "process for",
    "how to exercise",
    "submit a request",
    "to exercise your rights",
  ];

  const found = countMatches(text, keywords);

  return {
    id: "SC25",
    name: "Rights process documented",
    description:
      "Check if steps, verification, and timeline for exercising rights are explained.",
    severity: "MEDIUM",
    status: found.length >= 2 ? "PASS" : "FAIL",
    details:
      found.length >= 2
        ? `Rights process documentation found with: ${found.join(", ")}`
        : "Rights exercise process does not appear to be fully documented (steps/verification/timeline).",
    metadata: { matchedKeywords: found },
  };
}

/**
 * SC26: Retention policy published
 */
function checkRetentionPolicy(ctx: ScanContext): CheckResult {
  const combinedText = getCombinedText(ctx);
  const categoryText = getCategoryText(ctx, "retention");
  const text = combinedText + " " + categoryText;

  const keywords = [
    "retention",
    "how long we keep",
    "how long we store",
    "data retention",
    "retain your",
    "retention period",
    "stored for",
    "kept for",
    "deletion schedule",
    "retain personal",
  ];

  const found = countMatches(text, keywords);

  return {
    id: "SC26",
    name: "Retention policy published",
    description:
      "Search for data retention policy information across all discovered pages.",
    severity: "MEDIUM",
    status: found.length > 0 ? "PASS" : "FAIL",
    details:
      found.length > 0
        ? `Retention policy references found: ${found.join(", ")}`
        : "No data retention policy information found across main page, privacy policy, or any discovered retention/legal pages.",
    metadata: { matchedKeywords: found },
  };
}

/**
 * SC29: Account deletion available
 */
function checkAccountDeletion(ctx: ScanContext): CheckResult {
  const text = getCombinedText(ctx);
  const keywords = [
    "delete account",
    "delete my account",
    "close my account",
    "deactivate account",
    "remove my account",
    "account deletion",
    "terminate account",
    "cancel my account",
  ];

  const found = countMatches(text, keywords);

  return {
    id: "SC29",
    name: "Account deletion available",
    description: "Search for account deletion options across all discovered pages.",
    severity: "MEDIUM",
    status: found.length > 0 ? "PASS" : "FAIL",
    details:
      found.length > 0
        ? `Account deletion references found: ${found.join(", ")}`
        : "No account deletion option found.",
    metadata: { matchedKeywords: found },
  };
}

/**
 * SC30: Response timeline stated
 */
function checkResponseTimeline(ctx: ScanContext): CheckResult {
  const text = getCombinedText(ctx);

  // Look for time commitments
  const timePatterns = [
    "within \\d+ days",
    "within \\d+ business days",
    "within \\d+ working days",
    "\\d+ days of",
    "response time",
    "respond within",
    "acknowledge within",
    "processing time",
    "turnaround time",
    "within a reasonable",
  ];

  const found: string[] = [];
  const lower = text.toLowerCase();

  for (const pattern of timePatterns) {
    const regex = new RegExp(pattern, "i");
    if (regex.test(lower)) {
      found.push(pattern.replace(/\\\\/g, ""));
    }
  }

  // Also check for specific DPDP timeline references
  const dpdpKeywords = countMatches(text, [
    "30 days",
    "72 hours",
    "reasonable time",
    "promptly",
    "without undue delay",
  ]);

  const allFound = [...found, ...dpdpKeywords];

  return {
    id: "SC30",
    name: "Response timeline stated",
    description:
      "Search for response time commitments for user requests across all discovered pages.",
    severity: "MEDIUM",
    status: allFound.length > 0 ? "PASS" : "FAIL",
    details:
      allFound.length > 0
        ? `Response timeline indicators found: ${allFound.join(", ")}`
        : "No response timeline commitment found.",
    metadata: { matchedPatterns: allFound },
  };
}

export function runRightsChecks(ctx: ScanContext): CheckResult[] {
  return [
    checkGrievanceOfficer(ctx),
    checkDataAccessDeletion(ctx),
    checkRightsProcessDocumented(ctx),
    checkRetentionPolicy(ctx),
    checkAccountDeletion(ctx),
    checkResponseTimeline(ctx),
  ];
}
