import { CheckResult, ScanContext } from "../types";
import { containsAny } from "../utils";

/**
 * SC27: Age verification
 */
function checkAgeVerification(ctx: ScanContext): CheckResult {
  // Check main page + all crawled pages
  const htmlSources = [ctx.mainPage.html];
  for (const [, page] of ctx.crawl.fetchedPages) {
    if (page.url !== ctx.mainPage.url) {
      htmlSources.push(page.html);
    }
  }
  const html = htmlSources.join("\n");
  const lower = html.toLowerCase();

  // Check for date-of-birth fields
  const hasDobField =
    /<input[^>]*(?:type\s*=\s*["']date["']|name\s*=\s*["'][^"']*(?:dob|birth|age|date_of_birth|birthday)[^"']*["'])[^>]*>/i.test(
      html
    );

  // Check for age gate elements
  const hasAgeGate = containsAny(lower, [
    "age-gate",
    "agegate",
    "age-verification",
    "age_verification",
    "verify your age",
    "confirm your age",
    "are you over",
    "are you 18",
    "must be 18",
    "must be at least",
    "minimum age",
    "age restriction",
    "parental consent",
    "guardian consent",
    "parent or guardian",
  ]);

  // Check for select/dropdown with age or year
  const hasAgeSelect =
    /<select[^>]*(?:name|id)\s*=\s*["'][^"']*(?:age|year|birth)[^"']*["'][^>]*>/i.test(
      html
    );

  const found = hasDobField || hasAgeGate || hasAgeSelect;

  return {
    id: "SC27",
    name: "Age verification",
    description:
      "Check for date-of-birth field or age gate mechanism across all discovered pages.",
    severity: "MEDIUM",
    status: found ? "PASS" : "FAIL",
    details: found
      ? `Age verification mechanism detected: ${hasDobField ? "DOB field " : ""}${hasAgeGate ? "age gate " : ""}${hasAgeSelect ? "age selector" : ""}`.trim()
      : "No age verification or age gate mechanism detected.",
    metadata: { hasDobField, hasAgeGate, hasAgeSelect },
  };
}

/**
 * SC28: Trackers on child pages
 */
function checkTrackersOnChildPages(ctx: ScanContext): CheckResult {
  // Check main page + all crawled pages
  const htmlSources = [ctx.mainPage.html];
  for (const [, page] of ctx.crawl.fetchedPages) {
    if (page.url !== ctx.mainPage.url) {
      htmlSources.push(page.html);
    }
  }
  const html = htmlSources.join("\n");
  const lower = html.toLowerCase();

  // Detect if site targets children
  const childIndicators = [
    "kids",
    "children",
    "child",
    "minor",
    "teen",
    "young",
    "student",
    "school",
    "educational",
    "parental",
    "coppa",
    "age-appropriate",
  ];

  const isChildContent = containsAny(lower, childIndicators);

  if (!isChildContent) {
    return {
      id: "SC28",
      name: "Trackers on child pages",
      description:
        "If child-directed content is detected, check for ad/tracking scripts.",
      severity: "HIGH",
      status: "PASS",
      details:
        "No child-directed content indicators found on this page.",
    };
  }

  // Check for ad/tracking scripts on child content
  const adScripts = [
    "googlesyndication",
    "doubleclick",
    "adsbygoogle",
    "facebook.com/tr",
    "fbq(",
    "ads-twitter",
    "analytics.tiktok",
    "ad.js",
    "ads.js",
  ];

  const foundTrackers = adScripts.filter((s) => lower.includes(s));

  return {
    id: "SC28",
    name: "Trackers on child pages",
    description:
      "If child-directed content is detected, check for ad/tracking scripts across all discovered pages.",
    severity: "HIGH",
    status: foundTrackers.length === 0 ? "PASS" : "FAIL",
    details:
      foundTrackers.length === 0
        ? "Child-directed content detected but no ad/tracking scripts found."
        : `Child-directed content detected with ${foundTrackers.length} ad/tracking script(s): ${foundTrackers.join(", ")}`,
    metadata: { isChildContent, foundTrackers },
  };
}

export function runChildrenChecks(ctx: ScanContext): CheckResult[] {
  return [checkAgeVerification(ctx), checkTrackersOnChildPages(ctx)];
}
