import { CheckResult, ScanContext } from "../types";
import { stripHtml, containsAny } from "../utils";

const TRACKER_PATTERNS: { name: string; patterns: string[] }[] = [
  {
    name: "Google Analytics",
    patterns: [
      "google-analytics.com",
      "googletagmanager.com",
      "gtag(",
      "ga(",
      "analytics.js",
      "gtag.js",
      "gtm.js",
    ],
  },
  {
    name: "Facebook Pixel",
    patterns: [
      "connect.facebook.net",
      "fbq(",
      "facebook.com/tr",
      "fbevents.js",
    ],
  },
  {
    name: "Google Ads",
    patterns: [
      "googleads.g.doubleclick.net",
      "googlesyndication.com",
      "googleadservices.com",
      "adsbygoogle",
    ],
  },
  {
    name: "Hotjar",
    patterns: ["hotjar.com", "static.hotjar.com", "hj("],
  },
  {
    name: "Mixpanel",
    patterns: ["mixpanel.com", "cdn.mxpnl.com"],
  },
  {
    name: "Segment",
    patterns: ["cdn.segment.com", "segment.io", "analytics.min.js"],
  },
  {
    name: "LinkedIn Insight",
    patterns: ["snap.licdn.com", "linkedin.com/px"],
  },
  {
    name: "Twitter Pixel",
    patterns: ["static.ads-twitter.com", "t.co/i/adsct"],
  },
  {
    name: "Amplitude",
    patterns: ["cdn.amplitude.com", "amplitude.com"],
  },
  {
    name: "Microsoft Clarity",
    patterns: ["clarity.ms"],
  },
  {
    name: "TikTok Pixel",
    patterns: ["analytics.tiktok.com"],
  },
  {
    name: "Pinterest Tag",
    patterns: ["ct.pinterest.com", "pintrk("],
  },
];

const PERSONAL_FIELD_PATTERNS = [
  { label: "Email", patterns: ["email", "e-mail", "mail"] },
  { label: "Phone", patterns: ["phone", "mobile", "tel"] },
  {
    label: "Name",
    patterns: ["name", "full_name", "fullname", "first_name", "last_name"],
  },
  { label: "Aadhaar", patterns: ["aadhaar", "aadhar", "uid"] },
  { label: "PAN", patterns: ["pan", "pan_number"] },
  {
    label: "Address",
    patterns: ["address", "street", "city", "pincode", "zip"],
  },
  {
    label: "DOB",
    patterns: ["dob", "date_of_birth", "birthday", "birth_date"],
  },
];

/**
 * SC19: Personal data forms
 */
function checkPersonalDataForms(ctx: ScanContext): CheckResult {
  // Check main page + all crawled pages for forms
  const htmlSources = [ctx.mainPage.html];
  for (const [, page] of ctx.crawl.fetchedPages) {
    if (page.url !== ctx.mainPage.url) {
      htmlSources.push(page.html);
    }
  }
  const html = htmlSources.join("\n");

  // Find input fields
  const inputRegex =
    /<input[^>]*(?:name|id|placeholder|type|autocomplete)\s*=\s*["']([^"']*)["'][^>]*>/gi;
  const fields: { field: string; categories: string[] }[] = [];
  let match: RegExpExecArray | null;

  while ((match = inputRegex.exec(html)) !== null) {
    const value = match[1].toLowerCase();
    const matchedCategories: string[] = [];

    for (const category of PERSONAL_FIELD_PATTERNS) {
      if (category.patterns.some((p) => value.includes(p))) {
        matchedCategories.push(category.label);
      }
    }

    if (matchedCategories.length > 0) {
      fields.push({ field: value, categories: matchedCategories });
    }
  }

  // Deduplicate categories
  const allCategories = [...new Set(fields.flatMap((f) => f.categories))];

  return {
    id: "SC19",
    name: "Personal data forms",
    description:
      "Detect forms collecting personal data (email, phone, name, Aadhaar) across all discovered pages.",
    severity: "INFO",
    status: "INFO",
    details:
      fields.length > 0
        ? `Found ${fields.length} personal data field(s) across categories: ${allCategories.join(", ")}`
        : "No personal data collection fields detected.",
    metadata: { fields, categories: allCategories },
  };
}

/**
 * SC20: Third-party trackers
 */
function checkThirdPartyTrackers(ctx: ScanContext): CheckResult {
  // Check main page + all crawled pages for trackers
  const htmlSources = [ctx.mainPage.html];
  for (const [, page] of ctx.crawl.fetchedPages) {
    if (page.url !== ctx.mainPage.url) {
      htmlSources.push(page.html);
    }
  }
  const html = htmlSources.join("\n").toLowerCase();
  const detected: string[] = [];

  for (const tracker of TRACKER_PATTERNS) {
    if (tracker.patterns.some((p) => html.includes(p.toLowerCase()))) {
      detected.push(tracker.name);
    }
  }

  return {
    id: "SC20",
    name: "Third-party trackers",
    description:
      "Detect third-party tracking scripts (Google Analytics, Facebook Pixel, ad scripts, etc.) across all discovered pages.",
    severity: "HIGH",
    status: detected.length > 0 ? "FAIL" : "PASS",
    details:
      detected.length > 0
        ? `Found ${detected.length} tracker(s): ${detected.join(", ")}`
        : "No third-party trackers detected.",
    metadata: { trackers: detected },
  };
}

/**
 * SC21: Trackers disclosed in privacy policy
 */
function checkTrackersDisclosed(ctx: ScanContext): CheckResult {
  if (!ctx.privacyPage) {
    return {
      id: "SC21",
      name: "Trackers disclosed in privacy policy",
      description:
        "Cross-reference detected trackers with privacy policy disclosures.",
      severity: "HIGH",
      status: "SKIP",
      details: ctx.siteBlocked
        ? "Skipped — site has bot protection that prevented automated scanning."
        : ctx.privacySpaDetected
          ? `Skipped — privacy policy page found at ${ctx.privacyPolicyUrl} but content is JavaScript-rendered and could not be fully analyzed. Use manual paste scanner for deeper analysis.`
          : "Privacy policy page not available for cross-referencing.",
    };
  }

  // Gather all HTML for tracker detection
  const htmlSources = [ctx.mainPage.html];
  for (const [, page] of ctx.crawl.fetchedPages) {
    if (page.url !== ctx.mainPage.url && page.url !== ctx.privacyPage?.url) {
      htmlSources.push(page.html);
    }
  }
  const mainHtml = htmlSources.join("\n").toLowerCase();

  // Gather all privacy-related text for disclosure checks
  const privacySources = [stripHtml(ctx.privacyPage.html)];
  for (const [, page] of ctx.crawl.fetchedPages) {
    if (page.url !== ctx.mainPage.url && page.url !== ctx.privacyPage?.url) {
      privacySources.push(stripHtml(page.html));
    }
  }
  const privacyText = privacySources.join(" ").toLowerCase();

  const detected: string[] = [];
  const disclosed: string[] = [];
  const undisclosed: string[] = [];

  for (const tracker of TRACKER_PATTERNS) {
    if (tracker.patterns.some((p) => mainHtml.includes(p.toLowerCase()))) {
      detected.push(tracker.name);

      // Check if disclosed in privacy policy or any crawled page
      const trackerWords = tracker.name.toLowerCase().split(" ");
      const isDisclosed = trackerWords.some((w) => privacyText.includes(w));

      if (isDisclosed) {
        disclosed.push(tracker.name);
      } else {
        undisclosed.push(tracker.name);
      }
    }
  }

  if (detected.length === 0) {
    return {
      id: "SC21",
      name: "Trackers disclosed in privacy policy",
      description:
        "Cross-reference detected trackers with privacy policy disclosures.",
      severity: "HIGH",
      status: "PASS",
      details: "No third-party trackers detected to cross-reference.",
    };
  }

  return {
    id: "SC21",
    name: "Trackers disclosed in privacy policy",
    description:
      "Cross-reference detected trackers with privacy policy disclosures.",
    severity: "HIGH",
    status: undisclosed.length === 0 ? "PASS" : "FAIL",
    details:
      undisclosed.length === 0
        ? `All ${detected.length} detected tracker(s) are disclosed in the privacy policy.`
        : `${undisclosed.length} tracker(s) not disclosed: ${undisclosed.join(", ")}`,
    metadata: { detected, disclosed, undisclosed },
  };
}

/**
 * SC22: Undisclosed data sharing
 */
function checkUndisclosedDataSharing(ctx: ScanContext): CheckResult {
  const html = ctx.mainPage.html;
  const mainHost = new URL(ctx.mainPage.url).hostname;

  // Find external domains referenced in scripts/iframes/img
  const externalRegex =
    /(?:src|href)\s*=\s*["'](https?:\/\/([^/"']+))[^"']*["']/gi;
  const externalDomains = new Set<string>();
  let match: RegExpExecArray | null;

  while ((match = externalRegex.exec(html)) !== null) {
    const domain = match[2].toLowerCase();
    if (
      domain !== mainHost &&
      !domain.endsWith(`.${mainHost}`) &&
      !domain.includes("w3.org") &&
      !domain.includes("schema.org")
    ) {
      externalDomains.add(domain);
    }
  }

  // Also scan crawled pages for external domains
  for (const [, page] of ctx.crawl.fetchedPages) {
    let pageMatch: RegExpExecArray | null;
    const pageRegex =
      /(?:src|href)\s*=\s*["'](https?:\/\/([^/"']+))[^"']*["']/gi;
    while ((pageMatch = pageRegex.exec(page.html)) !== null) {
      const domain = pageMatch[2].toLowerCase();
      if (
        domain !== mainHost &&
        !domain.endsWith(`.${mainHost}`) &&
        !domain.includes("w3.org") &&
        !domain.includes("schema.org")
      ) {
        externalDomains.add(domain);
      }
    }
  }

  if (!ctx.privacyPage || externalDomains.size === 0) {
    let skipDetails = "Privacy policy not available for cross-referencing external domains.";
    if (externalDomains.size === 0) {
      skipDetails = "No external domain references detected.";
    } else if (ctx.privacySpaDetected) {
      skipDetails = `Privacy policy page found at ${ctx.privacyPolicyUrl} but content is JavaScript-rendered and could not be fully analyzed. Use manual paste scanner for deeper analysis.`;
    }
    return {
      id: "SC22",
      name: "Undisclosed data sharing",
      description:
        "Check for outbound requests to domains not listed in the privacy policy.",
      severity: "MEDIUM",
      status: externalDomains.size === 0 ? "PASS" : "SKIP",
      details: skipDetails,
      metadata: { externalDomains: [...externalDomains] },
    };
  }

  // Gather all text for disclosure checks
  const privacySources = [stripHtml(ctx.privacyPage.html)];
  for (const [, page] of ctx.crawl.fetchedPages) {
    if (page.url !== ctx.mainPage.url) {
      privacySources.push(stripHtml(page.html));
    }
  }
  const privacyText = privacySources.join(" ").toLowerCase();
  const undisclosed: string[] = [];

  for (const domain of externalDomains) {
    const parts = domain.split(".");
    const coreName =
      parts.length >= 2 ? parts[parts.length - 2] : parts[0];

    if (coreName.length > 2 && !privacyText.includes(coreName)) {
      undisclosed.push(domain);
    }
  }

  return {
    id: "SC22",
    name: "Undisclosed data sharing",
    description:
      "Check for outbound requests to domains not listed in the privacy policy.",
    severity: "MEDIUM",
    status: undisclosed.length === 0 ? "PASS" : "FAIL",
    details:
      undisclosed.length === 0
        ? `All ${externalDomains.size} external domain(s) appear to be disclosed.`
        : `${undisclosed.length} external domain(s) not mentioned in privacy policy: ${undisclosed.slice(0, 5).join(", ")}`,
    metadata: {
      totalExternal: externalDomains.size,
      undisclosed: undisclosed.slice(0, 10),
    },
  };
}

export function runCollectionChecks(ctx: ScanContext): CheckResult[] {
  return [
    checkPersonalDataForms(ctx),
    checkThirdPartyTrackers(ctx),
    checkTrackersDisclosed(ctx),
    checkUndisclosedDataSharing(ctx),
  ];
}
