import { CheckResult, ScanContext } from "../types";
import { extractForms, FETCH_TIMEOUT, getBrowserHeaders } from "../utils";

const BLOCKED_SKIP: Partial<CheckResult> = {
  status: "SKIP" as const,
  details: "Skipped — site has bot protection that prevented automated scanning.",
};

/**
 * SC12: HTTPS with valid SSL
 */
function checkHttps(ctx: ScanContext): CheckResult {
  const url = new URL(ctx.mainPage.url);
  const isHttps = url.protocol === "https:";
  const isValidResponse = ctx.mainPage.statusCode >= 200 && ctx.mainPage.statusCode < 400;

  return {
    id: "SC12",
    name: "HTTPS with valid SSL",
    description: "Check if the website uses HTTPS with a valid SSL certificate.",
    severity: "CRITICAL",
    status: isHttps && isValidResponse ? "PASS" : "FAIL",
    details:
      isHttps && isValidResponse
        ? "Site is served over HTTPS with a valid response."
        : !isHttps
          ? "Site is not served over HTTPS."
          : `HTTPS is used but server returned status ${ctx.mainPage.statusCode}.`,
  };
}

/**
 * SC13: Security headers
 */
function checkSecurityHeaders(ctx: ScanContext): CheckResult {
  if (ctx.siteBlocked && ctx.mainPage.statusCode === 0) {
    return {
      id: "SC13",
      name: "Security headers",
      description: "Check for essential security headers.",
      severity: "HIGH",
      ...BLOCKED_SKIP,
    } as CheckResult;
  }
  const headers = ctx.mainPage.headers;

  const checks = [
    {
      name: "X-Content-Type-Options",
      present: headers.has("x-content-type-options"),
    },
    { name: "X-Frame-Options", present: headers.has("x-frame-options") },
    {
      name: "Content-Security-Policy",
      present:
        headers.has("content-security-policy") ||
        headers.has("content-security-policy-report-only"),
    },
    {
      name: "Strict-Transport-Security",
      present: headers.has("strict-transport-security"),
    },
    {
      name: "Referrer-Policy",
      present: headers.has("referrer-policy"),
    },
  ];

  const present = checks.filter((c) => c.present);
  const missing = checks.filter((c) => !c.present);

  return {
    id: "SC13",
    name: "Security headers",
    description:
      "Check for essential security headers: X-Content-Type-Options, X-Frame-Options, CSP, HSTS.",
    severity: "HIGH",
    status: present.length >= 3 ? "PASS" : "FAIL",
    details:
      present.length >= 3
        ? `${present.length}/5 security headers present: ${present.map((c) => c.name).join(", ")}`
        : `Only ${present.length}/5 security headers present. Missing: ${missing.map((c) => c.name).join(", ")}`,
    metadata: {
      present: present.map((c) => c.name),
      missing: missing.map((c) => c.name),
    },
  };
}

/**
 * SC14: Secure cookie flags
 */
function checkSecureCookies(ctx: ScanContext): CheckResult {
  const cookies = ctx.mainPage.cookies;

  if (cookies.length === 0) {
    return {
      id: "SC14",
      name: "Secure cookie flags",
      description:
        "Check if cookies have Secure, HttpOnly, and SameSite flags.",
      severity: "HIGH",
      status: "PASS",
      details: "No cookies set by the server on the main page.",
    };
  }

  const insecureCookies: string[] = [];

  for (const cookie of cookies) {
    const lower = cookie.toLowerCase();
    const name = cookie.split("=")[0]?.trim() || "unknown";
    const hasSecure = lower.includes("secure");
    const hasHttpOnly = lower.includes("httponly");

    if (!hasSecure || !hasHttpOnly) {
      insecureCookies.push(
        `${name} (missing: ${!hasSecure ? "Secure " : ""}${!hasHttpOnly ? "HttpOnly" : ""})`
      );
    }
  }

  return {
    id: "SC14",
    name: "Secure cookie flags",
    description:
      "Check if cookies have Secure, HttpOnly, and SameSite flags.",
    severity: "HIGH",
    status: insecureCookies.length === 0 ? "PASS" : "FAIL",
    details:
      insecureCookies.length === 0
        ? `All ${cookies.length} cookie(s) have Secure and HttpOnly flags.`
        : `Insecure cookies found: ${insecureCookies.join("; ")}`,
    metadata: { totalCookies: cookies.length, insecureCookies },
  };
}

/**
 * SC15: No mixed content
 */
function checkNoMixedContent(ctx: ScanContext): CheckResult {
  const url = new URL(ctx.mainPage.url);
  if (url.protocol !== "https:") {
    return {
      id: "SC15",
      name: "No mixed content",
      description:
        "Detect HTTP resources loaded on an HTTPS page (mixed content).",
      severity: "MEDIUM",
      status: "SKIP",
      details: "Site is not on HTTPS; mixed content check not applicable.",
    };
  }

  const html = ctx.mainPage.html;

  // Look for http:// references in src and href attributes (excluding links to other pages)
  const mixedContentRegex =
    /(?:src|action)\s*=\s*["']http:\/\/[^"']+["']/gi;
  const matches = html.match(mixedContentRegex) || [];

  // Filter out false positives (e.g., http://schema.org)
  const realMixed = matches.filter(
    (m) =>
      !m.includes("schema.org") &&
      !m.includes("xmlns") &&
      !m.includes("w3.org")
  );

  return {
    id: "SC15",
    name: "No mixed content",
    description:
      "Detect HTTP resources loaded on an HTTPS page (mixed content).",
    severity: "MEDIUM",
    status: realMixed.length === 0 ? "PASS" : "FAIL",
    details:
      realMixed.length === 0
        ? "No mixed content detected."
        : `Found ${realMixed.length} mixed content reference(s): ${realMixed.slice(0, 3).join(", ")}`,
    metadata: { count: realMixed.length, samples: realMixed.slice(0, 5) },
  };
}

/**
 * SC16: No exposed API endpoints
 */
async function checkNoExposedApis(ctx: ScanContext): Promise<CheckResult> {
  const baseUrl = new URL(ctx.mainPage.url);
  const testPaths = ["/api/users", "/api/data", "/api/admin", "/api/config"];
  const exposed: string[] = [];

  for (const path of testPaths) {
    try {
      const testUrl = new URL(path, baseUrl).href;
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT);

      try {
        const res = await fetch(testUrl, {
          signal: controller.signal,
          headers: getBrowserHeaders(0),
        });

        // If we get a 200 with JSON-like content, it might be exposed
        if (res.status === 200) {
          const contentType = res.headers.get("content-type") || "";
          if (contentType.includes("json")) {
            exposed.push(path);
          }
        }
      } finally {
        clearTimeout(timer);
      }
    } catch {
      // Network error or timeout — not exposed
    }
  }

  return {
    id: "SC16",
    name: "No exposed API endpoints",
    description:
      "Check common API paths for unauthenticated data exposure.",
    severity: "HIGH",
    status: exposed.length === 0 ? "PASS" : "FAIL",
    details:
      exposed.length === 0
        ? "No common API endpoints returned unauthenticated JSON data."
        : `Potentially exposed API endpoints: ${exposed.join(", ")}`,
    metadata: { exposed },
  };
}

/**
 * SC17: Server version hidden
 */
function checkServerVersionHidden(ctx: ScanContext): CheckResult {
  const serverHeader = ctx.mainPage.headers.get("server") || "";

  // Check if server header exposes version info
  const versionPattern = /\d+\.\d+/;
  const exposesVersion =
    serverHeader.length > 0 && versionPattern.test(serverHeader);

  // Also check X-Powered-By
  const poweredBy = ctx.mainPage.headers.get("x-powered-by") || "";
  const exposesPoweredBy = poweredBy.length > 0;

  const isHidden = !exposesVersion && !exposesPoweredBy;

  return {
    id: "SC17",
    name: "Server version hidden",
    description:
      "Check if Server header or X-Powered-By reveals version information.",
    severity: "MEDIUM",
    status: isHidden ? "PASS" : "FAIL",
    details: isHidden
      ? "Server version information is not exposed in headers."
      : `Server info exposed: ${exposesVersion ? `Server: ${serverHeader}` : ""} ${exposesPoweredBy ? `X-Powered-By: ${poweredBy}` : ""}`.trim(),
    metadata: { serverHeader, poweredBy },
  };
}

/**
 * SC18: Forms submit over HTTPS
 */
function checkFormsHttps(ctx: ScanContext): CheckResult {
  const forms = extractForms(ctx.mainPage.html);

  if (forms.length === 0) {
    return {
      id: "SC18",
      name: "Forms submit over HTTPS",
      description: "Check that all form actions use HTTPS.",
      severity: "CRITICAL",
      status: "PASS",
      details: "No forms detected on the page.",
    };
  }

  const insecureForms = forms.filter((f) => {
    if (!f.action || f.action === "" || f.action.startsWith("/") || f.action.startsWith("#")) {
      // Relative or empty actions inherit page protocol — OK if page is HTTPS
      return false;
    }
    return f.action.startsWith("http://");
  });

  return {
    id: "SC18",
    name: "Forms submit over HTTPS",
    description: "Check that all form actions use HTTPS.",
    severity: "CRITICAL",
    status: insecureForms.length === 0 ? "PASS" : "FAIL",
    details:
      insecureForms.length === 0
        ? `All ${forms.length} form(s) submit over HTTPS or use relative URLs.`
        : `${insecureForms.length} form(s) submit over insecure HTTP.`,
    metadata: {
      totalForms: forms.length,
      insecureCount: insecureForms.length,
    },
  };
}

export async function runSecurityChecks(
  ctx: ScanContext
): Promise<CheckResult[]> {
  const syncResults = [
    checkHttps(ctx),
    checkSecurityHeaders(ctx),
    checkSecureCookies(ctx),
    checkNoMixedContent(ctx),
    checkServerVersionHidden(ctx),
    checkFormsHttps(ctx),
  ];

  const apiCheck = await checkNoExposedApis(ctx);

  return [...syncResults, apiCheck];
}
