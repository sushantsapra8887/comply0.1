import { CheckResult, ScanContext } from "../types";
import {
  containsAny,
  countMatches,
  stripHtml,
  findLinksMatching,
} from "../utils";

/**
 * Get combined text from all relevant crawled pages (main + privacy + any
 * additional pages discovered by the deep crawler).
 */
function getAllRelevantText(ctx: ScanContext): string {
  const sources = [stripHtml(ctx.mainPage.html)];
  if (ctx.privacyPage) {
    sources.push(stripHtml(ctx.privacyPage.html));
  }
  // Include text from all fetched pages discovered during deep crawl
  for (const [, page] of ctx.crawl.fetchedPages) {
    if (page.url !== ctx.mainPage.url && page.url !== ctx.privacyPage?.url) {
      sources.push(stripHtml(page.html));
    }
  }
  return sources.join(" ");
}

/**
 * SC01: Privacy Policy page exists
 *
 * Uses the deep crawler's comprehensive 6-step detection:
 * 1. All <a> links from homepage (including footer)
 * 2. URL pattern matching against comprehensive list
 * 3. Link text matching against keywords
 * 4. Inline privacy content in terms/legal pages
 * 5. Sitemap.xml check
 * 6. Common direct URL probing
 */
function checkPrivacyPolicyExists(ctx: ScanContext): CheckResult {
  const crawl = ctx.crawl;
  const found = ctx.privacyPolicyUrl !== null;
  const isEmbedded = ctx.privacyEmbeddedIn !== null;

  // Determine detection method for reporting
  let method = crawl.privacyDetectionMethod;
  if (method === "none") method = "not found";

  // Build detailed metadata
  const footerLinks = crawl.privacyLinks.filter((l) => l.source === "footer");
  const pageLinks = crawl.privacyLinks.filter((l) => l.source === "page");
  const scriptLinks = crawl.privacyLinks.filter((l) => l.source === "script");
  const rawHtmlLinks = crawl.privacyLinks.filter((l) => l.source === "raw-html");
  const sitemapLinks = crawl.privacyLinks.filter((l) => l.source === "sitemap");
  const probeLinks = crawl.privacyLinks.filter((l) => l.source === "probe");

  let details: string;
  let status: "PASS" | "FAIL" | "SKIP";

  if (found && isEmbedded) {
    details = `Privacy policy found within "${ctx.privacyEmbeddedIn}" but should be a standalone page per DPDP Rule 3: ${ctx.privacyPolicyUrl}`;
    status = "PASS";
  } else if (found && ctx.privacySpaDetected) {
    details = `Privacy policy page found at ${ctx.privacyPolicyUrl}. Content analysis limited due to JavaScript rendering (single-page application). For a deeper scan, use our manual paste scanner.`;
    status = "PASS";
  } else if (found) {
    details = `Privacy policy detected via ${method}: ${ctx.privacyPolicyUrl}`;
    status = "PASS";
  } else if (ctx.siteBlocked) {
    details =
      "This website has bot protection that prevents automated scanning. This does NOT mean they lack a privacy policy. Manual review recommended.";
    status = "SKIP";
  } else {
    details =
      "No privacy policy found after comprehensive 5-step detection: checked direct URL probes, all page links, footer links, script data, sitemap.xml, CORS proxy, and legal/terms pages.";
    status = "FAIL";
  }

  return {
    id: "SC01",
    name: "Privacy Policy page exists",
    description:
      "Check if the website has a linked privacy policy page accessible from the main page using comprehensive 5-step detection.",
    severity: "CRITICAL",
    status,
    details,
    metadata: {
      detectedUrl: ctx.privacyPolicyUrl,
      method,
      isEmbedded,
      embeddedIn: ctx.privacyEmbeddedIn,
      linksFoundInPage: pageLinks.length,
      linksFoundInFooter: footerLinks.length,
      linksFoundInScripts: scriptLinks.length,
      linksFoundInRawHtml: rawHtmlLinks.length,
      linksFoundInSitemap: sitemapLinks.length,
      linksFoundByProbing: probeLinks.length,
      totalPrivacyLinksFound: crawl.privacyLinks.length,
      totalLinksDiscovered: crawl.allLinks.length,
      siteBlocked: ctx.siteBlocked,
    },
  };
}

/**
 * SC02: Notice is standalone
 */
function checkNoticeStandalone(ctx: ScanContext): CheckResult {
  if (!ctx.privacyPage) {
    return {
      id: "SC02",
      name: "Notice is standalone",
      description:
        "Check if the privacy notice is a separate page, not embedded in Terms of Service.",
      severity: "MEDIUM",
      status: "SKIP",
      details: ctx.siteBlocked
        ? "Skipped — site has bot protection that prevented automated scanning."
        : ctx.privacySpaDetected
          ? `Skipped — privacy policy page found at ${ctx.privacyPolicyUrl} but content is JavaScript-rendered and could not be fully analyzed. Use manual paste scanner for deeper analysis.`
          : "Privacy policy page not available for analysis.",
    };
  }

  // If we detected it as embedded, that's already known
  if (ctx.privacyEmbeddedIn) {
    return {
      id: "SC02",
      name: "Notice is standalone",
      description:
        "Check if the privacy notice is a separate page, not embedded in Terms of Service.",
      severity: "MEDIUM",
      status: "FAIL",
      details: `Privacy notice is embedded within "${ctx.privacyEmbeddedIn}" rather than being a standalone page. Per DPDP Rule 3, it should be a dedicated page.`,
    };
  }

  const privacyUrl = (ctx.privacyPolicyUrl || "").toLowerCase();
  const privacyText = stripHtml(ctx.privacyPage.html).toLowerCase();

  // Check if it's embedded in TOS
  const isEmbeddedInTos =
    (privacyUrl.includes("terms") || privacyUrl.includes("tos")) &&
    !privacyUrl.includes("privacy");

  // Check if page title or heading is about terms rather than privacy
  const titleRegex = /<title[^>]*>([\s\S]*?)<\/title>/i;
  const titleMatch = ctx.privacyPage.html.match(titleRegex);
  const title = titleMatch ? titleMatch[1].toLowerCase() : "";

  const isTosTitle =
    (title.includes("terms") || title.includes("conditions")) &&
    !title.includes("privacy");

  // Check if the word "privacy" appears prominently (as heading)
  const hasPrivacyHeading =
    /<h[1-3][^>]*>[^<]*privac[yi]/i.test(ctx.privacyPage.html) ||
    /<h[1-3][^>]*>[^<]*data\s*protection/i.test(ctx.privacyPage.html);

  const isStandalone =
    !isEmbeddedInTos &&
    !isTosTitle &&
    (hasPrivacyHeading || privacyText.length > 500);

  return {
    id: "SC02",
    name: "Notice is standalone",
    description:
      "Check if the privacy notice is a separate page, not embedded in Terms of Service.",
    severity: "MEDIUM",
    status: isStandalone ? "PASS" : "FAIL",
    details: isStandalone
      ? "Privacy notice appears to be a standalone page."
      : "Privacy notice may be embedded within Terms of Service or is not a dedicated page.",
  };
}

/**
 * SC03: Lists what data is collected
 */
function checkDataCollectionListed(ctx: ScanContext): CheckResult {
  if (!ctx.privacyPage) {
    return {
      id: "SC03",
      name: "Lists what data is collected",
      description:
        "Check if the privacy policy describes what personal data is collected.",
      severity: "HIGH",
      status: "SKIP",
      details: ctx.siteBlocked
        ? "Skipped — site has bot protection that prevented automated scanning."
        : ctx.privacySpaDetected
          ? `Skipped — privacy policy page found at ${ctx.privacyPolicyUrl} but content is JavaScript-rendered and could not be fully analyzed. Use manual paste scanner for deeper analysis.`
          : "Privacy policy page not available for analysis.",
    };
  }

  const text = getAllRelevantText(ctx);
  const keywords = [
    "collect",
    "personal data",
    "personal information",
    "information we collect",
    "data we collect",
    "data collected",
    "categories of data",
    "types of information",
    "types of data",
  ];

  const found = countMatches(text, keywords);

  return {
    id: "SC03",
    name: "Lists what data is collected",
    description:
      "Check if the privacy policy describes what personal data is collected.",
    severity: "HIGH",
    status: found.length > 0 ? "PASS" : "FAIL",
    details:
      found.length > 0
        ? `Found data collection references: ${found.join(", ")}`
        : "No mention of data collection found in the privacy policy.",
    metadata: { matchedKeywords: found },
  };
}

/**
 * SC04: States purpose of processing
 */
function checkPurposeStated(ctx: ScanContext): CheckResult {
  if (!ctx.privacyPage) {
    return {
      id: "SC04",
      name: "States purpose of processing",
      description:
        "Check if the privacy policy explains why personal data is processed.",
      severity: "HIGH",
      status: "SKIP",
      details: ctx.siteBlocked
        ? "Skipped — site has bot protection that prevented automated scanning."
        : ctx.privacySpaDetected
          ? `Skipped — privacy policy page found at ${ctx.privacyPolicyUrl} but content is JavaScript-rendered and could not be fully analyzed. Use manual paste scanner for deeper analysis.`
          : "Privacy policy page not available for analysis.",
    };
  }

  const text = getAllRelevantText(ctx);
  const keywords = [
    "purpose",
    "why we collect",
    "use your data",
    "use your information",
    "how we use",
    "processing activities",
    "reasons for processing",
    "basis for processing",
    "lawful basis",
  ];

  const found = countMatches(text, keywords);

  return {
    id: "SC04",
    name: "States purpose of processing",
    description:
      "Check if the privacy policy explains why personal data is processed.",
    severity: "HIGH",
    status: found.length > 0 ? "PASS" : "FAIL",
    details:
      found.length > 0
        ? `Found purpose statements: ${found.join(", ")}`
        : "No purpose of data processing found in the privacy policy.",
    metadata: { matchedKeywords: found },
  };
}

/**
 * SC05: Mentions user rights
 */
function checkUserRightsMentioned(ctx: ScanContext): CheckResult {
  if (!ctx.privacyPage) {
    return {
      id: "SC05",
      name: "Mentions user rights",
      description:
        "Check if the privacy policy mentions data principal/user rights.",
      severity: "HIGH",
      status: "SKIP",
      details: ctx.siteBlocked
        ? "Skipped — site has bot protection that prevented automated scanning."
        : ctx.privacySpaDetected
          ? `Skipped — privacy policy page found at ${ctx.privacyPolicyUrl} but content is JavaScript-rendered and could not be fully analyzed. Use manual paste scanner for deeper analysis.`
          : "Privacy policy page not available for analysis.",
    };
  }

  const text = getAllRelevantText(ctx);
  const keywords = [
    "your rights",
    "right to access",
    "right to erasure",
    "right to rectification",
    "right to deletion",
    "data principal",
    "data subject rights",
    "rights of the user",
    "right to withdraw",
    "right to complain",
    "right to port",
  ];

  const found = countMatches(text, keywords);

  return {
    id: "SC05",
    name: "Mentions user rights",
    description:
      "Check if the privacy policy mentions data principal/user rights.",
    severity: "HIGH",
    status: found.length > 0 ? "PASS" : "FAIL",
    details:
      found.length > 0
        ? `Found user rights references: ${found.join(", ")}`
        : "No mention of user/data principal rights in the privacy policy.",
    metadata: { matchedKeywords: found },
  };
}

/**
 * SC06: Has withdrawal + rights + complaint links
 */
function checkRightsLinks(ctx: ScanContext): CheckResult {
  if (!ctx.privacyPage) {
    return {
      id: "SC06",
      name: "Has withdrawal + rights + complaint links",
      description:
        "Check for clickable links for consent withdrawal, exercising rights, and filing DPB complaints.",
      severity: "MEDIUM",
      status: "SKIP",
      details: ctx.siteBlocked
        ? "Skipped — site has bot protection that prevented automated scanning."
        : ctx.privacySpaDetected
          ? `Skipped — privacy policy page found at ${ctx.privacyPolicyUrl} but content is JavaScript-rendered and could not be fully analyzed. Use manual paste scanner for deeper analysis.`
          : "Privacy policy page not available for analysis.",
    };
  }

  const keywords = [
    "withdraw",
    "opt out",
    "opt-out",
    "unsubscribe",
    "manage consent",
    "manage preferences",
    "exercise your rights",
    "data request",
    "delete my data",
    "complaint",
    "grievance",
    "data protection board",
    "dpb",
    "dpo",
    "contact us",
  ];

  // Search in privacy page and all rights-related crawled pages
  const allLinks = findLinksMatching(
    ctx.privacyPage.html,
    ctx.privacyPolicyUrl || ctx.mainPage.url,
    keywords
  );

  // Also search in any rights-related crawled pages
  for (const [, page] of ctx.crawl.fetchedPages) {
    if (page.url !== ctx.privacyPage?.url && page.url !== ctx.mainPage.url) {
      const pageLinks = findLinksMatching(page.html, page.url, keywords);
      for (const link of pageLinks) {
        if (!allLinks.some((l) => l.href === link.href)) {
          allLinks.push(link);
        }
      }
    }
  }

  return {
    id: "SC06",
    name: "Has withdrawal + rights + complaint links",
    description:
      "Check for clickable links for consent withdrawal, exercising rights, and filing DPB complaints.",
    severity: "MEDIUM",
    status: allLinks.length >= 2 ? "PASS" : "FAIL",
    details:
      allLinks.length >= 2
        ? `Found ${allLinks.length} relevant links: ${allLinks.map((l) => l.text || l.href).join(", ")}`
        : `Found only ${allLinks.length} relevant link(s). Expected at least 2 for withdrawal, rights, or complaint.`,
    metadata: { links: allLinks },
  };
}

export function runNoticeChecks(ctx: ScanContext): CheckResult[] {
  return [
    checkPrivacyPolicyExists(ctx),
    checkNoticeStandalone(ctx),
    checkDataCollectionListed(ctx),
    checkPurposeStated(ctx),
    checkUserRightsMentioned(ctx),
    checkRightsLinks(ctx),
  ];
}
