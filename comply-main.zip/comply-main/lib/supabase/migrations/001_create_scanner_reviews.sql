-- Migration: Create scanner_reviews table
-- Description: Stores user ratings and optional reviews collected before PDF report download

CREATE TABLE IF NOT EXISTS scanner_reviews (
  id              UUID        DEFAULT gen_random_uuid() PRIMARY KEY,
  email           TEXT        NOT NULL,
  company_name    TEXT        NOT NULL,
  rating          INTEGER     NOT NULL CHECK (rating >= 1 AND rating <= 5),
  review          TEXT,
  scan_id         UUID        REFERENCES scan_reports(id) ON DELETE SET NULL,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_scanner_reviews_email
  ON scanner_reviews (email);

CREATE INDEX IF NOT EXISTS idx_scanner_reviews_scan_id
  ON scanner_reviews (scan_id);

-- Enable RLS
ALTER TABLE scanner_reviews ENABLE ROW LEVEL SECURITY;

-- Anyone can insert reviews (public form, no auth required)
CREATE POLICY "Anyone can insert scanner reviews"
  ON scanner_reviews FOR INSERT
  WITH CHECK (true);

-- Only service role can read reviews (admin access only)
CREATE POLICY "Service role can read scanner reviews"
  ON scanner_reviews FOR SELECT
  USING (false);

COMMENT ON TABLE scanner_reviews IS 'User ratings and optional reviews collected before PDF report download';
COMMENT ON COLUMN scanner_reviews.rating IS 'Star rating from 1 to 5';
COMMENT ON COLUMN scanner_reviews.review IS 'Optional written feedback from the user';
