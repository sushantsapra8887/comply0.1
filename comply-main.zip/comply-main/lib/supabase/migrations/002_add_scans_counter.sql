-- Add counter column to scans: number of times this (user_id, url) has been scanned
ALTER TABLE scans
  ADD COLUMN IF NOT EXISTS counter INTEGER NOT NULL DEFAULT 0;

COMMENT ON COLUMN scans.counter IS 'Number of times this user has scanned this URL (0 = first scan)';
