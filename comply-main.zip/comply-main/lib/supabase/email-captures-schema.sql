-- Email captures for gating PDF report downloads
CREATE TABLE email_captures (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  email TEXT NOT NULL,
  scan_id UUID,
  user_id UUID REFERENCES auth.users(id),
  captured_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for quick lookup by email
CREATE INDEX idx_email_captures_email ON email_captures(email);

-- Enable RLS
ALTER TABLE email_captures ENABLE ROW LEVEL SECURITY;

-- Anyone can insert (email capture happens before/during auth)
CREATE POLICY "Anyone can insert email capture" ON email_captures FOR INSERT WITH CHECK (true);

-- Users can view their own captures
CREATE POLICY "Users can view own captures" ON email_captures FOR SELECT USING (auth.uid() = user_id);
