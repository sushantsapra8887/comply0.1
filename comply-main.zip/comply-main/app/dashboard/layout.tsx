import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { DashboardShell } from "./dashboard-shell";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login");
  }

  const companyName = user.user_metadata?.company_name || "My Company";
  const userEmail = user.email || "";

  return (
    <DashboardShell companyName={companyName} userEmail={userEmail}>
      {children}
    </DashboardShell>
  );
}
