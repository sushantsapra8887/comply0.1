"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";
import { ReviewModal } from "@/components/ReviewModal";

interface ScanRecord {
  id: string;
  url: string;
  score: number;
  grade: string;
  checks: Array<{ id: string; status: string; name: string; details: string; severity?: string; description?: string }>;
  summary: { total: number; passed: number; failed: number; skipped: number; info: number };
  scanned_at: string;
  site_blocked?: boolean;
  blocked_message?: string | null;
}

const gradeColor: Record<string, string> = {
  A: "bg-green-50 text-green-700",
  B: "bg-blue-50 text-blue-700",
  C: "bg-yellow-50 text-yellow-700",
  D: "bg-orange-50 text-orange-700",
  F: "bg-red-50 text-red-700",
};

export function ReportsTable({ scans }: { scans: ScanRecord[] }) {
  const [url, setUrl] = useState("");
  const [scanning, setScanning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [emailGateScanId, setEmailGateScanId] = useState<string | null>(null);
  const [downloadingScanId, setDownloadingScanId] = useState<string | null>(null);
  const [capturedEmails, setCapturedEmails] = useState<Set<string>>(new Set());
  const router = useRouter();

  async function handleNewScan(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setScanning(true);

    try {
      const supabase = createClient();
      const { data: { session } } = await supabase.auth.getSession();

      const res = await fetch("/api/scan", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(session?.access_token
            ? { Authorization: `Bearer ${session.access_token}` }
            : {}),
        },
        body: JSON.stringify({ url }),
      });

      if (!res.ok) {
        const body = await res.json();
        throw new Error(body.error || "Scan failed");
      }

      setUrl("");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setScanning(false);
    }
  }

  function handleDownloadClick(scanId: string) {
    if (capturedEmails.has(scanId)) {
      downloadPdf(scanId);
    } else {
      setEmailGateScanId(scanId);
    }
  }

  async function downloadPdf(scanId: string) {
    const scan = scans.find((s) => s.id === scanId);
    if (!scan) return;

    setDownloadingScanId(scanId);
    try {
      const res = await fetch("/api/report/pdf", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scan }),
      });

      if (!res.ok) throw new Error("Failed to generate PDF");

      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `dpdp-report-${scan.url.replace(/https?:\/\//, "").replace(/[^a-zA-Z0-9.-]/g, "_")}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch {
      setError("Failed to download PDF report");
    } finally {
      setDownloadingScanId(null);
    }
  }

  function handleEmailGateSuccess(scanId: string) {
    setCapturedEmails((prev) => new Set(prev).add(scanId));
    setEmailGateScanId(null);
    downloadPdf(scanId);
  }

  return (
    <div className="space-y-6">
      {/* Review modal (replaces email gate) */}
      <ReviewModal
        isOpen={emailGateScanId !== null}
        onClose={() => setEmailGateScanId(null)}
        onSuccess={() => emailGateScanId && handleEmailGateSuccess(emailGateScanId)}
        scanId={emailGateScanId || ""}
      />

      {/* New scan form */}
      <div className="bg-white rounded-lg border border-gray-200 p-5">
        <h2 className="text-sm font-semibold text-gray-700 mb-3">New Scan</h2>
        <form onSubmit={handleNewScan} className="flex gap-3">
          <input
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            required
            placeholder="https://example.com"
            className="flex-1 px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <button
            type="submit"
            disabled={scanning}
            className="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors whitespace-nowrap"
          >
            {scanning ? "Scanning..." : "Run Scan"}
          </button>
        </form>
        {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
      </div>

      {/* Reports table */}
      <div className="bg-white rounded-lg border border-gray-200">
        {scans.length === 0 ? (
          <div className="px-5 py-12 text-center">
            <p className="text-sm text-gray-500">No scan reports yet.</p>
            <p className="text-xs text-gray-400 mt-1">
              Run your first scan above to get started.
            </p>
          </div>
        ) : (
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider px-5 py-3">
                  Date
                </th>
                <th className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider px-5 py-3">
                  URL
                </th>
                <th className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider px-5 py-3">
                  Score
                </th>
                <th className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider px-5 py-3">
                  Grade
                </th>
                <th className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider px-5 py-3">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {scans.map((scan) => (
                <>
                  <tr key={scan.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-5 py-3 text-sm text-gray-600 whitespace-nowrap">
                      {new Date(scan.scanned_at).toLocaleDateString()}
                    </td>
                    <td className="px-5 py-3 text-sm text-gray-900 font-medium truncate max-w-xs">
                      {scan.url}
                    </td>
                    <td className="px-5 py-3 text-sm text-gray-900 font-medium">
                      {scan.score}/100
                    </td>
                    <td className="px-5 py-3">
                      <span className="flex items-center gap-1.5">
                        <span
                          className={`text-xs font-semibold px-2 py-0.5 rounded ${
                            gradeColor[scan.grade] || "bg-gray-100 text-gray-600"
                          }`}
                        >
                          {scan.grade}
                        </span>
                        {scan.site_blocked && (
                          <span className="text-xs font-medium px-2 py-0.5 rounded bg-amber-50 text-amber-700" title={scan.blocked_message || "Site has bot protection"}>
                            Scan limited
                          </span>
                        )}
                      </span>
                    </td>
                    <td className="px-5 py-3 flex items-center gap-3">
                      <button
                        onClick={() =>
                          setExpandedId(expandedId === scan.id ? null : scan.id)
                        }
                        className="text-sm text-blue-600 hover:underline"
                      >
                        {expandedId === scan.id ? "Hide" : "View"}
                      </button>
                      <button
                        onClick={() => handleDownloadClick(scan.id)}
                        disabled={downloadingScanId === scan.id}
                        className="inline-flex items-center gap-1 text-sm text-green-700 bg-green-50 px-2.5 py-1 rounded-md hover:bg-green-100 disabled:opacity-50 transition-colors"
                      >
                        <svg
                          className="w-3.5 h-3.5"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                          />
                        </svg>
                        {downloadingScanId === scan.id ? "..." : "PDF"}
                      </button>
                    </td>
                  </tr>
                  {expandedId === scan.id && (
                    <tr key={`${scan.id}-detail`}>
                      <td colSpan={5} className="px-5 py-4 bg-gray-50">
                        <div className="space-y-3">
                          {scan.site_blocked && scan.blocked_message && (
                            <div className="flex items-start gap-2 bg-amber-50 border border-amber-200 rounded-md px-3 py-2">
                              <span className="text-amber-600 text-sm mt-0.5">&#9888;</span>
                              <p className="text-xs text-amber-700">{scan.blocked_message}</p>
                            </div>
                          )}
                          <div className="flex gap-4 text-xs text-gray-500">
                            <span>Passed: {scan.summary.passed}</span>
                            <span>Failed: {scan.summary.failed}</span>
                            <span>Skipped: {scan.summary.skipped}</span>
                            <span>Info: {scan.summary.info}</span>
                            {scan.summary.skipped > 0 && (
                              <span className="text-amber-600 font-medium">
                                {scan.summary.passed + scan.summary.failed}/{scan.summary.total} checks completed ({scan.summary.skipped} skipped due to site restrictions)
                              </span>
                            )}
                          </div>
                          <div className="grid grid-cols-1 gap-1.5">
                            {scan.checks.map((check) => (
                              <div
                                key={check.id}
                                className="flex items-center gap-3 text-sm"
                              >
                                <span
                                  className={`w-2 h-2 rounded-full flex-shrink-0 ${
                                    check.status === "PASS"
                                      ? "bg-green-500"
                                      : check.status === "FAIL"
                                      ? "bg-red-500"
                                      : check.status === "INFO"
                                      ? "bg-blue-500"
                                      : "bg-gray-300"
                                  }`}
                                />
                                <span className="text-gray-600 font-mono text-xs w-10">
                                  {check.id}
                                </span>
                                <span className="text-gray-800">{check.name}</span>
                                <span className="ml-auto text-xs text-gray-400 max-w-xs truncate">
                                  {check.details}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
