import { createClient } from "@/lib/supabase/server";
import { ReportsTable } from "./reports-table";

interface ScanRecord {
  id: string;
  url: string;
  score: number;
  grade: string;
  checks: Array<{ id: string; status: string; name: string; details: string }>;
  summary: { total: number; passed: number; failed: number; skipped: number; info: number };
  scanned_at: string;
}

export default async function ReportsPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  let scans: ScanRecord[] = [];
  if (user) {
    const { data } = await supabase
      .from("scans")
      .select("*")
      .eq("user_id", user.id)
      .order("scanned_at", { ascending: false });
    scans = (data as ScanRecord[] | null) ?? [];
  }

  return (
    <div className="max-w-5xl">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-xl font-bold text-gray-900">Scan Reports</h1>
      </div>
      <ReportsTable scans={scans} />
    </div>
  );
}
