"use client";

import Link from "next/link";

type ChecklistStatus = "compliant" | "non_compliant" | "not_checked";

interface ChecklistItem {
  id: number;
  name: string;
  section: string;
  actionType: "scanner" | "coming_soon";
  status: ChecklistStatus;
  checked: boolean;
}

const statusConfig: Record<
  ChecklistStatus,
  { label: string; className: string }
> = {
  compliant: { label: "Compliant", className: "bg-green-50 text-green-700" },
  non_compliant: { label: "Non-Compliant", className: "bg-red-50 text-red-700" },
  not_checked: { label: "Not Checked", className: "bg-gray-100 text-gray-500" },
};

export function ComplianceChecklist({ items }: { items: ChecklistItem[] }) {
  return (
    <div className="bg-white rounded-lg border border-gray-200">
      <div className="px-5 py-4 border-b border-gray-200">
        <h2 className="text-sm font-semibold text-gray-700">
          10-Point DPDP Compliance Checklist
        </h2>
        <p className="text-xs text-gray-400 mt-0.5">
          Based on Digital Personal Data Protection Act, 2023 — Appendix E
        </p>
      </div>

      <div className="divide-y divide-gray-100">
        {items.map((item) => {
          const status = statusConfig[item.status];
          return (
            <div
              key={item.id}
              className="flex items-center gap-4 px-5 py-3.5 hover:bg-gray-50 transition-colors"
            >
              {/* Checkbox */}
              <div
                className={`w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0 ${
                  item.checked
                    ? "bg-green-600 border-green-600"
                    : "border-gray-300 bg-white"
                }`}
              >
                {item.checked && (
                  <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                  </svg>
                )}
              </div>

              {/* Item details */}
              <div className="flex-1 min-w-0">
                <p className="text-sm text-gray-900">{item.name}</p>
                <p className="text-xs text-gray-400">{item.section}</p>
              </div>

              {/* Status badge */}
              <span
                className={`text-xs font-medium px-2 py-0.5 rounded ${status.className}`}
              >
                {status.label}
              </span>

              {/* Action link */}
              {item.actionType === "scanner" ? (
                <Link
                  href="/dashboard/reports"
                  className="text-xs text-blue-600 hover:underline whitespace-nowrap"
                >
                  View Scanner
                </Link>
              ) : (
                <span className="text-xs text-gray-400 whitespace-nowrap">
                  Coming Soon
                </span>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
