import { createClient } from "@/lib/supabase/server";

export default async function SettingsPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const companyName = user?.user_metadata?.company_name || "";
  const email = user?.email || "";

  return (
    <div className="max-w-2xl">
      <h1 className="text-xl font-bold text-gray-900 mb-6">Settings</h1>

      <div className="bg-white rounded-lg border border-gray-200 divide-y divide-gray-200">
        <div className="p-5">
          <h2 className="text-sm font-semibold text-gray-700 mb-4">Account</h2>
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">
                Email
              </label>
              <p className="text-sm text-gray-900">{email}</p>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">
                Company Name
              </label>
              <p className="text-sm text-gray-900">{companyName || "Not set"}</p>
            </div>
          </div>
        </div>

        <div className="p-5">
          <h2 className="text-sm font-semibold text-gray-700 mb-2">
            Supabase Configuration
          </h2>
          <p className="text-xs text-gray-400">
            Set <code className="bg-gray-100 px-1 rounded">NEXT_PUBLIC_SUPABASE_URL</code> and{" "}
            <code className="bg-gray-100 px-1 rounded">NEXT_PUBLIC_SUPABASE_ANON_KEY</code> in
            your environment to enable authentication and data persistence.
          </p>
        </div>

        <div className="p-5">
          <h2 className="text-sm font-semibold text-gray-700 mb-2">
            Google OAuth (Optional)
          </h2>
          <p className="text-xs text-gray-400">
            Configure Google OAuth in your Supabase dashboard under Authentication &rarr;
            Providers &rarr; Google. Set the redirect URL to{" "}
            <code className="bg-gray-100 px-1 rounded">/auth/callback</code>.
          </p>
        </div>
      </div>
    </div>
  );
}
