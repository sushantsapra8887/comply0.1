import { createClient } from "@/lib/supabase/server";
import { ComplianceChecklist } from "./compliance-checklist";

// Map scanner check IDs to the 10-point compliance checklist items
const CHECKLIST_ITEMS: Array<{
  id: number;
  name: string;
  section: string;
  scannerCheckIds: string[];
  actionType: "scanner" | "coming_soon";
}> = [
  {
    id: 1,
    name: "Privacy Notice displayed before consent?",
    section: "Sec 5",
    scannerCheckIds: ["SC01", "SC02"],
    actionType: "scanner" as const,
  },
  {
    id: 2,
    name: "Consent is free, specific, and affirmative?",
    section: "Sec 6",
    scannerCheckIds: ["SC07", "SC08", "SC09"],
    actionType: "scanner" as const,
  },
  {
    id: 3,
    name: 'Easy "Withdraw Consent" mechanism?',
    section: "Sec 6(4)",
    scannerCheckIds: ["SC10", "SC11"],
    actionType: "scanner" as const,
  },
  {
    id: 4,
    name: "Reasonable security safeguards in place?",
    section: "Sec 8(5)",
    scannerCheckIds: ["SC12", "SC13", "SC14", "SC15", "SC16", "SC17", "SC18"],
    actionType: "scanner" as const,
  },
  {
    id: 5,
    name: "Valid contracts with all Data Processors?",
    section: "Sec 8(2)",
    scannerCheckIds: [],
    actionType: "coming_soon" as const,
  },
  {
    id: 6,
    name: "Breach notification protocol exists?",
    section: "Sec 8(6)",
    scannerCheckIds: [],
    actionType: "coming_soon" as const,
  },
  {
    id: 7,
    name: "Data erasure process when purpose served?",
    section: "Sec 8(7)",
    scannerCheckIds: [],
    actionType: "coming_soon" as const,
  },
  {
    id: 8,
    name: "Grievance Officer contact published?",
    section: "Sec 13",
    scannerCheckIds: ["SC23", "SC24"],
    actionType: "scanner" as const,
  },
  {
    id: 9,
    name: "Age gate + parental consent for <18?",
    section: "Sec 9",
    scannerCheckIds: ["SC27", "SC28"],
    actionType: "scanner" as const,
  },
  {
    id: 10,
    name: "Can generate data summary if user asks?",
    section: "Sec 11",
    scannerCheckIds: [],
    actionType: "coming_soon" as const,
  },
];

interface ScanRecord {
  id: string;
  url: string;
  score: number;
  grade: string;
  checks: Array<{ id: string; status: string }>;
  scanned_at: string;
}

export default async function DashboardPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  // Fetch latest scan
  let latestScan: ScanRecord | null = null;
  if (user) {
    const { data } = await supabase
      .from("scans")
      .select("*")
      .eq("user_id", user.id)
      .order("scanned_at", { ascending: false })
      .limit(1)
      .single();
    latestScan = data as ScanRecord | null;
  }

  // Derive compliance status from latest scan
  const checklistWithStatus = CHECKLIST_ITEMS.map((item) => {
    if (item.scannerCheckIds.length === 0) {
      return { ...item, status: "not_checked" as const, checked: false };
    }

    if (!latestScan) {
      return { ...item, status: "not_checked" as const, checked: false };
    }

    const relevantChecks = latestScan.checks.filter((c) =>
      item.scannerCheckIds.includes(c.id)
    );

    if (relevantChecks.length === 0) {
      return { ...item, status: "not_checked" as const, checked: false };
    }

    const allPassed = relevantChecks.every((c) => c.status === "PASS" || c.status === "INFO");
    return {
      ...item,
      status: allPassed ? ("compliant" as const) : ("non_compliant" as const),
      checked: allPassed,
    };
  });

  const compliantCount = checklistWithStatus.filter((i) => i.status === "compliant").length;
  const checkableItems = checklistWithStatus.filter((i) => i.scannerCheckIds.length > 0).length;
  const overallScore = latestScan ? latestScan.score : null;

  // Deadline countdown
  const deadline = new Date("2027-05-13");
  const now = new Date();
  const daysLeft = Math.ceil((deadline.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

  return (
    <div className="max-w-4xl">
      <h1 className="text-xl font-bold text-gray-900 mb-6">Compliance Overview</h1>

      {/* Top stats row */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        {/* Compliance score */}
        <div className="bg-white rounded-lg border border-gray-200 p-5">
          <p className="text-sm font-medium text-gray-500 mb-1">Compliance Score</p>
          {overallScore !== null ? (
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-bold text-gray-900">{overallScore}</span>
              <span className="text-lg text-gray-400">/100</span>
            </div>
          ) : (
            <p className="text-2xl font-bold text-gray-300">--</p>
          )}
          <p className="text-xs text-gray-400 mt-1">
            {overallScore !== null
              ? `Grade: ${latestScan?.grade}`
              : "Run a scan to see your score"}
          </p>
        </div>

        {/* Checklist progress */}
        <div className="bg-white rounded-lg border border-gray-200 p-5">
          <p className="text-sm font-medium text-gray-500 mb-1">Checklist Progress</p>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold text-gray-900">{compliantCount}</span>
            <span className="text-lg text-gray-400">/{checkableItems} items</span>
          </div>
          <p className="text-xs text-gray-400 mt-1">
            {checkableItems - compliantCount} items need attention
          </p>
        </div>

        {/* Deadline countdown */}
        <div className="bg-white rounded-lg border border-gray-200 p-5">
          <p className="text-sm font-medium text-gray-500 mb-1">DPDP Deadline</p>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold text-gray-900">{daysLeft}</span>
            <span className="text-lg text-gray-400">days left</span>
          </div>
          <p className="text-xs text-gray-400 mt-1">13 May 2027</p>
        </div>
      </div>

      {/* Latest scan summary */}
      {latestScan && (
        <div className="bg-white rounded-lg border border-gray-200 p-5 mb-8">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-sm font-semibold text-gray-700">Latest Scan</h2>
            <a href="/dashboard/reports" className="text-sm text-blue-600 hover:underline">
              View all reports
            </a>
          </div>
          <div className="flex items-center gap-6 text-sm text-gray-600">
            <span>
              URL: <span className="font-medium text-gray-900">{latestScan.url}</span>
            </span>
            <span>
              Score: <span className="font-medium text-gray-900">{latestScan.score}/100</span>
            </span>
            <span>
              Grade: <span className="font-semibold text-gray-900">{latestScan.grade}</span>
            </span>
            <span className="text-gray-400">
              {new Date(latestScan.scanned_at).toLocaleDateString()}
            </span>
          </div>
        </div>
      )}

      {/* 10-point compliance checklist */}
      <ComplianceChecklist items={checklistWithStatus} />
    </div>
  );
}
