"use client";

import { useState, FormEvent, useEffect } from "react";
import Link from "next/link";
import { ReviewModal } from "@/components/ReviewModal";

interface CheckResult {
  id: string;
  name: string;
  description: string;
  severity: string;
  status: "PASS" | "FAIL" | "SKIP" | "INFO";
  details: string;
  metadata?: Record<string, unknown>;
}

interface ScanReport {
  url: string;
  scannedAt: string;
  score: number;
  grade: string;
  privacyPolicyUrl: string | null;
  checks: CheckResult[];
  summary: {
    total: number;
    passed: number;
    failed: number;
    skipped: number;
    info: number;
  };
}

function calcCountdown(targetDate: Date) {
  const diff = targetDate.getTime() - Date.now();
  if (diff <= 0) return { days: 0, hours: 0, minutes: 0, seconds: 0 };
  return {
    days: Math.floor(diff / (1000 * 60 * 60 * 24)),
    hours: Math.floor((diff / (1000 * 60 * 60)) % 24),
    minutes: Math.floor((diff / (1000 * 60)) % 60),
    seconds: Math.floor((diff / 1000) % 60),
  };
}

function useCountdown(targetDate: Date) {
  const [mounted, setMounted] = useState(false);
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });
  useEffect(() => {
    if(!mounted){
      setMounted(true);
      setTimeLeft(calcCountdown(targetDate));
    }
    const id = setInterval(() => setTimeLeft(calcCountdown(targetDate)), 1000);
    return () => clearInterval(id);
  }, [targetDate]);
  return { ...timeLeft, mounted };
}

export default function Home() {
  const [url, setUrl] = useState("");
  const [scanning, setScanning] = useState(false);
  const [report, setReport] = useState<ScanReport | null>(null);
  const [error, setError] = useState("");
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [downloadError, setDownloadError] = useState("");
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);

  const deadline = new Date("2027-05-13");
  const countdown = useCountdown(deadline);

  async function handleScan(e: FormEvent) {
    e.preventDefault();
    if (!url.trim()) return;
    setScanning(true);
    setError("");
    setReport(null);
    setShowReviewModal(false);
    setDownloadError("");
    try {
      const res = await fetch("/api/scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: url.trim() }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || "Scan failed"); return; }
      setReport(data);
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setScanning(false);
    }
  }

  async function handleReviewSuccess() {
    if (!report) return;
    setShowReviewModal(false);
    setDownloading(true);
    setDownloadError("");
    try {
      const res = await fetch("/api/report/pdf", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          scan: {
            url: report.url,
            score: report.score,
            grade: report.grade,
            checks: report.checks,
            summary: report.summary,
            scanned_at: report.scannedAt,
          },
        }),
      });
      if (!res.ok) {
        setDownloadError("Failed to generate report. Please try again.");
        return;
      }
      const blob = await res.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = downloadUrl;
      a.download = `compliance-report-${new URL(report.url).hostname}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(downloadUrl);
    } catch {
      setDownloadError("Failed to download report. Please try again.");
    } finally {
      setDownloading(false);
    }
  }

  // DPDP section and penalty mapping for each check
  const checkMeta: Record<string, { dpdpSection: string; penalty: string }> = {
    SC01: { dpdpSection: "Section 5(1)", penalty: "Up to ₹50 Cr" },
    SC02: { dpdpSection: "Section 5(1)(i)", penalty: "Up to ₹50 Cr" },
    SC03: { dpdpSection: "Section 5(1)(ii)", penalty: "Up to ₹50 Cr" },
    SC04: { dpdpSection: "Section 5(1)(iii)", penalty: "Up to ₹50 Cr" },
    SC05: { dpdpSection: "Section 5(1)(iv)", penalty: "Up to ₹50 Cr" },
    SC06: { dpdpSection: "Section 5(2)", penalty: "Up to ₹50 Cr" },
    SC07: { dpdpSection: "Section 6(1)", penalty: "Up to ₹50 Cr" },
    SC08: { dpdpSection: "Section 6(1)", penalty: "Up to ₹50 Cr" },
    SC09: { dpdpSection: "Section 6(1)", penalty: "Up to ₹50 Cr" },
    SC10: { dpdpSection: "Section 6(4)", penalty: "Up to ₹50 Cr" },
    SC11: { dpdpSection: "Section 6(6)", penalty: "Up to ₹50 Cr" },
    SC12: { dpdpSection: "Section 8(1)", penalty: "Up to ₹200 Cr" },
    SC13: { dpdpSection: "Section 8(1)", penalty: "Up to ₹200 Cr" },
    SC14: { dpdpSection: "Section 8(1)", penalty: "Up to ₹200 Cr" },
    SC15: { dpdpSection: "Section 8(1)", penalty: "Up to ₹200 Cr" },
    SC16: { dpdpSection: "Section 8(1)", penalty: "Up to ₹200 Cr" },
    SC17: { dpdpSection: "Section 8(6)", penalty: "Up to ₹200 Cr" },
    SC18: { dpdpSection: "Section 8(1)", penalty: "Up to ₹200 Cr" },
    SC19: { dpdpSection: "Section 4(2)", penalty: "Up to ₹50 Cr" },
    SC20: { dpdpSection: "Section 4(1)", penalty: "Up to ₹50 Cr" },
    SC21: { dpdpSection: "Section 8(7)", penalty: "Up to ₹50 Cr" },
    SC22: { dpdpSection: "Section 16(1)", penalty: "Up to ₹50 Cr" },
    SC23: { dpdpSection: "Section 11(1)", penalty: "Up to ₹50 Cr" },
    SC24: { dpdpSection: "Section 11(1)", penalty: "Up to ₹50 Cr" },
    SC25: { dpdpSection: "Section 12(1)", penalty: "Up to ₹50 Cr" },
    SC26: { dpdpSection: "Section 8(10)", penalty: "Up to ₹50 Cr" },
    SC27: { dpdpSection: "Section 9(1)", penalty: "Up to ₹200 Cr" },
    SC28: { dpdpSection: "Section 9(1)", penalty: "Up to ₹200 Cr" },
    SC29: { dpdpSection: "Section 8(10)", penalty: "Up to ₹50 Cr" },
    SC30: { dpdpSection: "Section 8(9)", penalty: "Up to ₹50 Cr" },
  };

  const severityOrder: Record<string, number> = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, INFO: 3 };

  function sortChecksByStatus(checks: CheckResult[]) {
    return [...checks].sort((a, b) => {
      // FAIL first, then PASS, then SKIP
      const statusOrder: Record<string, number> = { FAIL: 0, PASS: 1, SKIP: 2, INFO: 3 };
      const statusDiff = (statusOrder[a.status] ?? 3) - (statusOrder[b.status] ?? 3);
      if (statusDiff !== 0) return statusDiff;
      // Within same status, sort by severity (CRITICAL > HIGH > MEDIUM)
      return (severityOrder[a.severity] ?? 3) - (severityOrder[b.severity] ?? 3);
    });
  }

  function groupChecks(checks: CheckResult[]) {
    const groups: Record<string, CheckResult[]> = {};
    for (const check of checks) {
      const num = parseInt(check.id.replace("SC", ""), 10);
      let category: string;
      if (num <= 6) category = "Notice & Transparency";
      else if (num <= 11) category = "Consent Management";
      else if (num <= 18) category = "Security";
      else if (num <= 22) category = "Data Collection";
      else if (num <= 28) category = "User Rights & Children's Privacy";
      else category = "Other";
      if (!groups[category]) groups[category] = [];
      groups[category].push(check);
    }
    // Sort checks within each group: FAILED first by severity, then PASSED, then SKIPPED
    for (const key of Object.keys(groups)) {
      groups[key] = sortChecksByStatus(groups[key]);
    }
    return groups;
  }

  const gradeColor = (grade: string) => {
    switch (grade) {
      case "A": return "#22C55E";
      case "B": return "#84CC16";
      case "C": return "#EAB308";
      case "D": return "#F97316";
      default: return "#E94560";
    }
  };

  const penalties = [
    { amount: "250 Cr", label: "Non-compliance by Significant Data Fiduciary", section: "Sec 18(3)" },
    { amount: "200 Cr", label: "Failure to prevent data breach", section: "Sec 18(5)" },
    { amount: "200 Cr", label: "Non-compliance with children\u2019s data provisions", section: "Sec 18(4)" },
    { amount: "50 Cr", label: "Failure to fulfill other obligations", section: "Sec 18(6)" },
  ];

  const steps = [
    { num: "01", title: "Enter Your URL", desc: "Paste your website URL and our AI-powered scanner starts analyzing instantly." },
    { num: "02", title: "Get Your Score", desc: "Receive a detailed compliance score with 30+ automated checks across 6 categories." },
    { num: "03", title: "Fix & Comply", desc: "Follow prioritized recommendations to achieve full DPDP compliance before the deadline." },
  ];

  const pricing = [
    { name: "Free Scan", price: "Free", period: "", features: ["1 website scan", "Basic compliance score", "Category breakdown", "Top 5 issues"], cta: "Scan Now", highlight: false },
    { name: "Starter", price: "4,999", period: "/mo", features: ["5 scans per month", "Full PDF reports", "Priority recommendations", "Email support"], cta: "Start Free Trial", highlight: false },
    { name: "Professional", price: "14,999", period: "/mo", features: ["Unlimited scans", "Compliance dashboard", "Scheduled monitoring", "Consent widget", "Priority support"], cta: "Start Free Trial", highlight: true },
    { name: "Enterprise", price: "Custom", period: "", features: ["Everything in Pro", "DSAR portal", "Breach manager", "Dedicated CSM", "Custom integrations"], cta: "Contact Sales", highlight: false },
  ];

  return (
    <div className="min-h-screen bg-navy-900">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 border-b border-white/5 bg-navy-900/95 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-accent flex items-center justify-center">
              <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
            </div>
            <span className="text-lg font-bold text-white">GoLegal <span className="text-accent">Comply</span></span>
          </div>
          {/* Center nav links */}
          <div className="hidden md:flex items-center gap-8">
            <a href="#scanner" className="text-sm text-slate-400 hover:text-white transition-colors">Free Scanner</a>
            <a href="#how-it-works" className="text-sm text-slate-400 hover:text-white transition-colors">How It Works</a>
            <a href="#pricing" className="text-sm text-slate-400 hover:text-white transition-colors">Pricing</a>
            <Link href="/dashboard" className="text-sm text-slate-400 hover:text-white transition-colors">Dashboard</Link>
          </div>
          {/* Right side auth buttons */}
          <div className="flex items-center gap-4">
            <Link href="/login" className="text-sm text-slate-400 hover:text-white transition-colors">Sign in</Link>
            <Link href="/signup" className="text-sm bg-white/5 hover:bg-white/10 text-white border border-white/10 px-4 py-2 rounded-lg font-medium transition-all">Sign up</Link>
            <Link href="/signup" className="text-sm bg-accent hover:bg-accent-hover text-white px-4 py-2 rounded-lg font-medium transition-all">Get Started</Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="gradient-hero relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-20 left-10 w-72 h-72 bg-accent/20 rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-20 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl" />
        </div>
        <div className="relative max-w-4xl mx-auto px-6 pt-20 pb-24 text-center">
          <div className="inline-flex items-center gap-2 bg-accent/10 border border-accent/20 rounded-full px-4 py-1.5 mb-8">
            <span className="w-2 h-2 bg-accent rounded-full animate-pulse" />
            <span className="text-sm text-accent font-medium">DPDP Act Deadline: 13 May 2027</span>
          </div>
          <h1 className="text-5xl md:text-6xl font-extrabold text-white leading-tight mb-6">
            Is Your Website<br /><span className="text-gradient">DPDP Compliant?</span>
          </h1>
          <p className="text-lg text-slate-400 max-w-2xl mx-auto mb-10">
            Scan your website in seconds. Get a detailed compliance report with actionable recommendations
            to meet India&apos;s Digital Personal Data Protection Act requirements.
          </p>

          {/* Scanner Form */}
          <form id="scanner" onSubmit={handleScan} className="max-w-2xl mx-auto flex gap-3">
            <div className="flex-1">
              <input
                type="string"
                placeholder="https://yourwebsite.com"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                required
                disabled={scanning}
                className="w-full bg-navy-800 border border-white/10 text-white placeholder-slate-500 rounded-xl px-5 py-4 text-base focus:outline-none focus:ring-2 focus:ring-accent/50 focus:border-accent/50 transition-all"
              />
            </div>
            <button
              type="submit"
              disabled={scanning}
              className="bg-accent hover:bg-accent-hover text-white font-bold px-8 py-4 rounded-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed animate-glow whitespace-nowrap"
            >
              {scanning ? (
                <span className="flex items-center gap-2">
                  <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                  Scanning...
                </span>
              ) : "Scan Now \u2014 Free"}
            </button>
          </form>

          {error && (
            <div className="max-w-2xl mx-auto mt-4 bg-red-500/10 border border-red-500/20 text-red-400 px-4 py-3 rounded-xl text-sm">
              {error}
            </div>
          )}
        </div>
      </section>

      {/* Scanning Progress */}
      {scanning && (
        <section className="max-w-3xl mx-auto px-6 py-12">
          <div className="glass-card p-8 text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full border-4 border-navy-700 border-t-accent" style={{ animation: "spin 0.8s linear infinite" }} />
            <p className="text-lg font-medium text-white mb-2">Analyzing your website...</p>
            <p className="text-sm text-slate-400">Running 30+ compliance checks across 6 categories</p>
            <div className="mt-6 h-2 bg-navy-700 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-accent to-pink-400 rounded-full animate-progress" />
            </div>
          </div>
        </section>
      )}

      {/* Scan Results */}
      {report && (
        <section className="max-w-4xl mx-auto px-6 py-12 animate-fade-in">
          {/* Score Card */}
          <div className="glass-card p-8 mb-8">
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="relative w-40 h-40 flex-shrink-0">
                <svg className="w-40 h-40 -rotate-90" viewBox="0 0 160 160">
                  <circle cx="80" cy="80" r="70" fill="none" stroke="#1E293B" strokeWidth="12" />
                  <circle
                    cx="80" cy="80" r="70" fill="none"
                    stroke={gradeColor(report.grade)}
                    strokeWidth="12"
                    strokeLinecap="round"
                    strokeDasharray={`${2 * Math.PI * 70 * report.score / 100} ${2 * Math.PI * 70}`}
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-4xl font-extrabold text-white">{report.score}</span>
                  <span className="text-sm text-slate-400">/100</span>
                </div>
              </div>
              <div className="flex-1 text-center md:text-left">
                <div className="flex items-center justify-center md:justify-start gap-3 mb-2">
                  <span className="text-3xl font-extrabold" style={{ color: gradeColor(report.grade) }}>
                    Grade {report.grade}
                  </span>
                </div>
                <p className="text-slate-400 mb-4">Compliance analysis for <span className="text-white font-medium">{report.url}</span></p>
                <div className="flex flex-wrap gap-4">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-green-500" />
                    <span className="text-sm text-slate-300"><span className="font-bold text-white">{report.summary.passed}</span> Passed</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-red-500" />
                    <span className="text-sm text-slate-300"><span className="font-bold text-white">{report.summary.failed}</span> Failed</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-slate-500" />
                    <span className="text-sm text-slate-300"><span className="font-bold text-white">{report.summary.skipped}</span> Skipped</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Check Results by Category */}
          <div className="space-y-4 mb-8">
            {Object.entries(groupChecks(report.checks)).map(([category, checks]) => {
              const passed = checks.filter(c => c.status === "PASS").length;
              const failed = checks.filter(c => c.status === "FAIL").length;
              const isExpanded = expandedCategory === category;
              return (
                <div key={category} className="glass-card overflow-hidden">
                  <button
                    onClick={() => setExpandedCategory(isExpanded ? null : category)}
                    className="w-full flex items-center justify-between px-6 py-4 hover:bg-white/5 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <h3 className="text-base font-semibold text-white">{category}</h3>
                      <span className="text-xs bg-green-500/10 text-green-400 px-2 py-0.5 rounded-full font-medium">{passed} passed</span>
                      {failed > 0 && <span className="text-xs bg-red-500/10 text-red-400 px-2 py-0.5 rounded-full font-medium">{failed} failed</span>}
                    </div>
                    <svg className={`w-5 h-5 text-slate-400 transition-transform ${isExpanded ? "rotate-180" : ""}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                  {isExpanded && (
                    <div className="border-t border-white/5 px-6 py-3 space-y-1">
                      {checks.map((check) => {
                        const meta = checkMeta[check.id];
                        return (
                          <div key={check.id} className={`flex items-start gap-3 py-2.5 px-3 rounded-lg ${check.status === "FAIL" ? "bg-red-500/5" : ""}`}>
                            <div className="mt-0.5 flex-shrink-0">
                              {check.status === "PASS" ? (
                                <svg className="w-5 h-5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                                </svg>
                              ) : check.status === "FAIL" ? (
                                <svg className="w-5 h-5 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                                </svg>
                              ) : (
                                <svg className="w-5 h-5 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                  <path strokeLinecap="round" strokeLinejoin="round" d="M20 12H4" />
                                </svg>
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              {/* PASSED: check name + subtle green 'Passed' label, no severity badge */}
                              {check.status === "PASS" && (
                                <div className="flex items-center gap-2">
                                  <span className="text-sm text-white">{check.name}</span>
                                  <span className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-green-500/10 text-green-400">Passed</span>
                                </div>
                              )}
                              {/* FAILED: check name + severity badge + fail message + DPDP section + penalty */}
                              {check.status === "FAIL" && (
                                <>
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <span className="text-sm text-white font-medium">{check.name}</span>
                                    <span className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded ${
                                      check.severity === "CRITICAL" ? "bg-red-500/20 text-red-400" :
                                      check.severity === "HIGH" ? "bg-orange-500/20 text-orange-400" :
                                      check.severity === "MEDIUM" ? "bg-yellow-500/20 text-yellow-400" :
                                      "bg-blue-500/15 text-blue-400"
                                    }`}>{check.severity}</span>
                                  </div>
                                  {check.details && (
                                    <p className="text-xs text-slate-400 mt-1">{check.details}</p>
                                  )}
                                  {meta && (
                                    <div className="flex items-center gap-3 mt-1.5">
                                      <span className="text-[10px] text-slate-500 font-mono">{meta.dpdpSection}</span>
                                      <span className="text-[10px] text-red-400/80 font-medium">Penalty: {meta.penalty}</span>
                                    </div>
                                  )}
                                </>
                              )}
                              {/* SKIPPED: check name + gray 'Could not check' label */}
                              {check.status === "SKIP" && (
                                <div className="flex items-center gap-2">
                                  <span className="text-sm text-slate-400">{check.name}</span>
                                  <span className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-slate-500/10 text-slate-500">Could not check</span>
                                </div>
                              )}
                              {/* INFO status fallback */}
                              {check.status === "INFO" && (
                                <div className="flex items-center gap-2">
                                  <span className="text-sm text-white">{check.name}</span>
                                  <span className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-400">Info</span>
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Review Modal */}
          <ReviewModal
            isOpen={showReviewModal}
            onClose={() => setShowReviewModal(false)}
            onSuccess={handleReviewSuccess}
            scanId=""
          />

          {/* PDF Download */}
          <div className="glass-card p-8 border-accent/20 text-center">
            <h2 className="text-xl font-bold text-white mb-2">Get the Full Report + Action Plan</h2>
            <p className="text-sm text-slate-400 mb-6">
              Download a detailed PDF report with prioritized recommendations and a step-by-step compliance action plan.
            </p>
            {downloadError && <p className="text-sm text-red-400 mb-4">{downloadError}</p>}
            <button
              onClick={() => setShowReviewModal(true)}
              disabled={downloading}
              className="btn-accent disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {downloading ? "Generating PDF..." : "Download Full Report (PDF)"}
            </button>
          </div>
        </section>
      )}

      {/* Penalties Section */}
      {!report && !scanning && (
        <>
          <section className="max-w-7xl mx-auto px-6 py-20">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-white mb-3">DPDP Act Penalties</h2>
              <p className="text-slate-400">Non-compliance can cost your business up to <span className="text-accent font-bold">&#8377;250 Crore</span></p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {penalties.map((p, i) => (
                <div key={i} className="glass-card p-6 group hover:border-accent/30 transition-all">
                  <p className="text-3xl font-extrabold text-accent mb-2">&#8377;{p.amount}</p>
                  <p className="text-sm text-slate-300 mb-3">{p.label}</p>
                  <span className="text-xs text-slate-500 font-mono">{p.section}</span>
                </div>
              ))}
            </div>
          </section>

          {/* How It Works */}
          <section id="how-it-works" className="max-w-5xl mx-auto px-6 py-20">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-white mb-3">How It Works</h2>
              <p className="text-slate-400">Three simple steps to DPDP compliance</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {steps.map((s) => (
                <div key={s.num} className="text-center">
                  <div className="w-16 h-16 mx-auto mb-6 rounded-2xl bg-accent/10 border border-accent/20 flex items-center justify-center">
                    <span className="text-xl font-bold text-accent">{s.num}</span>
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2">{s.title}</h3>
                  <p className="text-sm text-slate-400 leading-relaxed">{s.desc}</p>
                </div>
              ))}
            </div>
          </section>

          {/* Pricing */}
          <section id="pricing" className="max-w-7xl mx-auto px-6 py-20">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-white mb-3">Pricing</h2>
              <p className="text-slate-400">Choose the plan that fits your compliance needs</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {pricing.map((plan) => (
                <div key={plan.name} className={`glass-card p-6 flex flex-col ${plan.highlight ? "border-accent/40 ring-1 ring-accent/20 relative" : ""}`}>
                  {plan.highlight && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-accent text-white text-xs font-bold px-3 py-1 rounded-full">
                      Most Popular
                    </div>
                  )}
                  <h3 className="text-lg font-bold text-white mb-1">{plan.name}</h3>
                  <div className="flex items-baseline gap-1 mb-6">
                    {plan.price !== "Free" && plan.price !== "Custom" && <span className="text-sm text-slate-400">&#8377;</span>}
                    <span className="text-3xl font-extrabold text-white">{plan.price}</span>
                    {plan.period && <span className="text-sm text-slate-400">{plan.period}</span>}
                  </div>
                  <ul className="space-y-3 mb-8 flex-1">
                    {plan.features.map((f) => (
                      <li key={f} className="flex items-center gap-2 text-sm text-slate-300">
                        <svg className="w-4 h-4 text-green-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                        </svg>
                        {f}
                      </li>
                    ))}
                  </ul>
                  <button className={`w-full py-3 rounded-lg font-semibold text-sm transition-all ${
                    plan.highlight
                      ? "bg-accent hover:bg-accent-hover text-white"
                      : "bg-white/5 hover:bg-white/10 text-white border border-white/10"
                  }`}>
                    {plan.cta}
                  </button>
                </div>
              ))}
            </div>
          </section>

          {/* Deadline Countdown */}
          <section className="max-w-4xl mx-auto px-6 py-20">
            <div className="glass-card p-12 text-center border-accent/20">
              <h2 className="text-3xl font-bold text-white mb-2">Compliance Deadline</h2>
              <p className="text-slate-400 mb-8">Time remaining until DPDP Act enforcement on 13 May 2027</p>
              <div className="flex justify-center gap-6 md:gap-10 mb-8">
                {[
                  { val: countdown.days, label: "Days" },
                  { val: countdown.hours, label: "Hours" },
                  { val: countdown.minutes, label: "Minutes" },
                  { val: countdown.seconds, label: "Seconds" },
                ].map((unit) => (
                  <div key={unit.label} className="text-center">
                    <div className="bg-navy-700/50 border border-white/10 rounded-xl px-5 py-4 min-w-[80px]">
                      <span className="text-4xl font-extrabold text-white" style={{ fontVariantNumeric: "tabular-nums" }}>{countdown.mounted ? String(unit.val).padStart(2, "0") : "--"}</span>
                    </div>
                    <p className="text-xs text-slate-500 mt-2 uppercase tracking-wider font-medium">{unit.label}</p>
                  </div>
                ))}
              </div>
              <Link href="/signup" className="inline-block btn-accent px-10">
                Get Compliant Now
              </Link>
            </div>
          </section>

          {/* Footer */}
          <footer className="border-t border-white/5 mt-10">
            <div className="max-w-7xl mx-auto px-6 py-12">
              <div className="flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-accent flex items-center justify-center">
                    <svg className="w-3.5 h-3.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                  </div>
                  <span className="text-sm font-bold text-white">GoLegal <span className="text-accent">Comply</span></span>
                </div>
                <div className="flex items-center gap-8">
                  <Link href="/login" className="text-sm text-slate-500 hover:text-white transition-colors">Sign in</Link>
                  <Link href="/signup" className="text-sm text-slate-500 hover:text-white transition-colors">Sign up</Link>
                  <Link href="/dashboard" className="text-sm text-slate-500 hover:text-white transition-colors">Dashboard</Link>
                </div>
                <p className="text-xs text-slate-600">GoLegal Comply. DPDP Compliance Platform.</p>
              </div>
            </div>
          </footer>
        </>
      )}
    </div>
  );
}
