import { NextRequest, NextResponse } from "next/server";
import { scanWebsite } from "@/lib/scanner/engine";

export const maxDuration = 120; // Extended for deep scans (up to 60s fast + 30s puppeteer)

type ScanReport = Awaited<ReturnType<typeof scanWebsite>>;

async function saveScanToSupabase(request: NextRequest, report: ScanReport): Promise<void> {
  if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) return;
  try {
    const { createClient } = await import("@supabase/supabase-js");
    const supabase = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL,
      process.env.SUPABASE_SERVICE_ROLE_KEY
    );
    let userId: string | null = null;
    const authHeader = request.headers.get("authorization");
    if (authHeader) {
      const token = authHeader.replace("Bearer ", "").trim();
      if (token) {
        const { data: { user } } = await supabase.auth.getUser(token);
        if (user) userId = user.id;
      }
    }
    const { data: existing } = await supabase
      .from("scans")
      .select("id, counter")
      .eq("url", report.url)
      .is("user_id", userId)
      .order("scanned_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    const row = {
      url: report.url,
      score: report.score,
      grade: report.grade,
      privacy_policy_url: report.privacyPolicyUrl,
      checks: report.checks,
      summary: report.summary,
      scanned_at: report.scannedAt,
    };

    if (existing?.id) {
      await supabase
        .from("scans")
        .update({
          ...row,
          counter: (existing.counter ?? 0) + 1,
        })
        .eq("id", existing.id);
    } else {
      const { error: insertError } = await supabase.from("scans").insert({
        ...row,
        user_id: userId,
        counter: 1,
      });
      if (insertError) {
        console.error("Failed to save scan to Supabase:", insertError.message);
      }
    }
  } catch (err) {
    console.error("Failed to save scan to Supabase", err);
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { url } = body;

    if (!url || typeof url !== "string") {
      return NextResponse.json(
        { error: "Missing required field: url" },
        { status: 400 }
      );
    }

    const urlToParse = /^https?:\/\//i.test(url.trim()) ? url.trim() : `https://${url.trim()}`;

    let parsedUrl: URL;
    try {
      parsedUrl = new URL(urlToParse);
    } catch {
      return NextResponse.json(
        { error: "Invalid URL format. Please provide a valid HTTP or HTTPS URL." },
        { status: 400 }
      );
    }

    const protocol = parsedUrl.protocol.toLowerCase();
    if (protocol !== "http:" && protocol !== "https:") {
      return NextResponse.json(
        { error: "Invalid URL format. Please provide a valid HTTP or HTTPS URL." },
        { status: 400 }
      );
    }

    const report = await scanWebsite(parsedUrl.href);
    await saveScanToSupabase(request, report);
    return NextResponse.json(report);
  } catch (error) {
    // Handle fetch abort / timeout errors with a user-friendly message
    if (
      error instanceof DOMException && error.name === "AbortError" ||
      (error instanceof Error && error.message.includes("aborted"))
    ) {
      return NextResponse.json(
        { error: "The website took too long to respond. Please try again or check that the URL is accessible." },
        { status: 504 }
      );
    }

    const message =
      error instanceof Error ? error.message : "An unexpected error occurred";

    return NextResponse.json(
      { error: message },
      { status: 500 }
    );
  }
}
