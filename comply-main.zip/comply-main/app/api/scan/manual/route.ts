import { NextRequest, NextResponse } from "next/server";
import { scanFromHtml } from "@/lib/scanner/engine";

export const maxDuration = 60;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { url, html } = body;

    if (!url || typeof url !== "string") {
      return NextResponse.json(
        { error: "Missing required field: url" },
        { status: 400 }
      );
    }

    if (!html || typeof html !== "string") {
      return NextResponse.json(
        { error: "Missing required field: html (paste your page source code)" },
        { status: 400 }
      );
    }

    if (html.length < 100) {
      return NextResponse.json(
        { error: "Pasted HTML is too short. Please paste the full page source." },
        { status: 400 }
      );
    }

    // Validate URL format
    let parsedUrl: URL;
    try {
      parsedUrl = new URL(url);
      if (!["http:", "https:"].includes(parsedUrl.protocol)) {
        throw new Error("Invalid protocol");
      }
    } catch {
      return NextResponse.json(
        { error: "Invalid URL format." },
        { status: 400 }
      );
    }

    const report = await scanFromHtml(parsedUrl.href, html);

    return NextResponse.json(report);
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "An unexpected error occurred";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
