import { NextRequest, NextResponse } from "next/server";
import { getSupabaseAdmin } from "@/lib/supabase";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, company_name, url_scanned, score } = body;

    if (!email || typeof email !== "string") {
      return NextResponse.json(
        { error: "Email is required" },
        { status: 400 }
      );
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: "Invalid email format" },
        { status: 400 }
      );
    }

    if (!url_scanned || typeof url_scanned !== "string") {
      return NextResponse.json(
        { error: "Scanned URL is required" },
        { status: 400 }
      );
    }

    const supabase = getSupabaseAdmin();

    if (!supabase) {
      // If Supabase is not configured, return success with a generated ID
      // so the flow still works in development
      return NextResponse.json({
        id: crypto.randomUUID(),
        email,
        company_name: company_name || null,
        url_scanned,
        score: score ?? null,
        created_at: new Date().toISOString(),
      });
    }

    const { data, error } = await supabase
      .from("scanner_leads")
      .insert({
        email,
        company_name: company_name || null,
        url_scanned,
        score: score ?? null,
      })
      .select()
      .single();

    if (error) {
      console.error("Failed to save lead:", error);
      return NextResponse.json(
        { error: "Failed to save lead" },
        { status: 500 }
      );
    }

    return NextResponse.json(data);
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "An unexpected error occurred";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
