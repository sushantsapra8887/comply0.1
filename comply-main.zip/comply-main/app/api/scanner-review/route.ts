import { NextRequest, NextResponse } from "next/server";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, companyName, rating, review, scanId } = body;

    if (!email || typeof email !== "string") {
      return NextResponse.json(
        { error: "Missing required field: email" },
        { status: 400 }
      );
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: "Invalid email format" },
        { status: 400 }
      );
    }

    if (!companyName || typeof companyName !== "string") {
      return NextResponse.json(
        { error: "Missing required field: company name" },
        { status: 400 }
      );
    }

    if (!rating || typeof rating !== "number" || rating < 1 || rating > 5) {
      return NextResponse.json(
        { error: "Rating must be a number between 1 and 5" },
        { status: 400 }
      );
    }

    if (
      process.env.NEXT_PUBLIC_SUPABASE_URL &&
      process.env.SUPABASE_SERVICE_ROLE_KEY
    ) {
      const { createClient } = await import("@supabase/supabase-js");
      const supabase = createClient(
        process.env.NEXT_PUBLIC_SUPABASE_URL,
        process.env.SUPABASE_SERVICE_ROLE_KEY
      );

      // Check for duplicate submission (same email + scan)
      if (scanId) {
        const { data: existing } = await supabase
          .from("scanner_reviews")
          .select("id")
          .eq("email", email)
          .eq("scan_id", scanId)
          .maybeSingle();

        if (existing) {
          return NextResponse.json(
            { error: "You have already submitted a review for this scan" },
            { status: 409 }
          );
        }
      }

      const { error: insertError } = await supabase
        .from("scanner_reviews")
        .insert({
          email,
          company_name: companyName,
          rating: Math.round(rating),
          review: review || null,
          scan_id: scanId || null,
        });

      if (insertError) {
        console.error("Failed to save scanner review:", insertError);
        return NextResponse.json(
          { error: "Failed to save review" },
          { status: 500 }
        );
      }

      // Also save to email_captures to maintain existing lead capture behaviour
      try {
        const authHeader = request.headers.get("authorization");
        let userId: string | null = null;

        if (authHeader) {
          const token = authHeader.replace("Bearer ", "");
          const {
            data: { user },
          } = await supabase.auth.getUser(token);
          userId = user?.id ?? null;
        }

        await supabase.from("email_captures").insert({
          email,
          scan_id: scanId || null,
          user_id: userId,
        });
      } catch {
        // Don't block the response if email_captures save fails
      }
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "An unexpected error occurred";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
