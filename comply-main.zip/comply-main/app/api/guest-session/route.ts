import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

/**
 * POST /api/guest-session
 * Creates an anonymous Supabase session and returns a JWT (access_token).
 * Client should send this token as Authorization: Bearer <access_token> when calling /api/scan
 * so that scans are associated with this guest session (user_id in scans table).
 */
export async function POST() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!url || !anonKey) {
    return NextResponse.json(
      { error: "Supabase is not configured" },
      { status: 503 }
    );
  }

  try {
    const supabase = createClient(url, anonKey);
    const { data, error } = await supabase.auth.signInAnonymously();

    if (error) {
      console.error("Guest session error:", error.message);
      return NextResponse.json(
        { error: error.message || "Failed to create guest session" },
        { status: 500 }
      );
    }

    const session = data.session;
    if (!session) {
      return NextResponse.json(
        { error: "No session returned" },
        { status: 500 }
      );
    }

    return NextResponse.json({
      access_token: session.access_token,
      refresh_token: session.refresh_token,
      expires_at: session.expires_at ?? null,
      expires_in: session.expires_in ?? null,
      user: {
        id: session.user?.id,
        is_anonymous: session.user?.is_anonymous,
      },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    console.error("Guest session error:", message);
    return NextResponse.json(
      { error: "Failed to create guest session" },
      { status: 500 }
    );
  }
}
