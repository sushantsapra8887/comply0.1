import { NextRequest, NextResponse } from "next/server";
import { scanWebsite } from "@/lib/scanner/engine";
import { generateReportPdf } from "@/lib/pdf";
import { getSupabaseAdmin } from "@/lib/supabase";

export const maxDuration = 60;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { url, lead_id } = body;

    if (!url || typeof url !== "string") {
      return NextResponse.json(
        { error: "Missing required field: url" },
        { status: 400 }
      );
    }

    if (!lead_id || typeof lead_id !== "string") {
      return NextResponse.json(
        { error: "Email submission is required to download the report. Please provide your email first." },
        { status: 403 }
      );
    }

    // Optionally verify the lead exists in Supabase
    const supabase = getSupabaseAdmin();
    if (supabase) {
      const { data: lead } = await supabase
        .from("scanner_leads")
        .select("id")
        .eq("id", lead_id)
        .single();

      if (!lead) {
        return NextResponse.json(
          { error: "Invalid lead reference. Please submit your email first." },
          { status: 403 }
        );
      }
    }

    // Run the scan (or accept cached report data)
    const report = await scanWebsite(url);

    // Generate PDF
    const pdfBuffer = generateReportPdf(report);

    return new NextResponse(new Uint8Array(pdfBuffer), {
      status: 200,
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="compliance-report-${new URL(url).hostname}.pdf"`,
        "Content-Length": String(pdfBuffer.length),
      },
    });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "An unexpected error occurred";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
