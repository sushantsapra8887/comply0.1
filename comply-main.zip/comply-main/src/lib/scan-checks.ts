export type CheckStatus = "pass" | "fail" | "warn" | "skip" | "pending" | "running";

export type Severity = "critical" | "high" | "medium" | "low";

export interface ScanCheck {
  id: string;
  name: string;
  category: string;
  severity: Severity;
  dpdpSection: string;
  failMessage: string;
  passMessage: string;
}

export interface ScanCheckResult extends ScanCheck {
  status: CheckStatus;
}

export interface CategoryGroup {
  name: string;
  checks: ScanCheck[];
}

export const SCAN_CHECKS: ScanCheck[] = [
  // Privacy Notice (SC01-SC06)
  { id: "SC01", name: "Privacy Policy Exists", category: "Privacy Notice", severity: "critical", dpdpSection: "Section 5(1)", failMessage: "No privacy policy found on the website", passMessage: "Privacy policy page detected" },
  { id: "SC02", name: "Purpose of Data Collection Stated", category: "Privacy Notice", severity: "critical", dpdpSection: "Section 5(1)(i)", failMessage: "Privacy policy does not clearly state purposes of data collection", passMessage: "Data collection purposes are clearly stated" },
  { id: "SC03", name: "Data Fiduciary Identity Disclosed", category: "Privacy Notice", severity: "high", dpdpSection: "Section 5(1)(ii)", failMessage: "Data fiduciary identity not disclosed in privacy notice", passMessage: "Data fiduciary identity is disclosed" },
  { id: "SC04", name: "Data Principal Rights Listed", category: "Privacy Notice", severity: "high", dpdpSection: "Section 5(1)(iii)", failMessage: "Rights of data principals not mentioned in privacy notice", passMessage: "Data principal rights are listed" },
  { id: "SC05", name: "Grievance Mechanism Mentioned", category: "Privacy Notice", severity: "high", dpdpSection: "Section 5(1)(iv)", failMessage: "No grievance redressal mechanism mentioned", passMessage: "Grievance mechanism is mentioned in notice" },
  { id: "SC06", name: "Notice in English & Hindi", category: "Privacy Notice", severity: "medium", dpdpSection: "Section 5(2)", failMessage: "Privacy notice not available in multiple languages", passMessage: "Privacy notice available in multiple languages" },

  // Consent Mechanism (SC07-SC11)
  { id: "SC07", name: "Consent Banner Present", category: "Consent Mechanism", severity: "critical", dpdpSection: "Section 6(1)", failMessage: "No cookie consent banner or consent mechanism detected", passMessage: "Consent banner is present" },
  { id: "SC08", name: "Consent is Freely Given", category: "Consent Mechanism", severity: "critical", dpdpSection: "Section 6(1)", failMessage: "Consent appears pre-checked or forced (dark patterns detected)", passMessage: "Consent appears to be freely given" },
  { id: "SC09", name: "Consent is Specific & Informed", category: "Consent Mechanism", severity: "high", dpdpSection: "Section 6(1)", failMessage: "Consent is bundled — not specific to each purpose", passMessage: "Consent is specific and informed for each purpose" },
  { id: "SC10", name: "Withdraw Consent Option", category: "Consent Mechanism", severity: "high", dpdpSection: "Section 6(4)", failMessage: "No option to withdraw consent found", passMessage: "Withdraw consent option is available" },
  { id: "SC11", name: "Consent Record Keeping", category: "Consent Mechanism", severity: "medium", dpdpSection: "Section 6(6)", failMessage: "No evidence of consent record-keeping mechanism", passMessage: "Consent record-keeping mechanism detected" },

  // Security Safeguards (SC12-SC18)
  { id: "SC12", name: "HTTPS Enabled", category: "Security Safeguards", severity: "critical", dpdpSection: "Section 8(1)", failMessage: "Website does not use HTTPS encryption", passMessage: "HTTPS encryption is enabled" },
  { id: "SC13", name: "Valid SSL Certificate", category: "Security Safeguards", severity: "critical", dpdpSection: "Section 8(1)", failMessage: "SSL certificate is invalid or expired", passMessage: "SSL certificate is valid" },
  { id: "SC14", name: "Secure Form Submissions", category: "Security Safeguards", severity: "high", dpdpSection: "Section 8(1)", failMessage: "Forms submit data over insecure connection", passMessage: "All forms submit data securely" },
  { id: "SC15", name: "No Mixed Content", category: "Security Safeguards", severity: "medium", dpdpSection: "Section 8(1)", failMessage: "Page loads insecure resources over HTTP (mixed content)", passMessage: "No mixed content detected" },
  { id: "SC16", name: "Security Headers Present", category: "Security Safeguards", severity: "medium", dpdpSection: "Section 8(1)", failMessage: "Important security headers missing (CSP, HSTS, X-Frame-Options)", passMessage: "Security headers are properly configured" },
  { id: "SC17", name: "Data Breach Notification Policy", category: "Security Safeguards", severity: "high", dpdpSection: "Section 8(6)", failMessage: "No data breach notification policy found", passMessage: "Data breach notification policy is documented" },
  { id: "SC18", name: "Third-Party Script Audit", category: "Security Safeguards", severity: "medium", dpdpSection: "Section 8(1)", failMessage: "Unaudited third-party scripts detected that may access personal data", passMessage: "Third-party scripts appear properly managed" },

  // Data Collection (SC19-SC22)
  { id: "SC19", name: "Data Minimisation", category: "Data Collection", severity: "high", dpdpSection: "Section 4(2)", failMessage: "Forms collect more data than necessary for stated purpose", passMessage: "Data collection appears proportionate to purpose" },
  { id: "SC20", name: "Purpose Limitation Enforced", category: "Data Collection", severity: "high", dpdpSection: "Section 4(1)", failMessage: "Data appears to be used beyond stated purposes", passMessage: "Data use appears limited to stated purposes" },
  { id: "SC21", name: "Storage Limitation Stated", category: "Data Collection", severity: "medium", dpdpSection: "Section 8(7)", failMessage: "No data retention/deletion policy found", passMessage: "Data retention and deletion policy is stated" },
  { id: "SC22", name: "Cross-Border Transfer Notice", category: "Data Collection", severity: "high", dpdpSection: "Section 16(1)", failMessage: "No disclosure about cross-border data transfers", passMessage: "Cross-border data transfer information is disclosed" },

  // Rights & Grievance (SC23-SC26, SC29-SC30)
  { id: "SC23", name: "Right to Access Data", category: "Rights & Grievance", severity: "high", dpdpSection: "Section 11(1)", failMessage: "No mechanism for data principals to access their data", passMessage: "Data access mechanism is available" },
  { id: "SC24", name: "Right to Correction", category: "Rights & Grievance", severity: "high", dpdpSection: "Section 11(1)", failMessage: "No mechanism to correct personal data", passMessage: "Data correction mechanism is available" },
  { id: "SC25", name: "Right to Erasure", category: "Rights & Grievance", severity: "high", dpdpSection: "Section 12(1)", failMessage: "No mechanism to request data erasure/deletion", passMessage: "Data erasure mechanism is available" },
  { id: "SC26", name: "Grievance Officer Contact", category: "Rights & Grievance", severity: "critical", dpdpSection: "Section 8(10)", failMessage: "No grievance officer contact information found", passMessage: "Grievance officer contact is published" },
  { id: "SC29", name: "Response Timeline Stated", category: "Rights & Grievance", severity: "medium", dpdpSection: "Section 8(10)", failMessage: "No timeline for grievance response is mentioned", passMessage: "Grievance response timeline is stated" },
  { id: "SC30", name: "DPO / Nodal Officer Listed", category: "Rights & Grievance", severity: "high", dpdpSection: "Section 8(9)", failMessage: "No Data Protection Officer or nodal officer listed", passMessage: "Data Protection Officer / nodal officer is listed" },

  // Children's Data (SC27-SC28)
  { id: "SC27", name: "Age Verification Mechanism", category: "Children's Data", severity: "critical", dpdpSection: "Section 9(1)", failMessage: "No age verification mechanism detected for minors", passMessage: "Age verification mechanism is in place" },
  { id: "SC28", name: "Parental Consent Mechanism", category: "Children's Data", severity: "critical", dpdpSection: "Section 9(1)", failMessage: "No verifiable parental consent mechanism for children's data", passMessage: "Parental consent mechanism is available" },
];

export const CATEGORIES = [
  { name: "Privacy Notice", checkIds: ["SC01","SC02","SC03","SC04","SC05","SC06"] },
  { name: "Consent Mechanism", checkIds: ["SC07","SC08","SC09","SC10","SC11"] },
  { name: "Security Safeguards", checkIds: ["SC12","SC13","SC14","SC15","SC16","SC17","SC18"] },
  { name: "Data Collection", checkIds: ["SC19","SC20","SC21","SC22"] },
  { name: "Rights & Grievance", checkIds: ["SC23","SC24","SC25","SC26","SC29","SC30"] },
  { name: "Children's Data", checkIds: ["SC27","SC28"] },
];

export function getGrade(score: number): { letter: string; color: string } {
  if (score >= 90) return { letter: "A", color: "#22C55E" };
  if (score >= 80) return { letter: "B", color: "#22C55E" };
  if (score >= 60) return { letter: "C", color: "#EAB308" };
  if (score >= 40) return { letter: "D", color: "#E94560" };
  return { letter: "F", color: "#E94560" };
}

export function calculatePenalty(failCount: number): string {
  // DPDP Act penalties can range up to ₹250 crore
  // Rough estimate based on number of violations
  if (failCount >= 15) return "250";
  if (failCount >= 10) return "150";
  if (failCount >= 6) return "50";
  if (failCount >= 3) return "10";
  return "5";
}

/** Simulate a scan — in production this would call a backend API */
export function simulateScanResult(checkId: string): CheckStatus {
  // Deterministic-ish mock based on check id for demo consistency
  const num = parseInt(checkId.replace("SC", ""), 10);
  // Roughly 50% pass, 35% fail, 15% warn for demo
  const hash = (num * 7 + 3) % 10;
  if (hash < 5) return "pass";
  if (hash < 8) return "fail";
  return "warn";
}
