"use client";

import { ScanCheckResult, CATEGORIES, SCAN_CHECKS } from "@/lib/scan-checks";

interface ScanProgressProps {
  results: ScanCheckResult[];
  currentCheckIndex: number;
}

const STATUS_ICON: Record<string, string> = {
  pass: "✓",
  fail: "✗",
  warn: "!",
  running: "…",
  pending: "○",
};

const STATUS_COLOR: Record<string, string> = {
  pass: "text-pass",
  fail: "text-fail",
  warn: "text-warn",
  running: "text-blue-400",
  pending: "text-gray-500",
};

export default function ScanProgress({
  results,
  currentCheckIndex,
}: ScanProgressProps) {
  const total = SCAN_CHECKS.length;
  const completed = results.filter(
    (r) => r.status === "pass" || r.status === "fail" || r.status === "warn"
  ).length;
  const percent = Math.round((completed / total) * 100);

  // Current category being scanned
  const currentCheck = SCAN_CHECKS[currentCheckIndex];
  const currentCategoryName = currentCheck?.category ?? "Finishing up...";

  return (
    <div className="mx-auto w-full max-w-2xl">
      {/* Header */}
      <div className="mb-6 text-center">
        <h2 className="text-2xl font-bold">Scanning your website...</h2>
        <p className="mt-1 text-gray-400">
          Checking {currentCategoryName}
        </p>
      </div>

      {/* Progress bar */}
      <div className="mb-8">
        <div className="mb-2 flex justify-between text-sm text-gray-400">
          <span>
            {completed} of {total} checks
          </span>
          <span>{percent}%</span>
        </div>
        <div className="h-3 w-full overflow-hidden rounded-full bg-navy-lighter">
          <div
            className="progress-bar-animated h-full rounded-full bg-accent transition-all duration-300"
            style={{ width: `${percent}%` }}
          />
        </div>
      </div>

      {/* Category-grouped checks */}
      <div className="space-y-4">
        {CATEGORIES.map((cat) => {
          const catResults = results.filter((r) =>
            cat.checkIds.includes(r.id)
          );
          if (catResults.length === 0) return null;

          return (
            <div key={cat.name}>
              <h3 className="mb-2 text-sm font-semibold uppercase tracking-wider text-gray-400">
                {cat.name}
              </h3>
              <div className="space-y-1">
                {catResults.map((r) => (
                  <div
                    key={r.id}
                    className={`check-item-enter flex items-center gap-3 rounded-lg px-3 py-2 ${
                      r.status === "running"
                        ? "bg-navy-lighter"
                        : "bg-transparent"
                    }`}
                  >
                    <span
                      className={`w-5 text-center font-bold ${STATUS_COLOR[r.status]}`}
                    >
                      {STATUS_ICON[r.status]}
                    </span>
                    <span className="text-sm text-gray-300">
                      {r.id}
                    </span>
                    <span
                      className={`text-sm ${
                        r.status === "running"
                          ? "text-white"
                          : "text-gray-400"
                      }`}
                    >
                      {r.name}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
