"use client";

import { useState } from "react";
import {
  ScanCheckResult,
  CATEGORIES,
  getGrade,
  calculatePenalty,
  Severity,
} from "@/lib/scan-checks";
import CountdownTimer from "./CountdownTimer";
import { ReviewModal } from "@/components/ReviewModal";

interface ScanReportProps {
  results: ScanCheckResult[];
  url: string;
}

const SEVERITY_BADGE: Record<Severity, { bg: string; text: string }> = {
  critical: { bg: "bg-red-900/50", text: "text-red-300" },
  high: { bg: "bg-orange-900/50", text: "text-orange-300" },
  medium: { bg: "bg-yellow-900/50", text: "text-yellow-300" },
  low: { bg: "bg-blue-900/50", text: "text-blue-300" },
};

const STATUS_ICON: Record<string, { icon: string; color: string }> = {
  pass: { icon: "✓", color: "text-pass" },
  fail: { icon: "✗", color: "text-fail" },
  warn: { icon: "!", color: "text-warn" },
  skip: { icon: "—", color: "text-gray-400" },
};

export default function ScanReport({ results, url }: ScanReportProps) {
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(
    new Set(CATEGORIES.map((c) => c.name))
  );
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const passCount = results.filter((r) => r.status === "pass").length;
  const failCount = results.filter((r) => r.status === "fail").length;
  const skipCount = results.filter((r) => r.status === "skip").length;
  const total = results.length;
  const runnableCount = passCount + failCount;
  const score = runnableCount > 0 ? Math.round((passCount / runnableCount) * 100) : 0;
  const grade = getGrade(score);
  const penalty = calculatePenalty(failCount);

  const toggleCategory = (name: string) => {
    setExpandedCategories((prev) => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name);
      else next.add(name);
      return next;
    });
  };

  const handleShare = async () => {
    const text = `My website ${url} scored ${score}% on DPDP compliance (Grade ${grade.letter}). Check yours free at GoLegal Comply!`;
    if (navigator.share) {
      await navigator.share({ title: "DPDP Compliance Score", text });
    } else {
      await navigator.clipboard.writeText(text);
      alert("Results copied to clipboard!");
    }
  };

  async function handleReviewSuccess() {
    setShowReviewModal(false);
    setDownloading(true);
    try {
      const res = await fetch("/api/report/pdf", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          scan: {
            url,
            score,
            grade: grade.letter,
            checks: results.map((r) => ({
              id: r.id,
              name: r.name,
              status: r.status.toUpperCase(),
              details: r.failMessage || "",
              severity: r.severity?.toUpperCase() || "INFO",
              description: r.name,
            })),
            summary: {
              total,
              passed: passCount,
              failed: failCount,
              skipped: skipCount,
              info: 0,
            },
            scanned_at: new Date().toISOString(),
          },
        }),
      });
      if (!res.ok) return;
      const blob = await res.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = downloadUrl;
      a.download = `compliance-report-${url.replace(/https?:\/\//, "").replace(/[^a-zA-Z0-9.-]/g, "_")}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(downloadUrl);
    } finally {
      setDownloading(false);
    }
  }

  return (
    <div className="mx-auto w-full max-w-3xl">
      {/* Score Section */}
      <div className="score-circle mb-8 text-center">
        {/* Score Circle */}
        <div className="mx-auto mb-4 flex h-44 w-44 items-center justify-center rounded-full border-4" style={{ borderColor: grade.color }}>
          <div>
            <div className="text-5xl font-bold" style={{ color: grade.color }}>
              {grade.letter}
            </div>
            <div className="text-2xl font-semibold text-white">{score}%</div>
          </div>
        </div>
        <h2 className="text-2xl font-bold">
          Your website is{" "}
          <span style={{ color: grade.color }}>{score}% DPDP compliant</span>
        </h2>
        <p className="mt-1 text-gray-400">{url}</p>
        {skipCount > 0 && (
          <p className="mt-2 text-sm text-amber-400">
            {runnableCount}/{total} checks completed ({skipCount} skipped due to site restrictions)
          </p>
        )}
      </div>

      {/* Penalty Banner */}
      {failCount > 0 && (
        <div className="mb-8 rounded-xl border border-red-800 bg-red-950/50 px-6 py-4 text-center">
          <p className="text-sm text-red-300">Potential penalty exposure</p>
          <p className="text-3xl font-bold text-fail">
            Up to ₹{penalty} Crore
          </p>
          <p className="mt-1 text-xs text-red-400">
            Under DPDP Act 2023 — based on {failCount} failing check
            {failCount > 1 ? "s" : ""}
          </p>
        </div>
      )}

      {/* Category Results */}
      <div className="mb-8 space-y-3">
        {CATEGORIES.map((cat) => {
          const catResults = results.filter((r) =>
            cat.checkIds.includes(r.id)
          );
          const catPass = catResults.filter(
            (r) => r.status === "pass"
          ).length;
          const catTotal = catResults.length;
          const isExpanded = expandedCategories.has(cat.name);
          const allPass = catPass === catTotal;

          return (
            <div
              key={cat.name}
              className="overflow-hidden rounded-xl border border-gray-800 bg-surface"
            >
              {/* Category Header */}
              <button
                onClick={() => toggleCategory(cat.name)}
                className="flex w-full items-center justify-between px-5 py-4 text-left transition hover:bg-surface-light"
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`text-lg ${
                      allPass ? "text-pass" : "text-fail"
                    }`}
                  >
                    {allPass ? "✓" : "✗"}
                  </span>
                  <span className="font-semibold">{cat.name}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span
                    className={`text-sm font-medium ${
                      allPass ? "text-pass" : "text-gray-400"
                    }`}
                  >
                    {catPass}/{catTotal} passed
                  </span>
                  <span className="text-gray-500">
                    {isExpanded ? "▲" : "▼"}
                  </span>
                </div>
              </button>

              {/* Check Items */}
              {isExpanded && (
                <div className="border-t border-gray-800">
                  {catResults.map((r) => {
                    const statusInfo = STATUS_ICON[r.status] ?? STATUS_ICON.fail;
                    const badge = SEVERITY_BADGE[r.severity];
                    return (
                      <div
                        key={r.id}
                        className="flex flex-col gap-1 border-b border-gray-800/50 px-5 py-3 last:border-b-0 sm:flex-row sm:items-center sm:gap-3"
                      >
                        <div className="flex items-center gap-3">
                          <span className={`w-5 text-center font-bold ${statusInfo.color}`}>
                            {statusInfo.icon}
                          </span>
                          <span className="text-sm font-medium">
                            {r.name}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 pl-8 sm:ml-auto sm:pl-0">
                          <span
                            className={`rounded px-2 py-0.5 text-xs font-medium ${badge.bg} ${badge.text}`}
                          >
                            {r.severity}
                          </span>
                          <span className="text-xs text-gray-500">
                            {r.dpdpSection}
                          </span>
                        </div>
                        {r.status !== "pass" && (
                          <p className="pl-8 text-xs text-gray-400 sm:w-full sm:pl-8">
                            {r.failMessage}
                          </p>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Review Modal */}
      <ReviewModal
        isOpen={showReviewModal}
        onClose={() => setShowReviewModal(false)}
        onSuccess={handleReviewSuccess}
        scanId=""
      />

      {/* CTAs */}
      <div className="mb-12 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
        <button
          onClick={() => setShowReviewModal(true)}
          disabled={downloading}
          className="w-full rounded-lg border border-gray-600 px-6 py-3 font-semibold text-white transition hover:bg-navy-lighter disabled:opacity-50 disabled:cursor-not-allowed sm:w-auto"
        >
          {downloading ? "Generating PDF..." : "Download Full Report (PDF)"}
        </button>
        <a
          href="/pricing"
          className="w-full rounded-lg bg-accent px-6 py-3 text-center font-semibold text-white transition hover:bg-accent-hover sm:w-auto"
        >
          Fix These Issues — Get GoLegal Comply
        </a>
        <button
          onClick={handleShare}
          className="w-full rounded-lg border border-gray-600 px-6 py-3 font-semibold text-white transition hover:bg-navy-lighter sm:w-auto"
        >
          Share Results
        </button>
      </div>

      {/* What These Results Mean */}
      <div className="mb-10 rounded-xl border border-gray-800 bg-surface p-6">
        <h3 className="mb-4 text-xl font-bold">What These Results Mean</h3>
        <div className="space-y-3 text-sm text-gray-300">
          <p>
            The Digital Personal Data Protection (DPDP) Act 2023 is India&apos;s
            comprehensive data protection law. Non-compliance can result in
            penalties of <strong className="text-fail">up to ₹250 Crore</strong>{" "}
            per violation.
          </p>
          <p>
            Your scan identified{" "}
            <strong className="text-white">{failCount} failures</strong> and{" "}
            <strong className="text-warn">
              {results.filter((r) => r.status === "warn").length} warnings
            </strong>{" "}
            across {total} compliance checks. Each failure represents a
            potential violation that could trigger regulatory action.
          </p>
          <p>
            <strong className="text-white">Critical</strong> and{" "}
            <strong className="text-white">High</strong> severity issues should
            be addressed immediately. The Data Protection Board of India (DPBI)
            has the authority to investigate complaints and impose penalties.
          </p>
        </div>
      </div>

      {/* Countdown Timer */}
      <div className="mb-10 rounded-xl border border-yellow-800/50 bg-yellow-950/30 p-6 text-center">
        <h3 className="mb-2 text-lg font-bold text-warn">
          Compliance Deadline
        </h3>
        <p className="mb-4 text-3xl font-bold text-white">13 May 2027</p>
        <CountdownTimer targetDate="2027-05-13T00:00:00+05:30" />
      </div>

      {/* Final CTA */}
      <div className="mb-16 rounded-xl bg-gradient-to-r from-accent/20 to-purple-900/20 p-8 text-center">
        <h3 className="mb-2 text-2xl font-bold">
          Get Started with GoLegal Comply
        </h3>
        <p className="mb-6 text-gray-300">
          Automated compliance monitoring, remediation guidance, and
          certification-ready reports.
        </p>
        <a
          href="/pricing"
          className="inline-block rounded-lg bg-accent px-8 py-4 text-lg font-semibold text-white transition hover:bg-accent-hover"
        >
          View Pricing Plans
        </a>
      </div>
    </div>
  );
}
