import Link from "next/link";

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center px-4 text-center">
      <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">
        GoLegal <span className="text-accent">Comply</span>
      </h1>
      <p className="mt-4 max-w-xl text-lg text-gray-300">
        Is your website compliant with India&apos;s Digital Personal Data
        Protection Act (DPDP) 2023? Find out in 60 seconds — free.
      </p>
      <Link
        href="/scanner"
        className="mt-8 rounded-lg bg-accent px-8 py-4 text-lg font-semibold text-white transition hover:bg-accent-hover"
      >
        Scan Your Website — Free
      </Link>
    </main>
  );
}
