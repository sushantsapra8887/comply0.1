"use client";

import { useState, useCallback, useRef } from "react";
import ScanProgress from "@/components/ScanProgress";
import ScanReport from "@/components/ScanReport";
import {
  SCAN_CHECKS,
  ScanCheckResult,
  simulateScanResult,
} from "@/lib/scan-checks";

type ScanState = "idle" | "scanning" | "done";

export default function ScannerPage() {
  const [url, setUrl] = useState("");
  const [scanState, setScanState] = useState<ScanState>("idle");
  const [results, setResults] = useState<ScanCheckResult[]>([]);
  const [currentCheckIndex, setCurrentCheckIndex] = useState(0);
  const abortRef = useRef(false);

  // Manual paste state
  const [showManualPaste, setShowManualPaste] = useState(false);
  const [pastedHtml, setPastedHtml] = useState("");
  const [manualScanning, setManualScanning] = useState(false);
  const [manualError, setManualError] = useState<string | null>(null);

  // Scan metadata
  const [scanMethod, setScanMethod] = useState<string | null>(null);
  const [siteBlocked, setSiteBlocked] = useState(false);
  const [blockedMessage, setBlockedMessage] = useState<string | null>(null);

  // Deep scan metadata
  const [scanMode, setScanMode] = useState<string | null>(null);
  const [deepScanResolved, setDeepScanResolved] = useState(0);

  const normalizeUrl = (input: string): string => {
    let u = input.trim();
    if (!/^https?:\/\//i.test(u)) u = "https://" + u;
    return u;
  };

  const startScan = useCallback(async () => {
    const normalized = normalizeUrl(url);
    if (!normalized || normalized === "https://") return;
    setUrl(normalized);
    setScanState("scanning");
    setResults([]);
    setCurrentCheckIndex(0);
    setShowManualPaste(false);
    setScanMethod(null);
    setSiteBlocked(false);
    setBlockedMessage(null);
    setScanMode(null);
    setDeepScanResolved(0);
    abortRef.current = false;

    // Try real API scan first
    try {
      const res = await fetch("/api/scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: normalized }),
      });

      if (res.ok) {
        const report = await res.json();

        // Map API results back to ScanCheckResult format for the UI
        const mappedResults: ScanCheckResult[] = (report.checks || []).map(
          (check: { id: string; name: string; status: string; details: string; severity: string; description: string }) => {
            const scanCheck = SCAN_CHECKS.find((c) => c.id === check.id);
            return {
              id: check.id,
              name: check.name || scanCheck?.name || check.id,
              category: scanCheck?.category || "General",
              severity: (scanCheck?.severity || check.severity?.toLowerCase() || "medium") as "critical" | "high" | "medium" | "low",
              dpdpSection: scanCheck?.dpdpSection || "",
              failMessage: check.details || scanCheck?.failMessage || "",
              passMessage: scanCheck?.passMessage || "",
              status: check.status.toLowerCase() as "pass" | "fail" | "warn" | "skip" | "pending" | "running",
            };
          }
        );

        setResults(mappedResults);
        setScanMethod(report.privacyDetectionMethod || "direct-fetch");
        setSiteBlocked(report.siteBlocked || false);
        setBlockedMessage(report.blockedMessage || null);
        setScanMode(report.scanMode || "fast");
        setDeepScanResolved(report.deepScanResolved || 0);
        setScanState("done");
        return;
      }
    } catch {
      // API failed — fall back to simulation
    }

    // Fallback: simulated scan
    const allResults: ScanCheckResult[] = [];

    for (let i = 0; i < SCAN_CHECKS.length; i++) {
      if (abortRef.current) return;

      const check = SCAN_CHECKS[i];
      const running: ScanCheckResult = { ...check, status: "running" };
      setResults([...allResults, running]);
      setCurrentCheckIndex(i);

      await new Promise((r) => setTimeout(r, 800 + Math.random() * 600));

      if (abortRef.current) return;

      const status = simulateScanResult(check.id);
      const resolved: ScanCheckResult = { ...check, status };
      allResults.push(resolved);
      setResults([...allResults]);
    }

    setScanMethod("simulated");
    setScanMode("fast");
    setScanState("done");
  }, [url]);

  const handleManualPasteScan = async () => {
    if (!pastedHtml.trim() || pastedHtml.length < 100) {
      setManualError("Please paste at least 100 characters of HTML source code.");
      return;
    }

    setManualScanning(true);
    setManualError(null);

    try {
      const normalized = normalizeUrl(url);
      const res = await fetch("/api/scan/manual", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: normalized, html: pastedHtml }),
      });

      if (!res.ok) {
        const body = await res.json();
        throw new Error(body.error || "Manual scan failed");
      }

      const report = await res.json();

      const mappedResults: ScanCheckResult[] = (report.checks || []).map(
        (check: { id: string; name: string; status: string; details: string; severity: string; description: string }) => {
          const scanCheck = SCAN_CHECKS.find((c) => c.id === check.id);
          return {
            id: check.id,
            name: check.name || scanCheck?.name || check.id,
            category: scanCheck?.category || "General",
            severity: (scanCheck?.severity || check.severity?.toLowerCase() || "medium") as "critical" | "high" | "medium" | "low",
            dpdpSection: scanCheck?.dpdpSection || "",
            failMessage: check.details || scanCheck?.failMessage || "",
            passMessage: scanCheck?.passMessage || "",
            status: check.status.toLowerCase() as "pass" | "fail" | "warn" | "skip" | "pending" | "running",
          };
        }
      );

      setResults(mappedResults);
      setScanMethod("manual-paste");
      setSiteBlocked(false);
      setBlockedMessage(null);
      setScanMode("fast");
      setDeepScanResolved(0);
      setShowManualPaste(false);
    } catch (err) {
      setManualError(
        err instanceof Error ? err.message : "Something went wrong"
      );
    } finally {
      setManualScanning(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (url.trim()) startScan();
  };

  const handleRescan = () => {
    abortRef.current = true;
    setScanState("idle");
    setResults([]);
    setCurrentCheckIndex(0);
    setShowManualPaste(false);
    setScanMethod(null);
    setSiteBlocked(false);
    setBlockedMessage(null);
    setScanMode(null);
    setDeepScanResolved(0);
  };

  const skipCount = results.filter((r) => r.status === "skip").length;
  const runnableCount = results.filter(
    (r) => r.status === "pass" || r.status === "fail"
  ).length;

  const usedDeepScan = scanMode === "fast+deep" || scanMode === "deep";

  return (
    <main className="min-h-screen bg-navy">
      {/* Nav */}
      <nav className="border-b border-gray-800 bg-navy/80 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-4">
          <a href="/" className="text-xl font-bold">
            GoLegal <span className="text-accent">Comply</span>
          </a>
          {scanState !== "idle" && (
            <button
              onClick={handleRescan}
              className="rounded-lg border border-gray-600 px-4 py-2 text-sm text-gray-300 transition hover:bg-navy-lighter"
            >
              New Scan
            </button>
          )}
        </div>
      </nav>

      <div className="mx-auto max-w-5xl px-4 py-8">
        {/* URL Input Section */}
        {scanState === "idle" && (
          <div className="flex min-h-[60vh] flex-col items-center justify-center text-center">
            <h1 className="mb-2 text-4xl font-bold tracking-tight sm:text-5xl">
              DPDP Compliance <span className="text-accent">Scanner</span>
            </h1>
            <p className="mb-8 max-w-lg text-lg text-gray-400">
              Check if your website complies with India&apos;s Digital Personal
              Data Protection Act 2023 — in 60 seconds.
            </p>

            <form
              onSubmit={handleSubmit}
              className="flex w-full max-w-xl flex-col gap-3 sm:flex-row"
            >
              <input
                type="text"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="Enter your website URL"
                className="flex-1 rounded-xl border border-gray-700 bg-surface px-5 py-4 text-lg text-white placeholder-gray-500 outline-none transition focus:border-accent focus:ring-1 focus:ring-accent"
                autoFocus
              />
              <button
                type="submit"
                disabled={!url.trim()}
                className="rounded-xl bg-accent px-8 py-4 text-lg font-semibold text-white transition hover:bg-accent-hover disabled:opacity-40 disabled:cursor-not-allowed"
              >
                Scan Now — Free
              </button>
            </form>

            <p className="mt-4 text-sm text-gray-500">
              Takes 30–60 seconds. No signup required.
            </p>

            {/* Trust badges */}
            <div className="mt-12 flex flex-wrap justify-center gap-6 text-sm text-gray-500">
              <span>30 compliance checks</span>
              <span>·</span>
              <span>Based on DPDP Act 2023</span>
              <span>·</span>
              <span>Instant results</span>
            </div>
          </div>
        )}

        {/* Scanning Progress */}
        {scanState === "scanning" && (
          <div className="py-8">
            <ScanProgress
              results={results}
              currentCheckIndex={currentCheckIndex}
            />
          </div>
        )}

        {/* Results */}
        {scanState === "done" && (
          <div className="py-8">
            {/* Scan Method Badge */}
            {scanMethod && (
              <div className="mb-4 flex flex-wrap items-center justify-center gap-2">
                <span className="rounded-full border border-gray-700 bg-surface px-3 py-1 text-xs text-gray-400">
                  Scanned via:{" "}
                  <span className="font-medium text-gray-300">
                    {scanMethod === "manual-paste"
                      ? "Manual paste"
                      : scanMethod === "simulated"
                        ? "Simulated"
                        : scanMethod.includes("sitemap")
                          ? "Sitemap"
                          : scanMethod.includes("cache")
                            ? "Search engine cache"
                            : scanMethod.includes("cors-proxy")
                              ? "CORS proxy"
                              : "Direct fetch"}
                  </span>
                </span>
                {usedDeepScan && (
                  <span className="rounded-full border border-blue-700/50 bg-blue-950/50 px-3 py-1 text-xs text-blue-400">
                    + Deep analysis
                  </span>
                )}
                {skipCount > 0 && (
                  <span className="rounded-full border border-amber-700/50 bg-amber-950/50 px-3 py-1 text-xs text-amber-400">
                    {runnableCount}/{results.length} checks completed ({skipCount} skipped)
                  </span>
                )}
              </div>
            )}

            {/* Site Blocked Banner */}
            {siteBlocked && (
              <div className="mb-6 rounded-xl border border-amber-700/50 bg-amber-950/30 px-6 py-4">
                <div className="flex items-start gap-3">
                  <span className="mt-0.5 text-lg text-amber-400">&#9888;</span>
                  <div>
                    <h3 className="font-semibold text-amber-300">
                      Scan blocked by website
                    </h3>
                    <p className="mt-1 text-sm text-amber-200/80">
                      {blockedMessage ||
                        "This website has bot protection that prevents automated scanning. This does NOT mean they lack a privacy policy."}
                    </p>
                    <p className="mt-2 text-sm text-amber-200/80">
                      {runnableCount}/{results.length} checks completed, {skipCount} checks could not be performed.{" "}
                      <button
                        onClick={() => setShowManualPaste(true)}
                        className="font-medium text-accent underline hover:text-accent-hover"
                      >
                        Use manual paste for a complete scan
                      </button>
                    </p>
                  </div>
                </div>
              </div>
            )}

            <ScanReport results={results} url={url} />

            {/* Deep Scan Note */}
            {usedDeepScan && (
              <div className="mt-6 rounded-xl border border-blue-800/40 bg-blue-950/20 px-6 py-4">
                <div className="flex items-start gap-3">
                  <span className="mt-0.5 text-lg text-blue-400">&#9881;</span>
                  <div>
                    <p className="text-sm text-blue-300">
                      This scan used deep analysis for JavaScript-rendered content.
                      {deepScanResolved > 0 && (
                        <span className="ml-1 font-medium">
                          Deep analysis completed — {deepScanResolved} additional check{deepScanResolved !== 1 ? "s" : ""} resolved.
                        </span>
                      )}
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Manual Paste Section (Layer 6) */}
            {(siteBlocked || showManualPaste) && (
              <div className="mt-8 rounded-xl border border-gray-700 bg-surface p-6">
                <div className="mb-4 flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-bold text-white">
                      Deep Scan — Paste Page Source
                    </h3>
                    <p className="mt-1 text-sm text-gray-400">
                      For sites with bot protection: visit your website, right-click
                      → &quot;View Page Source&quot;, copy all the HTML, and paste it below.
                      This works on ANY website regardless of protection.
                    </p>
                  </div>
                  {!siteBlocked && (
                    <button
                      onClick={() => setShowManualPaste(false)}
                      className="text-sm text-gray-500 hover:text-gray-300"
                    >
                      Close
                    </button>
                  )}
                </div>

                <textarea
                  value={pastedHtml}
                  onChange={(e) => setPastedHtml(e.target.value)}
                  placeholder="Paste your page source code here (Ctrl+A, Ctrl+C from View Source)..."
                  className="h-40 w-full rounded-lg border border-gray-600 bg-navy p-4 font-mono text-sm text-gray-300 placeholder-gray-600 outline-none transition focus:border-accent focus:ring-1 focus:ring-accent"
                />

                {manualError && (
                  <p className="mt-2 text-sm text-red-400">{manualError}</p>
                )}

                <div className="mt-3 flex items-center gap-3">
                  <button
                    onClick={handleManualPasteScan}
                    disabled={manualScanning || !pastedHtml.trim()}
                    className="rounded-lg bg-accent px-6 py-2.5 font-semibold text-white transition hover:bg-accent-hover disabled:opacity-40 disabled:cursor-not-allowed"
                  >
                    {manualScanning ? "Scanning pasted HTML..." : "Scan Pasted HTML"}
                  </button>
                  <span className="text-xs text-gray-500">
                    {pastedHtml.length > 0
                      ? `${pastedHtml.length.toLocaleString()} characters pasted`
                      : "No HTML pasted yet"}
                  </span>
                </div>
              </div>
            )}

            {/* Show manual paste option even for non-blocked sites */}
            {!siteBlocked && !showManualPaste && scanState === "done" && (
              <div className="mt-4 text-center">
                <button
                  onClick={() => setShowManualPaste(true)}
                  className="text-sm text-gray-500 underline transition hover:text-gray-300"
                >
                  Site not scanning correctly? Try pasting your page source manually
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </main>
  );
}
