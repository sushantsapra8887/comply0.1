import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "GoLegal Comply — DPDP Compliance Scanner",
  description:
    "Free website scanner for India's Digital Personal Data Protection Act (DPDP) 2023 compliance. Check your website in 60 seconds.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-navy text-white antialiased">
        {children}
      </body>
    </html>
  );
}
