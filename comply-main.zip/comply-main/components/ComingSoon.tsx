"use client";

import Link from "next/link";

export function ComingSoon({
  title = "Coming Soon",
  description = "We're building something great. Stay tuned.",
  showNotify = false,
}: Readonly<{
  title?: string;
  description?: string;
  showNotify?: boolean;
}>) {
  return (
    <div className="min-h-screen bg-navy-900 flex flex-col">
      {/* Background orbs */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 -left-32 w-96 h-96 bg-accent/15 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 -right-32 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-accent/5 rounded-full blur-3xl" />
      </div>

      {/* Nav bar - matches main app */}
      <nav className="relative z-10 border-b border-white/5 bg-navy-900/80 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-6 h-14 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-accent flex items-center justify-center">
              <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
            </div>
            <span className="text-lg font-bold text-white">GoLegal <span className="text-accent">Comply</span></span>
          </Link>
          <Link href="/" className="text-sm text-slate-400 hover:text-white transition-colors">Back to home</Link>
        </div>
      </nav>

      {/* Main content */}
      <main className="relative z-10 flex-1 flex items-center justify-center px-4 py-16">
        <div className="w-full max-w-lg">
          <div className="glass-card p-8 md:p-10 text-center border-accent/10">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-accent/10 border border-accent/20 rounded-full px-4 py-1.5 mb-6">
              <span className="w-2 h-2 bg-accent rounded-full animate-pulse" />
              <span className="text-sm text-accent font-medium">In development</span>
            </div>

            {/* Title with gradient */}
            <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-3">
              <span className="text-gradient">{title}</span>
            </h1>
            <p className="text-slate-400 text-lg mb-8 max-w-sm mx-auto">
              {description}
            </p>

            {/* Progress bar accent */}
            <div className="h-1.5 bg-navy-700 rounded-full overflow-hidden mb-8 max-w-xs mx-auto">
              <div
                className="h-full bg-gradient-to-r from-accent to-pink-400 rounded-full animate-progress"
                style={{ width: "65%" }}
              />
            </div>

            {showNotify && (
              <>
                <p className="text-sm text-slate-500 mb-4">Get notified when we launch</p>
                <form
                  onSubmit={(e) => e.preventDefault()}
                  className="flex gap-2 max-w-sm mx-auto"
                >
                  <input
                    type="email"
                    placeholder="you@company.com"
                    className="flex-1 input-dark text-sm py-2.5"
                  />
                  <button type="submit" className="btn-accent py-2.5 px-5 text-sm whitespace-nowrap">
                    Notify me
                  </button>
                </form>
              </>
            )}

            <Link
              href="/"
              className="mt-8 inline-flex items-center gap-2 text-sm text-slate-400 hover:text-accent transition-colors"
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
              Back to scanner
            </Link>
          </div>
        </div>
      </main>
    </div>
  );
}
