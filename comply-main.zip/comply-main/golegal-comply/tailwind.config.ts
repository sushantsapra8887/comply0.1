import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "var(--background)",
        foreground: "var(--foreground)",
        primary: {
          50: "#f0f4ff",
          100: "#dbe4ff",
          200: "#bac8ff",
          300: "#91a7ff",
          400: "#748ffc",
          500: "#5c7cfa",
          600: "#4c6ef5",
          700: "#4263eb",
          800: "#3b5bdb",
          900: "#364fc7",
        },
        navy: {
          50: "#e7e9ef",
          100: "#c3c8d4",
          200: "#9ba3b8",
          300: "#727e9c",
          400: "#546287",
          500: "#354672",
          600: "#2d3d66",
          700: "#233155",
          800: "#1a2744",
          900: "#0f172a",
          950: "#0a0f1e",
        },
        accent: {
          DEFAULT: "#E94560",
          50: "#fef1f3",
          100: "#fde4e8",
          200: "#fbc9d2",
          300: "#f8a0b0",
          400: "#f26d85",
          500: "#E94560",
          600: "#d42a4a",
          700: "#b21e3c",
          800: "#951c38",
          900: "#7f1b35",
        },
        slate: {
          750: "#293548",
          850: "#172033",
        },
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        mono: ["JetBrains Mono", "monospace"],
      },
    },
  },
  plugins: [],
};
export default config;
