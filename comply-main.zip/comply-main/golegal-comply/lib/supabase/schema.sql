-- Users (handled by Supabase Auth)

-- Scan Reports
CREATE TABLE scan_reports (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id),
  url TEXT NOT NULL,
  score INTEGER NOT NULL DEFAULT 0,
  total_checks INTEGER NOT NULL DEFAULT 30,
  passed_checks INTEGER NOT NULL DEFAULT 0,
  failed_checks INTEGER NOT NULL DEFAULT 0,
  results JSONB NOT NULL DEFAULT '[]',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Companies (for paid users)
CREATE TABLE companies (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id),
  name TEXT NOT NULL,
  website TEXT,
  industry TEXT,
  employee_count TEXT,
  compliance_score INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE scan_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE companies ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Users can view own reports" ON scan_reports FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own reports" ON scan_reports FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Anyone can insert scan (free tool)" ON scan_reports FOR INSERT WITH CHECK (user_id IS NULL);
