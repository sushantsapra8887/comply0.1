export type Severity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';

export interface ScanCheck {
  id: string;           // SC01-SC30
  category: string;     // Notice, Consent, Security, etc.
  name: string;         // What we checked
  status: 'PASS' | 'FAIL' | 'WARN' | 'SKIP';
  severity: Severity;
  message: string;      // User-facing result message
  dpdpSource: string;   // Section reference
  details?: string;     // Technical details
}

export interface ScanReport {
  id: string;
  url: string;
  score: number;        // 0-100
  grade: 'A' | 'B' | 'C' | 'D' | 'F';
  totalChecks: number;
  passedChecks: number;
  failedChecks: number;
  checks: ScanCheck[];
  penaltyExposure: string;  // e.g., "Up to ₹250 Crore"
  scanDate: string;
  scanDuration: number; // milliseconds
}
