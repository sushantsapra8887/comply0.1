import { ScanCheck } from './types';

type Grade = 'A' | 'B' | 'C' | 'D' | 'F';

const SEVERITY_WEIGHTS = {
  CRITICAL: 10,
  HIGH: 7,
  MEDIUM: 4,
  LOW: 2,
  INFO: 1,
};

export function calculateScore(checks: ScanCheck[]): { score: number; grade: Grade } {
  if (checks.length === 0) {
    return { score: 0, grade: 'F' };
  }

  const totalWeight = checks.reduce((sum, check) => sum + SEVERITY_WEIGHTS[check.severity], 0);
  const passedWeight = checks
    .filter((c) => c.status === 'PASS')
    .reduce((sum, check) => sum + SEVERITY_WEIGHTS[check.severity], 0);

  const score = totalWeight > 0 ? Math.round((passedWeight / totalWeight) * 100) : 0;
  const grade = getGrade(score);

  return { score, grade };
}

function getGrade(score: number): Grade {
  if (score >= 90) return 'A';
  if (score >= 75) return 'B';
  if (score >= 60) return 'C';
  if (score >= 40) return 'D';
  return 'F';
}
