'use client';

import { useState } from 'react';

interface ScanFormProps {
  onScan?: (url: string) => void;
  variant?: 'hero' | 'page';
}

export default function ScanForm({ onScan, variant = 'page' }: ScanFormProps) {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;

    setLoading(true);
    try {
      onScan?.(url);
      // TODO: Call /api/scan endpoint
    } finally {
      setLoading(false);
    }
  };

  if (variant === 'hero') {
    return (
      <form onSubmit={handleSubmit} className="mx-auto flex w-full max-w-2xl flex-col gap-3 sm:flex-row">
        <input
          type="url"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="Enter your website URL (e.g., https://example.in)"
          className="flex-1 rounded-xl border border-navy-600 bg-navy-800/80 px-5 py-4 text-white placeholder-slate-400 outline-none ring-accent/50 transition focus:border-accent focus:ring-2"
          required
        />
        <button
          type="submit"
          disabled={loading}
          className="whitespace-nowrap rounded-xl bg-accent px-8 py-4 font-semibold text-white shadow-lg shadow-accent/25 transition hover:bg-accent-600 hover:shadow-accent/40 disabled:opacity-50"
        >
          {loading ? 'Scanning...' : 'Scan Now — Free'}
        </button>
      </form>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="flex w-full flex-col gap-3 sm:flex-row">
      <input
        type="url"
        value={url}
        onChange={(e) => setUrl(e.target.value)}
        placeholder="Enter website URL to scan"
        className="flex-1 rounded-lg border border-navy-600 bg-navy-800 px-4 py-3 text-white placeholder-slate-400 outline-none ring-accent/50 transition focus:border-accent focus:ring-2"
        required
      />
      <button
        type="submit"
        disabled={loading}
        className="rounded-lg bg-accent px-6 py-3 font-semibold text-white transition hover:bg-accent-600 disabled:opacity-50"
      >
        {loading ? 'Scanning...' : 'Start Scan'}
      </button>
    </form>
  );
}
