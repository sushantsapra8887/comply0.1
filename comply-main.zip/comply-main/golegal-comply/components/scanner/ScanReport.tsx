'use client';

import { ScanReport as ScanReportType, ScanCheck } from '@/lib/scanner/types';

interface ScanReportProps {
  report: ScanReportType;
}

const gradeColors: Record<string, string> = {
  A: 'text-green-400 border-green-400',
  B: 'text-blue-400 border-blue-400',
  C: 'text-yellow-400 border-yellow-400',
  D: 'text-orange-400 border-orange-400',
  F: 'text-red-400 border-red-400',
};

const statusColors: Record<string, string> = {
  PASS: 'bg-green-500/10 text-green-400',
  FAIL: 'bg-red-500/10 text-red-400',
  WARN: 'bg-yellow-500/10 text-yellow-400',
  SKIP: 'bg-slate-500/10 text-slate-400',
};

function CheckItem({ check }: { check: ScanCheck }) {
  return (
    <div className="flex items-start gap-3 rounded-lg border border-navy-700 bg-navy-800/50 p-4">
      <span className={`mt-0.5 rounded px-2 py-0.5 text-xs font-medium ${statusColors[check.status]}`}>
        {check.status}
      </span>
      <div className="flex-1">
        <div className="flex items-center gap-2">
          <span className="font-mono text-xs text-slate-500">{check.id}</span>
          <span className="text-sm font-medium text-white">{check.name}</span>
        </div>
        <p className="mt-1 text-sm text-slate-400">{check.message}</p>
        <p className="mt-1 text-xs text-slate-500">DPDP Reference: {check.dpdpSource}</p>
      </div>
      <span className="text-xs text-slate-500">{check.severity}</span>
    </div>
  );
}

export default function ScanReport({ report }: ScanReportProps) {
  return (
    <div className="space-y-6">
      {/* Score card */}
      <div className="rounded-xl border border-navy-700 bg-navy-800 p-6">
        <div className="flex flex-col items-center gap-6 sm:flex-row">
          <div className={`flex h-20 w-20 items-center justify-center rounded-full border-4 text-3xl font-bold ${gradeColors[report.grade]}`}>
            {report.grade}
          </div>
          <div className="text-center sm:text-left">
            <h2 className="text-2xl font-bold text-white">{report.score}/100</h2>
            <p className="text-slate-400">{report.url}</p>
            <p className="mt-1 text-sm text-accent">{report.penaltyExposure}</p>
          </div>
          <div className="flex gap-4 sm:ml-auto">
            <div className="text-center">
              <p className="text-2xl font-bold text-green-400">{report.passedChecks}</p>
              <p className="text-xs text-slate-400">Passed</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-red-400">{report.failedChecks}</p>
              <p className="text-xs text-slate-400">Failed</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-slate-400">{report.totalChecks}</p>
              <p className="text-xs text-slate-400">Total</p>
            </div>
          </div>
        </div>
      </div>

      {/* Check results */}
      <div className="space-y-3">
        {report.checks.map((check) => (
          <CheckItem key={check.id} check={check} />
        ))}
        {report.checks.length === 0 && (
          <p className="rounded-lg border border-navy-700 bg-navy-800/50 p-8 text-center text-slate-400">
            No scan results yet. Run a scan to see detailed results.
          </p>
        )}
      </div>
    </div>
  );
}
