'use client';

interface ScanProgressProps {
  progress: number; // 0-100
  currentCheck?: string;
}

export default function ScanProgress({ progress, currentCheck }: ScanProgressProps) {
  return (
    <div className="w-full rounded-xl border border-navy-700 bg-navy-800 p-6">
      <div className="mb-2 flex items-center justify-between text-sm">
        <span className="text-slate-300">Scanning in progress...</span>
        <span className="font-mono text-accent">{progress}%</span>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-navy-700">
        <div
          className="h-full rounded-full bg-accent transition-all duration-500"
          style={{ width: `${progress}%` }}
        />
      </div>
      {currentCheck && (
        <p className="mt-3 text-xs text-slate-400">
          Checking: {currentCheck}
        </p>
      )}
    </div>
  );
}
