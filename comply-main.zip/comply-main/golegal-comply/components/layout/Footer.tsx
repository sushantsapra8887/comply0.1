import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="border-t border-navy-700/50 bg-navy-950">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          <div>
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent font-bold text-white">
                G
              </div>
              <span className="text-lg font-bold text-white">
                GoLegal<span className="text-accent">Comply</span>
              </span>
            </div>
            <p className="mt-3 text-sm text-slate-400">
              DPDP Act compliance made simple for Indian businesses.
            </p>
          </div>

          <div>
            <h3 className="mb-3 text-sm font-semibold uppercase tracking-wider text-slate-300">
              Product
            </h3>
            <ul className="space-y-2 text-sm text-slate-400">
              <li><Link href="/scanner" className="transition hover:text-white">Free Scanner</Link></li>
              <li><Link href="/dashboard" className="transition hover:text-white">Dashboard</Link></li>
              <li><span className="cursor-default">Pricing</span></li>
            </ul>
          </div>

          <div>
            <h3 className="mb-3 text-sm font-semibold uppercase tracking-wider text-slate-300">
              Resources
            </h3>
            <ul className="space-y-2 text-sm text-slate-400">
              <li><span className="cursor-default">DPDP Act Guide</span></li>
              <li><span className="cursor-default">Compliance Checklist</span></li>
              <li><span className="cursor-default">Blog</span></li>
            </ul>
          </div>

          <div>
            <h3 className="mb-3 text-sm font-semibold uppercase tracking-wider text-slate-300">
              Legal
            </h3>
            <ul className="space-y-2 text-sm text-slate-400">
              <li><span className="cursor-default">Privacy Policy</span></li>
              <li><span className="cursor-default">Terms of Service</span></li>
              <li><span className="cursor-default">Contact</span></li>
            </ul>
          </div>
        </div>

        <div className="mt-8 border-t border-navy-700/50 pt-8 text-center text-sm text-slate-500">
          &copy; {new Date().getFullYear()} GoLegal Comply. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
