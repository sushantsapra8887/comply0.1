'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-navy-700/50 bg-navy-900/95 backdrop-blur-sm">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent font-bold text-white">
            G
          </div>
          <span className="text-xl font-bold text-white">
            GoLegal<span className="text-accent">Comply</span>
          </span>
        </Link>

        {/* Desktop nav */}
        <div className="hidden items-center gap-8 md:flex">
          <Link href="/scanner" className="text-sm text-slate-300 transition hover:text-white">
            Free Scanner
          </Link>
          <Link href="/dashboard" className="text-sm text-slate-300 transition hover:text-white">
            Dashboard
          </Link>
          <Link
            href="/scanner"
            className="rounded-lg bg-accent px-4 py-2 text-sm font-semibold text-white transition hover:bg-accent-600"
          >
            Scan Now — Free
          </Link>
        </div>

        {/* Mobile hamburger */}
        <button
          className="md:hidden text-white"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Toggle menu"
        >
          <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            {mobileOpen ? (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            ) : (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            )}
          </svg>
        </button>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="border-t border-navy-700/50 bg-navy-900 px-4 py-4 md:hidden">
          <div className="flex flex-col gap-4">
            <Link href="/scanner" className="text-sm text-slate-300 transition hover:text-white">
              Free Scanner
            </Link>
            <Link href="/dashboard" className="text-sm text-slate-300 transition hover:text-white">
              Dashboard
            </Link>
            <Link
              href="/scanner"
              className="rounded-lg bg-accent px-4 py-2 text-center text-sm font-semibold text-white transition hover:bg-accent-600"
            >
              Scan Now — Free
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}
