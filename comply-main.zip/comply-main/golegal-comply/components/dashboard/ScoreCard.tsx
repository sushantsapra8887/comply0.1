'use client';

interface ScoreCardProps {
  score: number;
  label: string;
  change?: number;
}

export default function ScoreCard({ score, label, change }: ScoreCardProps) {
  const getScoreColor = (s: number) => {
    if (s >= 80) return 'text-green-400';
    if (s >= 60) return 'text-yellow-400';
    if (s >= 40) return 'text-orange-400';
    return 'text-red-400';
  };

  return (
    <div className="rounded-xl border border-navy-700 bg-navy-800 p-6">
      <p className="text-sm text-slate-400">{label}</p>
      <p className={`mt-2 text-4xl font-bold ${getScoreColor(score)}`}>{score}</p>
      {change !== undefined && (
        <p className={`mt-1 text-sm ${change >= 0 ? 'text-green-400' : 'text-red-400'}`}>
          {change >= 0 ? '+' : ''}{change} from last scan
        </p>
      )}
    </div>
  );
}
