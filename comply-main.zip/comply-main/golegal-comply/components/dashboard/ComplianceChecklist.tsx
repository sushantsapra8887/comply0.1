'use client';

interface ChecklistItem {
  id: number;
  title: string;
  description: string;
  completed: boolean;
}

const defaultChecklist: ChecklistItem[] = [
  { id: 1, title: 'Appoint a Data Protection Officer', description: 'Designate a DPO as required under the DPDP Act', completed: false },
  { id: 2, title: 'Publish Privacy Notice', description: 'Create and publish a DPDP-compliant privacy notice', completed: false },
  { id: 3, title: 'Implement Consent Mechanism', description: 'Set up lawful consent collection with clear purpose', completed: false },
  { id: 4, title: 'Enable Data Principal Rights', description: 'Allow users to access, correct, and erase their data', completed: false },
  { id: 5, title: 'Set Up Grievance Redressal', description: 'Establish a grievance officer and redressal process', completed: false },
  { id: 6, title: 'Implement Data Security Measures', description: 'Apply reasonable security safeguards to protect data', completed: false },
  { id: 7, title: 'Children\'s Data Protection', description: 'Implement age verification and parental consent', completed: false },
  { id: 8, title: 'Data Breach Notification Process', description: 'Set up procedures for notifying DPBI of breaches', completed: false },
  { id: 9, title: 'Vendor & Processor Agreements', description: 'Update contracts with data processors for compliance', completed: false },
  { id: 10, title: 'Conduct Compliance Audit', description: 'Run a full DPDP compliance scan and address gaps', completed: false },
];

interface ComplianceChecklistProps {
  items?: ChecklistItem[];
}

export default function ComplianceChecklist({ items = defaultChecklist }: ComplianceChecklistProps) {
  return (
    <div className="space-y-3">
      {items.map((item) => (
        <div
          key={item.id}
          className="flex items-start gap-4 rounded-lg border border-navy-700 bg-navy-800/50 p-4 transition hover:border-navy-600"
        >
          <div className={`mt-1 flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full border-2 ${
            item.completed ? 'border-green-400 bg-green-400/20' : 'border-slate-600'
          }`}>
            {item.completed && (
              <svg className="h-3 w-3 text-green-400" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
            )}
          </div>
          <div className="flex-1">
            <h3 className="text-sm font-medium text-white">{item.id}. {item.title}</h3>
            <p className="mt-0.5 text-xs text-slate-400">{item.description}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
