import ComplianceChecklist from '@/components/dashboard/ComplianceChecklist';
import ScoreCard from '@/components/dashboard/ScoreCard';

export default function DashboardPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold text-white">Compliance Dashboard</h1>
      <p className="mt-1 text-sm text-slate-400">
        Track your DPDP Act compliance progress with the 10-point checklist.
      </p>

      {/* Score cards */}
      <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <ScoreCard score={0} label="Compliance Score" />
        <ScoreCard score={0} label="Checks Passed" />
        <ScoreCard score={0} label="Total Scans" />
      </div>

      {/* Checklist */}
      <div className="mt-8">
        <h2 className="mb-4 text-lg font-semibold text-white">10-Point DPDP Compliance Checklist</h2>
        <ComplianceChecklist />
      </div>
    </div>
  );
}
