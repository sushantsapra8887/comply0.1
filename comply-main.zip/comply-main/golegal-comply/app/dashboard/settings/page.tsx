export default function SettingsPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold text-white">Account Settings</h1>
      <p className="mt-1 text-sm text-slate-400">
        Manage your account, company details, and notification preferences.
      </p>

      <div className="mt-8 space-y-6">
        {/* Profile section */}
        <div className="rounded-xl border border-navy-700 bg-navy-800/50 p-6">
          <h2 className="text-lg font-semibold text-white">Profile</h2>
          <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-sm text-slate-400">Full Name</label>
              <input
                type="text"
                placeholder="Your name"
                className="mt-1 w-full rounded-lg border border-navy-600 bg-navy-800 px-4 py-2.5 text-white placeholder-slate-500 outline-none focus:border-accent"
                disabled
              />
            </div>
            <div>
              <label className="block text-sm text-slate-400">Email</label>
              <input
                type="email"
                placeholder="your@email.com"
                className="mt-1 w-full rounded-lg border border-navy-600 bg-navy-800 px-4 py-2.5 text-white placeholder-slate-500 outline-none focus:border-accent"
                disabled
              />
            </div>
          </div>
        </div>

        {/* Company section */}
        <div className="rounded-xl border border-navy-700 bg-navy-800/50 p-6">
          <h2 className="text-lg font-semibold text-white">Company Details</h2>
          <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-sm text-slate-400">Company Name</label>
              <input
                type="text"
                placeholder="Your company"
                className="mt-1 w-full rounded-lg border border-navy-600 bg-navy-800 px-4 py-2.5 text-white placeholder-slate-500 outline-none focus:border-accent"
                disabled
              />
            </div>
            <div>
              <label className="block text-sm text-slate-400">Website</label>
              <input
                type="url"
                placeholder="https://example.com"
                className="mt-1 w-full rounded-lg border border-navy-600 bg-navy-800 px-4 py-2.5 text-white placeholder-slate-500 outline-none focus:border-accent"
                disabled
              />
            </div>
            <div>
              <label className="block text-sm text-slate-400">Industry</label>
              <input
                type="text"
                placeholder="e.g., FinTech, EdTech"
                className="mt-1 w-full rounded-lg border border-navy-600 bg-navy-800 px-4 py-2.5 text-white placeholder-slate-500 outline-none focus:border-accent"
                disabled
              />
            </div>
            <div>
              <label className="block text-sm text-slate-400">Employee Count</label>
              <input
                type="text"
                placeholder="e.g., 10-50"
                className="mt-1 w-full rounded-lg border border-navy-600 bg-navy-800 px-4 py-2.5 text-white placeholder-slate-500 outline-none focus:border-accent"
                disabled
              />
            </div>
          </div>
        </div>

        <p className="text-center text-sm text-slate-500">
          Settings will be editable after authentication is configured.
        </p>
      </div>
    </div>
  );
}
