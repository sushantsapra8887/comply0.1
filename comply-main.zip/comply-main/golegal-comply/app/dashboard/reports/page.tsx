export default function ReportsPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold text-white">Scan Reports</h1>
      <p className="mt-1 text-sm text-slate-400">
        View your past compliance scan reports and track improvements over time.
      </p>

      {/* Placeholder */}
      <div className="mt-8 rounded-xl border border-navy-700 bg-navy-800/50 p-12 text-center">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-navy-700/50">
          <svg className="h-8 w-8 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
        </div>
        <h3 className="mt-4 text-lg font-medium text-white">No Reports Yet</h3>
        <p className="mt-2 text-sm text-slate-400">
          Run your first scan to see reports here. Each scan generates a detailed compliance report
          that you can download as PDF.
        </p>
        <a
          href="/scanner"
          className="mt-6 inline-block rounded-lg bg-accent px-6 py-2.5 text-sm font-semibold text-white transition hover:bg-accent-600"
        >
          Run Your First Scan
        </a>
      </div>
    </div>
  );
}
