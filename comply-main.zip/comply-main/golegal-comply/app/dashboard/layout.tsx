import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Dashboard — GoLegal Comply',
};

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // TODO: Add auth check — redirect to login if not authenticated
  return (
    <div className="min-h-screen bg-navy-900">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Dashboard sidebar nav */}
        <div className="flex flex-col gap-8 lg:flex-row">
          <aside className="w-full flex-shrink-0 lg:w-56">
            <nav className="flex flex-row gap-1 overflow-x-auto lg:flex-col">
              <a
                href="/dashboard"
                className="whitespace-nowrap rounded-lg px-4 py-2.5 text-sm font-medium text-slate-300 transition hover:bg-navy-800 hover:text-white"
              >
                Compliance Checklist
              </a>
              <a
                href="/dashboard/reports"
                className="whitespace-nowrap rounded-lg px-4 py-2.5 text-sm font-medium text-slate-300 transition hover:bg-navy-800 hover:text-white"
              >
                Scan Reports
              </a>
              <a
                href="/dashboard/settings"
                className="whitespace-nowrap rounded-lg px-4 py-2.5 text-sm font-medium text-slate-300 transition hover:bg-navy-800 hover:text-white"
              >
                Settings
              </a>
            </nav>
          </aside>
          <div className="flex-1">{children}</div>
        </div>
      </div>
    </div>
  );
}
