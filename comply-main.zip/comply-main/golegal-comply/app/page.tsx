import ScanForm from '@/components/scanner/ScanForm';

export default function HomePage() {
  return (
    <div className="bg-navy-900">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        {/* Gradient background */}
        <div className="absolute inset-0 bg-gradient-to-b from-navy-950 via-navy-900 to-navy-900" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-accent/10 via-transparent to-transparent" />

        <div className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6 sm:py-32 lg:px-8 lg:py-40">
          <div className="text-center">
            {/* Badge */}
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-accent/30 bg-accent/10 px-4 py-1.5">
              <span className="h-2 w-2 animate-pulse rounded-full bg-accent" />
              <span className="text-sm font-medium text-accent">
                DPDP Act 2023 — Now in Effect
              </span>
            </div>

            <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
              Is Your Website{' '}
              <span className="bg-gradient-to-r from-accent to-accent-400 bg-clip-text text-transparent">
                DPDP Compliant?
              </span>
            </h1>

            <p className="mx-auto mt-6 max-w-2xl text-lg text-slate-300 sm:text-xl">
              Scan your website in seconds. Get a detailed compliance report against India&apos;s
              Digital Personal Data Protection Act.
            </p>

            {/* URL Input */}
            <div className="mt-10">
              <ScanForm variant="hero" />
            </div>

            {/* Stats */}
            <div className="mt-8 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-sm text-slate-400">
              <span className="flex items-center gap-1.5">
                <svg className="h-4 w-4 text-accent" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
                82 compliance rules checked
              </span>
              <span className="flex items-center gap-1.5">
                <svg className="h-4 w-4 text-accent" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
                30 automated scans
              </span>
              <span className="flex items-center gap-1.5">
                <svg className="h-4 w-4 text-accent" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
                Free instant report
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Social Proof Section */}
      <section className="border-y border-navy-700/50 bg-navy-950/50">
        <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
          <p className="text-center text-sm font-medium uppercase tracking-widest text-slate-500">
            Trusted by 500+ Indian Startups & Enterprises
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-x-12 gap-y-6">
            {['TechCorp', 'FinServe', 'HealthPlus', 'EduStart', 'ShopEasy'].map((name) => (
              <div key={name} className="text-lg font-bold text-slate-600/60">
                {name}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-navy-900 py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-white sm:text-4xl">
              Comprehensive DPDP Compliance Checks
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-slate-400">
              Our scanner performs 30 automated checks across 6 key compliance areas of the DPDP Act.
            </p>
          </div>

          <div className="mt-16 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                title: 'Privacy Notice',
                checks: 'SC01-SC06',
                description: 'Validates privacy policy presence, accessibility, and DPDP Act compliance.',
              },
              {
                title: 'Consent Mechanism',
                checks: 'SC07-SC11',
                description: 'Checks consent collection, granularity, and withdrawal mechanisms.',
              },
              {
                title: 'Security Measures',
                checks: 'SC12-SC18',
                description: 'Tests HTTPS, SSL, security headers, and data encryption indicators.',
              },
              {
                title: 'Data Collection',
                checks: 'SC19-SC22',
                description: 'Audits data minimization, purpose limitation, and third-party trackers.',
              },
              {
                title: 'Data Principal Rights',
                checks: 'SC23-SC26, SC29-SC30',
                description: 'Verifies access, correction, erasure rights and grievance redressal.',
              },
              {
                title: "Children's Data",
                checks: 'SC27-SC28',
                description: 'Checks age verification and parental consent mechanisms.',
              },
            ].map((feature) => (
              <div
                key={feature.title}
                className="rounded-xl border border-navy-700 bg-navy-800/50 p-6 transition hover:border-accent/30 hover:bg-navy-800"
              >
                <h3 className="text-lg font-semibold text-white">{feature.title}</h3>
                <p className="mt-1 font-mono text-xs text-accent">{feature.checks}</p>
                <p className="mt-3 text-sm text-slate-400">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Penalty Warning Section */}
      <section className="relative overflow-hidden bg-navy-950">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-accent/5 via-transparent to-transparent" />
        <div className="relative mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-white sm:text-4xl">
              Penalties up to{' '}
              <span className="text-accent">&#8377;250 Crore</span>.
              <br />
              Don&apos;t risk it.
            </h2>
            <p className="mx-auto mt-6 max-w-2xl text-lg text-slate-400">
              The DPDP Act imposes significant penalties for non-compliance. A single data breach or
              compliance failure could result in fines up to &#8377;250 Crore per instance. Get ahead
              of enforcement — scan your website today.
            </p>

            <div className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-3">
              <div className="rounded-xl border border-red-500/20 bg-red-500/5 p-6">
                <p className="text-3xl font-bold text-red-400">&#8377;250 Cr</p>
                <p className="mt-2 text-sm text-slate-400">Maximum penalty per data breach</p>
              </div>
              <div className="rounded-xl border border-orange-500/20 bg-orange-500/5 p-6">
                <p className="text-3xl font-bold text-orange-400">&#8377;200 Cr</p>
                <p className="mt-2 text-sm text-slate-400">Penalty for children&apos;s data violations</p>
              </div>
              <div className="rounded-xl border border-yellow-500/20 bg-yellow-500/5 p-6">
                <p className="text-3xl font-bold text-yellow-400">&#8377;50 Cr</p>
                <p className="mt-2 text-sm text-slate-400">Penalty for non-compliance with obligations</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-navy-900 py-20">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white sm:text-4xl">
            Get Your Free Compliance Report
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-slate-400">
            Enter your website URL and receive a detailed DPDP Act compliance report in under 60
            seconds. No signup required.
          </p>
          <div className="mt-8">
            <ScanForm variant="hero" />
          </div>
        </div>
      </section>
    </div>
  );
}
