import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const id = searchParams.get('id');

  if (!id) {
    return NextResponse.json(
      { error: 'Report ID is required' },
      { status: 400 }
    );
  }

  // TODO: Fetch report from Supabase by ID
  // const { data, error } = await supabase
  //   .from('scan_reports')
  //   .select('*')
  //   .eq('id', id)
  //   .single();

  return NextResponse.json(
    { error: 'Report fetching not yet implemented' },
    { status: 501 }
  );
}
