import { NextRequest, NextResponse } from 'next/server';
import { runScan } from '@/lib/scanner/engine';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { url } = body;

    if (!url || typeof url !== 'string') {
      return NextResponse.json(
        { error: 'A valid URL is required' },
        { status: 400 }
      );
    }

    // Validate URL format
    try {
      new URL(url);
    } catch {
      return NextResponse.json(
        { error: 'Invalid URL format' },
        { status: 400 }
      );
    }

    const report = await runScan(url);

    // TODO: Save to Supabase if user is authenticated

    return NextResponse.json(report);
  } catch (error) {
    console.error('Scan error:', error);
    return NextResponse.json(
      { error: 'An error occurred during scanning' },
      { status: 500 }
    );
  }
}
