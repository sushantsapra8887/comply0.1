import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const code = searchParams.get('code');

  if (!code) {
    return NextResponse.json(
      { error: 'Authorization code is required' },
      { status: 400 }
    );
  }

  // TODO: Exchange code for session via Supabase Auth
  // const supabase = createClient(...)
  // const { data, error } = await supabase.auth.exchangeCodeForSession(code)

  return NextResponse.redirect(new URL('/dashboard', request.url));
}
