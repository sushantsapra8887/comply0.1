'use client';

import ScanForm from '@/components/scanner/ScanForm';

export default function ScannerPage() {
  return (
    <div className="min-h-screen bg-navy-900">
      <div className="mx-auto max-w-4xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-white sm:text-4xl">
            DPDP Compliance Scanner
          </h1>
          <p className="mt-3 text-slate-400">
            Enter your website URL below to run a comprehensive compliance scan against 30 DPDP Act
            requirements. Results are instant and free.
          </p>
        </div>

        <div className="mt-10">
          <ScanForm variant="page" />
        </div>

        {/* Placeholder for scan results */}
        <div className="mt-12 rounded-xl border border-navy-700 bg-navy-800/50 p-12 text-center">
          <div className="mx-auto h-16 w-16 rounded-full bg-navy-700/50 flex items-center justify-center">
            <svg className="h-8 w-8 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
          <h3 className="mt-4 text-lg font-medium text-white">Ready to Scan</h3>
          <p className="mt-2 text-sm text-slate-400">
            Enter a URL above to check your website&apos;s DPDP Act compliance. We&apos;ll analyze your
            privacy policy, consent mechanisms, security headers, and more.
          </p>
        </div>

        {/* What we check */}
        <div className="mt-16">
          <h2 className="text-xl font-bold text-white">What We Check</h2>
          <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
            {[
              { category: 'Privacy Notice', range: 'SC01-SC06', count: 6 },
              { category: 'Consent Mechanism', range: 'SC07-SC11', count: 5 },
              { category: 'Security Measures', range: 'SC12-SC18', count: 7 },
              { category: 'Data Collection', range: 'SC19-SC22', count: 4 },
              { category: 'Data Principal Rights', range: 'SC23-SC26, SC29-SC30', count: 6 },
              { category: "Children's Data", range: 'SC27-SC28', count: 2 },
            ].map((item) => (
              <div key={item.category} className="flex items-center gap-3 rounded-lg border border-navy-700 bg-navy-800/50 p-4">
                <span className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg bg-accent/10 font-mono text-xs font-bold text-accent">
                  {item.count}
                </span>
                <div>
                  <p className="text-sm font-medium text-white">{item.category}</p>
                  <p className="font-mono text-xs text-slate-500">{item.range}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
